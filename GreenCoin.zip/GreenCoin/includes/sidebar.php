<!-- Sidebar -->
    <aside id="sidebar"
        class="fixed top-0 left-0 h-full w-64 bg-green-800 text-white flex flex-col transform -translate-x-full md:translate-x-0 transition-transform duration-300 z-40">
        <div class="p-6 flex items-center justify-between border-b border-green-700">
            <span class="text-2xl font-bold">🌱 GreenCoin</span>
            <button onclick="toggleSidebar()" class="md:hidden text-white text-xl">✖</button>
        </div>
        <nav class="flex-1 p-4 space-y-3">
            <a href="dashboard.php" class="block px-3 py-2 rounded hover:bg-green-700">🏠 Dashboard</a>
            <a href="log_action.php" class="block px-3 py-2 rounded hover:bg-green-700">➕ Log Action</a>
            <a href="rewards.php" class="block px-3 py-2 rounded hover:bg-green-700 font-semibold bg-green-700">🎁 Rewards</a>
            <a href="profile.php" class="block px-3 py-2 rounded hover:bg-green-700">👤 Profile</a>
        </nav>
        <div class="p-4 border-t border-green-700">
            <a href="logout.php"
                class="block px-3 py-2 rounded bg-red-600 hover:bg-red-700 text-center">🚪 Logout</a>
        </div>
    </aside>

    <!-- Mobile menu button -->
    <button onclick="toggleSidebar()"
        class="md:hidden fixed top-4 left-4 z-50 bg-green-700 text-white p-2 rounded shadow " >☰
    </button>