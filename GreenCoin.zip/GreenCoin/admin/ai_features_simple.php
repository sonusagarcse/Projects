<?php
session_start();
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../public/login.php");
    exit;
}
$pdo = require __DIR__ . '/../config/db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Features - GreenCoin Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <?php include "components/sidebar.php"; ?>
    
    <div class="content p-6">
        <div class="mb-6">
            <h1 class="text-3xl font-bold text-gray-800 mb-2">
                <i class="fas fa-robot text-blue-600"></i> AI Features Dashboard
            </h1>
            <p class="text-gray-600">Manage and monitor AI-powered features</p>
        </div>

        <!-- Setup Instructions -->
        <div class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded mb-6">
            <i class="fas fa-info-circle"></i> 
            <strong>AI Features Setup Required:</strong>
            <ul class="mt-2 ml-4">
                <li>1. Run the database migration: <code>SOURCE ai/ai_database_migration.sql;</code></li>
                <li>2. Test the setup: <a href="test_ai_page.php" class="underline">Run AI Test</a></li>
                <li>3. Once setup is complete, the full AI features will be available</li>
            </ul>
        </div>

        <!-- Basic Stats -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- Users -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">Total Users</h3>
                        <p class="text-3xl font-bold text-blue-600">
                            <?= $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn() ?>
                        </p>
                    </div>
                    <div class="text-4xl text-blue-600">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>

            <!-- Actions -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">Total Actions</h3>
                        <p class="text-3xl font-bold text-green-600">
                            <?= $pdo->query("SELECT COUNT(*) FROM user_actions")->fetchColumn() ?>
                        </p>
                    </div>
                    <div class="text-4xl text-green-600">
                        <i class="fas fa-leaf"></i>
                    </div>
                </div>
            </div>

            <!-- Rewards -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">Total Rewards</h3>
                        <p class="text-3xl font-bold text-purple-600">
                            <?= $pdo->query("SELECT COUNT(*) FROM rewards")->fetchColumn() ?>
                        </p>
                    </div>
                    <div class="text-4xl text-purple-600">
                        <i class="fas fa-gift"></i>
                    </div>
                </div>
            </div>

            <!-- Coins -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">Total Coins</h3>
                        <p class="text-3xl font-bold text-yellow-600">
                            <?= $pdo->query("SELECT SUM(coins) FROM users")->fetchColumn() ?: 0 ?>
                        </p>
                    </div>
                    <div class="text-4xl text-yellow-600">
                        <i class="fas fa-coins"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- AI Features Status -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- AI Status -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-xl font-semibold text-gray-800 mb-4">
                    <i class="fas fa-cogs text-blue-600"></i> AI Features Status
                </h3>
                
                <div class="space-y-4">
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                            <h4 class="font-semibold text-gray-800">Carbon Calculator</h4>
                            <p class="text-sm text-gray-600">Calculate CO₂ savings from eco actions</p>
                        </div>
                        <div class="text-green-600">
                            <i class="fas fa-check-circle"></i> Ready
                        </div>
                    </div>

                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                            <h4 class="font-semibold text-gray-800">Smart Suggestions</h4>
                            <p class="text-sm text-gray-600">Personalized eco action recommendations</p>
                        </div>
                        <div class="text-green-600">
                            <i class="fas fa-check-circle"></i> Ready
                        </div>
                    </div>

                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                            <h4 class="font-semibold text-gray-800">Eco Chatbot</h4>
                            <p class="text-sm text-gray-600">24/7 AI assistant for eco guidance</p>
                        </div>
                        <div class="text-green-600">
                            <i class="fas fa-check-circle"></i> Ready
                        </div>
                    </div>

                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                            <h4 class="font-semibold text-gray-800">Photo Verification</h4>
                            <p class="text-sm text-gray-600">AI-powered photo verification</p>
                        </div>
                        <div class="text-yellow-600">
                            <i class="fas fa-exclamation-triangle"></i> Setup Required
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-xl font-semibold text-gray-800 mb-4">
                    <i class="fas fa-bolt text-yellow-600"></i> Quick Actions
                </h3>
                
                <div class="space-y-3">
                    <a href="test_ai_page.php" class="block w-full bg-blue-600 text-white text-center py-2 rounded-lg hover:bg-blue-700">
                        <i class="fas fa-vial mr-2"></i> Test AI Features
                    </a>
                    <a href="../test_ai_features.php" class="block w-full bg-green-600 text-white text-center py-2 rounded-lg hover:bg-green-700">
                        <i class="fas fa-cogs mr-2"></i> Run Full AI Test
                    </a>
                    <a href="../test_google_vision.php" class="block w-full bg-purple-600 text-white text-center py-2 rounded-lg hover:bg-purple-700">
                        <i class="fas fa-camera mr-2"></i> Test Google Vision API
                    </a>
                    <a href="index.php" class="block w-full bg-gray-600 text-white text-center py-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('-translate-x-full');
        }
    </script>
</body>
</html>
