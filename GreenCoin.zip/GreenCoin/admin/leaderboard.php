<?php
session_start();
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}
$pdo = require __DIR__ . '/../config/db.php';

// Fetch leaderboard data with actions count
$stmt = $pdo->query("
    SELECT u.name, u.email, u.coins, 
           COUNT(ua.id) as actions_taken,
           COUNT(CASE WHEN ua.status = 'approved' THEN 1 END) as approved_actions,
           COUNT(CASE WHEN ua.status = 'pending' THEN 1 END) as pending_actions
    FROM users u
    LEFT JOIN user_actions ua ON u.id = ua.user_id
    GROUP BY u.id, u.name, u.email, u.coins
    ORDER BY u.coins DESC, actions_taken DESC
    LIMIT 20
");
$leaders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Leaderboard - GreenCoin Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { 
      background: #f9fafa; 
      margin: 0;
      padding: 0;
    }
    .content { 
      padding: 20px; 
      margin-left: 256px; /* Account for fixed sidebar width (w-64 = 256px) */
      min-height: 100vh;
    }
    .table { border-radius: 12px; overflow: hidden; }
    .gold { color: #FFD700; font-weight: bold; }
    .silver { color: #C0C0C0; font-weight: bold; }
    .bronze { color: #CD7F32; font-weight: bold; }
    
    /* Mobile responsive */
    @media (max-width: 768px) {
      .content {
        margin-left: 0;
      }
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
  <?php include "components/sidebar.php"; ?>
  
  <!-- Content -->
  <div class="content">
  <h2 class="mb-4 text-success">🏆 GreenCoin Leaderboard</h2>
  
  <!-- Stats Cards -->
  <div class="row mb-4">
    <div class="col-md-3">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title text-warning">🥇 Top Performer</h5>
          <p class="card-text"><?= htmlspecialchars($leaders[0]['name'] ?? 'N/A') ?></p>
          <small class="text-muted"><?= $leaders[0]['coins'] ?? 0 ?> coins</small>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title text-info">📊 Most Active</h5>
          <p class="card-text">
            <?php
            $mostActive = array_reduce($leaders, function($carry, $item) {
              return ($carry === null || $item['actions_taken'] > $carry['actions_taken']) ? $item : $carry;
            });
            echo htmlspecialchars($mostActive['name'] ?? 'N/A');
            ?>
          </p>
          <small class="text-muted"><?= $mostActive['actions_taken'] ?? 0 ?> actions</small>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title text-success">✅ High Approval</h5>
          <p class="card-text">
            <?php
            $highApproval = array_reduce($leaders, function($carry, $item) {
              if ($item['actions_taken'] == 0) return $carry;
              $approvalRate = $item['approved_actions'] / $item['actions_taken'];
              if ($carry === null || $approvalRate > ($carry['approved_actions'] / $carry['actions_taken'])) {
                return $item;
              }
              return $carry;
            });
            echo htmlspecialchars($highApproval['name'] ?? 'N/A');
            ?>
          </p>
          <small class="text-muted">
            <?php 
            if ($highApproval && $highApproval['actions_taken'] > 0) {
              echo round(($highApproval['approved_actions'] / $highApproval['actions_taken']) * 100, 1) . '%';
            } else {
              echo 'N/A';
            }
            ?>
          </small>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title text-primary">👥 Total Users</h5>
          <p class="card-text"><?= count($leaders) ?></p>
          <small class="text-muted">in leaderboard</small>
        </div>
      </div>
    </div>
  </div>

  <table class="table table-striped table-hover shadow-sm">
    <thead class="table-success">
      <tr>
        <th>Rank</th>
        <th>Name</th>
        <th>Email</th>
        <th>Coins</th>
        <th>Actions</th>
        <th>Approved</th>
        <th>Pending</th>
        <th>Success Rate</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $rank = 1;
      foreach ($leaders as $row):
          $class = "";
          if ($rank == 1) $class = "gold";
          elseif ($rank == 2) $class = "silver";
          elseif ($rank == 3) $class = "bronze";
          
          $successRate = $row['actions_taken'] > 0 ? round(($row['approved_actions'] / $row['actions_taken']) * 100, 1) : 0;
      ?>
      <tr class="<?= $class ?>">
        <td>#<?= $rank ?></td>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><strong><?= htmlspecialchars($row['coins']) ?></strong></td>
        <td><?= $row['actions_taken'] ?></td>
        <td><span class="badge bg-success"><?= $row['approved_actions'] ?></span></td>
        <td><span class="badge bg-warning"><?= $row['pending_actions'] ?></span></td>
        <td>
          <div class="progress" style="height: 20px;">
            <div class="progress-bar <?= $successRate >= 80 ? 'bg-success' : ($successRate >= 60 ? 'bg-warning' : 'bg-danger') ?>" 
                 role="progressbar" style="width: <?= $successRate ?>%">
              <?= $successRate ?>%
            </div>
          </div>
        </td>
      </tr>
      <?php $rank++; endforeach; ?>
    </tbody>
  </table>
  </div>
  
  <!-- Footer / Scripts -->
  <?php include('../includes/footer.php'); ?>
  
  <script>
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      sidebar.classList.toggle('-translate-x-full');
    }
  </script>
</body>
</html>
