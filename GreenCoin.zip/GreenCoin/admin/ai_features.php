<?php
session_start();
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../public/login.php");
    exit;
}
$pdo = require __DIR__ . '/../config/db.php';

// Include AI classes with error handling
$ai_classes_loaded = true;
$error_message = '';

try {
    require_once '../ai/carbon_calculator.php';
    require_once '../ai/photo_verification.php';
    require_once '../ai/smart_suggestions.php';
    require_once '../ai/eco_chatbot.php';
    
    // Initialize AI classes
    $carbon_calc = new CarbonCalculator($pdo);
    $photo_verifier = new PhotoVerification($pdo);
    $suggestions = new SmartSuggestions($pdo);
    $chatbot = new EcoChatbot($pdo);
} catch (Exception $e) {
    $ai_classes_loaded = false;
    $error_message = $e->getMessage();
}

// Handle AI actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'auto_verify_photos':
                $result = $photo_verifier->autoVerifyHighConfidencePhotos();
                $success_message = "Auto-verified {$result['auto_approved']} photos, {$result['manual_review']} flagged for review";
                break;
                
            case 'calculate_carbon':
                $impact = $carbon_calc->getEnvironmentalImpact();
                $success_message = "Carbon calculation updated: {$impact['total_co2_saved']} kg CO2 saved";
                break;
                
            case 'generate_suggestions':
                // Generate suggestions for all users
                $stmt = $pdo->query("SELECT id FROM users WHERE role = 'user' LIMIT 10");
                $users = $stmt->fetchAll(PDO::FETCH_COLUMN);
                $generated = 0;
                foreach ($users as $user_id) {
                    $suggestions->getPersonalizedSuggestions($user_id, 3);
                    $generated++;
                }
                $success_message = "Generated AI suggestions for {$generated} users";
                break;
        }
    }
}

// Get AI statistics with error handling
$verification_stats = ['total_photos' => 0, 'approved_photos' => 0, 'pending_photos' => 0, 'rejected_photos' => 0];
$carbon_impact = ['total_co2_saved' => 0, 'trees_equivalent' => 0, 'total_actions' => 0, 'action_breakdown' => []];
$co2_leaderboard = [];

if ($ai_classes_loaded) {
    try {
        $verification_stats = $photo_verifier->getVerificationStats();
        $carbon_impact = $carbon_calc->getEnvironmentalImpact();
        $co2_leaderboard = $carbon_calc->getAllUsersCO2(10);
    } catch (Exception $e) {
        $error_message = "Error loading AI statistics: " . $e->getMessage();
    }
}

// Get recent AI activity
$recent_verifications = $pdo->query("
    SELECT vl.*, ua.photo_path, u.name as user_name, ea.name as action_name
    FROM verification_logs vl
    JOIN user_actions ua ON vl.action_id = ua.id
    JOIN users u ON ua.user_id = u.id
    JOIN eco_actions ea ON ua.action_id = ea.id
    ORDER BY vl.created_at DESC
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);

$recent_chatbot = $pdo->query("
    SELECT cc.*, u.name as user_name
    FROM chatbot_conversations cc
    LEFT JOIN users u ON cc.user_id = u.id
    ORDER BY cc.created_at DESC
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Features - GreenCoin Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-100">
    <?php include "components/sidebar.php"; ?>
    
    <div class="content p-6 md:ml-64">
        <div class="mb-6">
            <h1 class="text-3xl font-bold text-gray-800 mb-2">
                <i class="fas fa-robot text-blue-600"></i> AI Features Dashboard
            </h1>
            <p class="text-gray-600">Manage and monitor AI-powered features</p>
        </div>

        <?php if (isset($success_message)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success_message) ?>
            </div>
        <?php endif; ?>

        <?php if (!$ai_classes_loaded): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                <i class="fas fa-exclamation-triangle"></i> 
                <strong>AI Features Error:</strong> <?= htmlspecialchars($error_message) ?>
                <br><small>Please check that all AI files exist and the database migration has been run.</small>
            </div>
        <?php endif; ?>

        <!-- AI Overview Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- Photo Verification -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">Photo Verification</h3>
                        <p class="text-3xl font-bold text-blue-600"><?= $verification_stats['total_photos'] ?></p>
                        <p class="text-sm text-gray-600">Total Photos</p>
                    </div>
                    <div class="text-4xl text-blue-600">
                        <i class="fas fa-camera"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <div class="flex justify-between text-sm">
                        <span class="text-green-600">✓ <?= $verification_stats['approved_photos'] ?> Approved</span>
                        <span class="text-yellow-600">⏳ <?= $verification_stats['pending_photos'] ?> Pending</span>
                    </div>
                </div>
            </div>

            <!-- Carbon Calculator -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">CO₂ Saved</h3>
                        <p class="text-3xl font-bold text-green-600"><?= $carbon_impact['total_co2_saved'] ?> kg</p>
                        <p class="text-sm text-gray-600">Total Impact</p>
                    </div>
                    <div class="text-4xl text-green-600">
                        <i class="fas fa-leaf"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <div class="text-sm text-gray-600">
                        🌳 <?= $carbon_impact['trees_equivalent'] ?> trees equivalent
                    </div>
                </div>
            </div>

            <!-- Smart Suggestions -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">AI Suggestions</h3>
                        <p class="text-3xl font-bold text-purple-600"><?= $carbon_impact['total_actions'] ?></p>
                        <p class="text-sm text-gray-600">Actions Generated</p>
                    </div>
                    <div class="text-4xl text-purple-600">
                        <i class="fas fa-lightbulb"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <div class="text-sm text-gray-600">
                        💡 Personalized recommendations
                    </div>
                </div>
            </div>

            <!-- Chatbot -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">Eco Chatbot</h3>
                        <p class="text-3xl font-bold text-orange-600">24/7</p>
                        <p class="text-sm text-gray-600">AI Assistant</p>
                    </div>
                    <div class="text-4xl text-orange-600">
                        <i class="fas fa-comments"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <div class="text-sm text-gray-600">
                        🤖 Eco guidance & support
                    </div>
                </div>
            </div>
        </div>

        <!-- AI Actions -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <!-- AI Actions Panel -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-xl font-semibold text-gray-800 mb-4">
                    <i class="fas fa-cogs text-blue-600"></i> AI Actions
                </h3>
                
                <div class="space-y-4">
                    <form method="POST" class="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                        <div>
                            <h4 class="font-semibold text-gray-800">Auto-Verify Photos</h4>
                            <p class="text-sm text-gray-600">Use AI to automatically verify high-confidence photos</p>
                        </div>
                        <button type="submit" name="action" value="auto_verify_photos" 
                                class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                            <i class="fas fa-magic"></i> Run Now
                        </button>
                    </form>

                    <form method="POST" class="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                        <div>
                            <h4 class="font-semibold text-gray-800">Calculate Carbon Impact</h4>
                            <p class="text-sm text-gray-600">Update CO₂ savings calculations for all users</p>
                        </div>
                        <button type="submit" name="action" value="calculate_carbon" 
                                class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                            <i class="fas fa-calculator"></i> Calculate
                        </button>
                    </form>

                    <form method="POST" class="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                        <div>
                            <h4 class="font-semibold text-gray-800">Generate Suggestions</h4>
                            <p class="text-sm text-gray-600">Create personalized AI suggestions for users</p>
                        </div>
                        <button type="submit" name="action" value="generate_suggestions" 
                                class="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
                            <i class="fas fa-brain"></i> Generate
                        </button>
                    </form>
                </div>
            </div>

            <!-- CO₂ Leaderboard -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-xl font-semibold text-gray-800 mb-4">
                    <i class="fas fa-trophy text-green-600"></i> CO₂ Impact Leaderboard
                </h3>
                
                <div class="space-y-3">
                    <?php foreach ($co2_leaderboard as $index => $user): ?>
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div class="flex items-center">
                                <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3">
                                    <span class="text-sm font-semibold text-green-600"><?= $index + 1 ?></span>
                                </div>
                                <div>
                                    <div class="font-semibold text-gray-800"><?= htmlspecialchars($user['name']) ?></div>
                                    <div class="text-sm text-gray-600"><?= $user['approved_actions'] ?> actions</div>
                                </div>
                            </div>
                            <div class="text-right">
                                <div class="font-bold text-green-600"><?= $user['co2_saved'] ?> kg</div>
                                <div class="text-sm text-gray-600">CO₂ saved</div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Recent Verifications -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-xl font-semibold text-gray-800 mb-4">
                    <i class="fas fa-camera text-blue-600"></i> Recent Photo Verifications
                </h3>
                
                <div class="space-y-3">
                    <?php foreach ($recent_verifications as $verification): ?>
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div class="flex items-center">
                                <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                                    <i class="fas fa-camera text-blue-600"></i>
                                </div>
                                <div>
                                    <div class="font-semibold text-gray-800"><?= htmlspecialchars($verification['user_name']) ?></div>
                                    <div class="text-sm text-gray-600"><?= htmlspecialchars($verification['action_name']) ?></div>
                                </div>
                            </div>
                            <div class="text-right">
                                <div class="flex items-center">
                                    <?php if ($verification['verified']): ?>
                                        <i class="fas fa-check-circle text-green-600 mr-1"></i>
                                        <span class="text-sm text-green-600">Verified</span>
                                    <?php else: ?>
                                        <i class="fas fa-times-circle text-red-600 mr-1"></i>
                                        <span class="text-sm text-red-600">Rejected</span>
                                    <?php endif; ?>
                                </div>
                                <div class="text-xs text-gray-500"><?= $verification['confidence'] ?>% confidence</div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Recent Chatbot Activity -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-xl font-semibold text-gray-800 mb-4">
                    <i class="fas fa-comments text-orange-600"></i> Recent Chatbot Activity
                </h3>
                
                <div class="space-y-3">
                    <?php foreach ($recent_chatbot as $chat): ?>
                        <div class="p-3 bg-gray-50 rounded-lg">
                            <div class="flex items-center justify-between mb-2">
                                <div class="font-semibold text-gray-800">
                                    <?= $chat['user_name'] ? htmlspecialchars($chat['user_name']) : 'Anonymous' ?>
                                </div>
                                <div class="text-xs text-gray-500">
                                    <?= date('M j, H:i', strtotime($chat['created_at'])) ?>
                                </div>
                            </div>
                            <div class="text-sm text-gray-600 mb-1">
                                <strong>User:</strong> <?= htmlspecialchars(substr($chat['user_message'], 0, 100)) ?>...
                            </div>
                            <div class="text-sm text-gray-600">
                                <strong>Bot:</strong> <?= htmlspecialchars(substr($chat['bot_response'], 0, 100)) ?>...
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('-translate-x-full');
        }
    </script>
</body>
</html>
