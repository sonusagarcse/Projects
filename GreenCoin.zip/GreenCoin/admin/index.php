<?php
session_start();
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}
$pdo = require __DIR__ . '/../config/db.php';

// Get comprehensive stats
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_actions = $pdo->query("SELECT COUNT(*) FROM user_actions")->fetchColumn();
$total_coins = $pdo->query("SELECT SUM(coins) FROM users")->fetchColumn();
$pending_actions = $pdo->query("SELECT COUNT(*) FROM user_actions WHERE status = 'pending'")->fetchColumn();
$approved_actions = $pdo->query("SELECT COUNT(*) FROM user_actions WHERE status = 'approved'")->fetchColumn();
$rejected_actions = $pdo->query("SELECT COUNT(*) FROM user_actions WHERE status = 'rejected'")->fetchColumn();
$total_rewards = $pdo->query("SELECT COUNT(*) FROM rewards")->fetchColumn();
$total_redemptions = $pdo->query("SELECT COUNT(*) FROM redemptions")->fetchColumn();

// Get daily stats for the last 7 days
$daily_stats = $pdo->query("
    SELECT DATE(created_at) as date, 
           COUNT(*) as actions,
           COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved
    FROM user_actions 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(created_at)
    ORDER BY date DESC
")->fetchAll(PDO::FETCH_ASSOC);

// Get action type distribution
$action_distribution = $pdo->query("
    SELECT ea.name, COUNT(ua.id) as count, ea.coin_value
    FROM eco_actions ea
    LEFT JOIN user_actions ua ON ea.id = ua.action_id AND ua.status = 'approved'
    GROUP BY ea.id, ea.name, ea.coin_value
    ORDER BY count DESC
")->fetchAll(PDO::FETCH_ASSOC);

// Get top users
$top_users = $pdo->query("
    SELECT u.name, u.coins, COUNT(ua.id) as actions_taken
    FROM users u
    LEFT JOIN user_actions ua ON u.id = ua.user_id
    GROUP BY u.id, u.name, u.coins
    ORDER BY u.coins DESC
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// Get recent activity
$recent_activity = $pdo->query("
    SELECT ua.*, u.name as user_name, ea.name as action_name
    FROM user_actions ua
    JOIN users u ON ua.user_id = u.id
    JOIN eco_actions ea ON ua.action_id = ea.id
    ORDER BY ua.created_at DESC
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Panel - GreenCoin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body { 
      background: #f9fafa; 
      margin: 0;
      padding: 0;
    }
    .content { 
      padding: 20px; 
      margin-left: 256px; /* Account for fixed sidebar width (w-64 = 256px) */
      min-height: 100vh;
    }
    .card { border-radius: 12px; }
    
    /* Mobile responsive */
    @media (max-width: 768px) {
      .content {
        margin-left: 0;
      }
    }
  </style>
  
</head>
<body>
  <!-- Sidebar -->
  <?php include "components/sidebar.php"; ?>
  
  <!-- Content -->
  <div class="content">
    <h2 class="mb-4">📊 Admin Dashboard</h2>
    
    <!-- Main Stats Cards -->
    <div class="row g-4 mb-4">
      <div class="col-md-3">
        <div class="card p-4 shadow-sm border-start border-primary border-4">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <h6 class="text-muted mb-1">Total Users</h6>
              <h2 class="mb-0 text-primary"><?= $total_users ?></h2>
            </div>
            <div class="text-primary">
              <i class="fas fa-users fa-2x"></i>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card p-4 shadow-sm border-start border-success border-4">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <h6 class="text-muted mb-1">Total Actions</h6>
              <h2 class="mb-0 text-success"><?= $total_actions ?></h2>
            </div>
            <div class="text-success">
              <i class="fas fa-tasks fa-2x"></i>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card p-4 shadow-sm border-start border-warning border-4">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <h6 class="text-muted mb-1">Total Coins</h6>
              <h2 class="mb-0 text-warning"><?= $total_coins ?? 0 ?></h2>
            </div>
            <div class="text-warning">
              <i class="fas fa-coins fa-2x"></i>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card p-4 shadow-sm border-start border-info border-4">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <h6 class="text-muted mb-1">Pending Actions</h6>
              <h2 class="mb-0 text-info"><?= $pending_actions ?></h2>
            </div>
            <div class="text-info">
              <i class="fas fa-clock fa-2x"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Action Status Overview -->
    <div class="row g-4 mb-4">
      <div class="col-md-4">
        <div class="card p-4 shadow-sm">
          <h5 class="card-title text-success">✅ Approved Actions</h5>
          <h2 class="text-success"><?= $approved_actions ?></h2>
          <small class="text-muted">
            <?= $total_actions > 0 ? round(($approved_actions / $total_actions) * 100, 1) : 0 ?>% of total
          </small>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card p-4 shadow-sm">
          <h5 class="card-title text-danger">❌ Rejected Actions</h5>
          <h2 class="text-danger"><?= $rejected_actions ?></h2>
          <small class="text-muted">
            <?= $total_actions > 0 ? round(($rejected_actions / $total_actions) * 100, 1) : 0 ?>% of total
          </small>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card p-4 shadow-sm">
          <h5 class="card-title text-warning">🕐 Pending Actions</h5>
          <h2 class="text-warning"><?= $pending_actions ?></h2>
          <small class="text-muted">
            <?= $total_actions > 0 ? round(($pending_actions / $total_actions) * 100, 1) : 0 ?>% of total
          </small>
        </div>
      </div>
    </div>

    <!-- Charts Row -->
    <div class="row g-4 mb-4">
      <!-- Daily Activity Chart -->
      <div class="col-md-8">
        <div class="card p-4 shadow-sm">
          <h5 class="card-title">📈 Daily Activity (Last 7 Days)</h5>
          <canvas id="dailyActivityChart" width="400" height="200"></canvas>
        </div>
      </div>
      
      <!-- Action Distribution Chart -->
      <div class="col-md-4">
        <div class="card p-4 shadow-sm">
          <h5 class="card-title">🥧 Action Types</h5>
          <canvas id="actionDistributionChart" width="300" height="200"></canvas>
        </div>
      </div>
    </div>

    <!-- Additional Stats and Tables -->
    <div class="row g-4 mb-4">
      <!-- Top Users -->
      <div class="col-md-6">
        <div class="card p-4 shadow-sm">
          <h5 class="card-title">🏆 Top Users</h5>
          <div class="table-responsive">
            <table class="table table-sm">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Name</th>
                  <th>Coins</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($top_users as $index => $user): ?>
                <tr>
                  <td>#<?= $index + 1 ?></td>
                  <td><?= htmlspecialchars($user['name']) ?></td>
                  <td><span class="badge bg-warning"><?= $user['coins'] ?></span></td>
                  <td><?= $user['actions_taken'] ?></td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Rewards & Redemptions -->
      <div class="col-md-6">
        <div class="card p-4 shadow-sm">
          <h5 class="card-title">🎁 Rewards Overview</h5>
          <div class="row text-center">
            <div class="col-6">
              <h3 class="text-primary"><?= $total_rewards ?></h3>
              <small class="text-muted">Available Rewards</small>
            </div>
            <div class="col-6">
              <h3 class="text-success"><?= $total_redemptions ?></h3>
              <small class="text-muted">Total Redemptions</small>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Recent Activity -->
    <div class="row g-4">
      <div class="col-12">
        <div class="card p-4 shadow-sm">
          <h5 class="card-title">🕒 Recent Activity</h5>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>User</th>
                  <th>Action</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($recent_activity as $activity): ?>
                <tr>
                  <td><?= htmlspecialchars($activity['user_name']) ?></td>
                  <td><?= htmlspecialchars($activity['action_name']) ?></td>
                  <td>
                    <span class="badge <?= $activity['status'] === 'approved' ? 'bg-success' : ($activity['status'] === 'pending' ? 'bg-warning' : 'bg-danger') ?>">
                      <?= ucfirst($activity['status']) ?>
                    </span>
                  </td>
                  <td><?= date('M j, Y g:i A', strtotime($activity['created_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Footer / Scripts -->
  <?php include('../includes/footer.php'); ?>
  
  <script>
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      sidebar.classList.toggle('-translate-x-full');
    }

    // Daily Activity Chart
    const dailyCtx = document.getElementById('dailyActivityChart').getContext('2d');
    const dailyData = {
      labels: [<?php 
        $labels = [];
        $actions = [];
        $approved = [];
        for ($i = 6; $i >= 0; $i--) {
          $date = date('M j', strtotime("-{$i} days"));
          $labels[] = "'{$date}'";
          $found = false;
          foreach ($daily_stats as $stat) {
            if ($stat['date'] === date('Y-m-d', strtotime("-{$i} days"))) {
              $actions[] = $stat['actions'];
              $approved[] = $stat['approved'];
              $found = true;
              break;
            }
          }
          if (!$found) {
            $actions[] = 0;
            $approved[] = 0;
          }
        }
        echo implode(',', $labels);
      ?>],
      datasets: [{
        label: 'Total Actions',
        data: [<?= implode(',', $actions) ?>],
        borderColor: 'rgb(75, 192, 192)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        tension: 0.1
      }, {
        label: 'Approved Actions',
        data: [<?= implode(',', $approved) ?>],
        borderColor: 'rgb(54, 162, 235)',
        backgroundColor: 'rgba(54, 162, 235, 0.2)',
        tension: 0.1
      }]
    };

    new Chart(dailyCtx, {
      type: 'line',
      data: dailyData,
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });

    // Action Distribution Chart
    const actionCtx = document.getElementById('actionDistributionChart').getContext('2d');
    const actionData = {
      labels: [<?php 
        $actionLabels = [];
        $actionCounts = [];
        foreach ($action_distribution as $action) {
          $actionLabels[] = "'{$action['name']}'";
          $actionCounts[] = $action['count'];
        }
        echo implode(',', $actionLabels);
      ?>],
      datasets: [{
        data: [<?= implode(',', $actionCounts) ?>],
        backgroundColor: [
          '#FF6384',
          '#36A2EB',
          '#FFCE56',
          '#4BC0C0',
          '#9966FF',
          '#FF9F40'
        ]
      }]
    };

    new Chart(actionCtx, {
      type: 'doughnut',
      data: actionData,
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  </script>
</body>
</html>
