<?php
session_start();
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../public/login.php");
    exit;
}

$pdo = require __DIR__ . '/../config/db.php';

$success_message = '';
$error_message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'add') {
            // Add new reward
            $name = trim($_POST['name']);
            $description = trim($_POST['description']);
            $coin_cost = intval($_POST['coin_cost']);
            $stock = intval($_POST['stock']);
            $partner = trim($_POST['partner']);
            
            if (empty($name) || empty($description) || $coin_cost <= 0) {
                $error_message = "Please fill in all required fields with valid values.";
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO rewards (name, description, coin_cost, stock, partner) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$name, $description, $coin_cost, $stock, $partner]);
                    $success_message = "Reward added successfully!";
                } catch (PDOException $e) {
                    $error_message = "Error adding reward: " . $e->getMessage();
                }
            }
        } elseif ($action === 'edit') {
            // Edit existing reward
            $id = intval($_POST['id']);
            $name = trim($_POST['name']);
            $description = trim($_POST['description']);
            $coin_cost = intval($_POST['coin_cost']);
            $stock = intval($_POST['stock']);
            $partner = trim($_POST['partner']);
            
            if (empty($name) || empty($description) || $coin_cost <= 0) {
                $error_message = "Please fill in all required fields with valid values.";
            } else {
                try {
                    $stmt = $pdo->prepare("UPDATE rewards SET name=?, description=?, coin_cost=?, stock=?, partner=? WHERE id=?");
                    $stmt->execute([$name, $description, $coin_cost, $stock, $partner, $id]);
                    $success_message = "Reward updated successfully!";
                } catch (PDOException $e) {
                    $error_message = "Error updating reward: " . $e->getMessage();
                }
            }
        } elseif ($action === 'delete') {
            // Delete reward
            $id = intval($_POST['id']);
            try {
                $stmt = $pdo->prepare("DELETE FROM rewards WHERE id=?");
                $stmt->execute([$id]);
                $success_message = "Reward deleted successfully!";
            } catch (PDOException $e) {
                $error_message = "Error deleting reward: " . $e->getMessage();
            }
        }
    }
}

// Fetch all rewards
// Check if created_at column exists, otherwise order by id
$column_check = $pdo->query("SHOW COLUMNS FROM rewards LIKE 'created_at'")->fetch();
$order_column = $column_check ? 'created_at' : 'id';
$rewards = $pdo->query("SELECT * FROM rewards ORDER BY $order_column DESC")->fetchAll(PDO::FETCH_ASSOC);

// Get reward statistics
$total_rewards = $pdo->query("SELECT COUNT(*) FROM rewards")->fetchColumn();
$total_redemptions = $pdo->query("SELECT COUNT(*) FROM redemptions")->fetchColumn();
$low_stock_rewards = $pdo->query("SELECT COUNT(*) FROM rewards WHERE stock < 5")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Rewards Management - GreenCoin Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <style>
    body { 
      background: #f9fafa; 
      margin: 0;
      padding: 0;
    }
    .content { 
      padding: 20px; 
      margin-left: 256px; /* Account for fixed sidebar width (w-64 = 256px) */
      min-height: 100vh;
    }
    .card { border-radius: 12px; }
    
    /* Mobile responsive */
    @media (max-width: 768px) {
      .content {
        margin-left: 0;
      }
    }
    
    .reward-card {
      transition: all 0.3s ease;
    }
    
    .reward-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
    
    .stock-low {
      background: linear-gradient(135deg, #fef3c7, #fde68a);
      border-left: 4px solid #f59e0b;
    }
    
    .stock-out {
      background: linear-gradient(135deg, #fee2e2, #fecaca);
      border-left: 4px solid #ef4444;
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
  <?php include "components/sidebar.php"; ?>
  
  <!-- Content -->
  <div class="content">
    <h2 class="mb-4">🎁 Rewards Management</h2>
    
    <!-- Messages -->
    <?php if ($success_message): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($success_message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($error_message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>
    
    <!-- Statistics Cards -->
    <div class="row g-4 mb-4">
      <div class="col-md-3">
        <div class="card p-4 shadow-sm border-start border-primary border-4">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <h6 class="text-muted mb-1">Total Rewards</h6>
              <h2 class="mb-0 text-primary"><?= $total_rewards ?></h2>
            </div>
            <div class="text-primary">
              <i class="fas fa-gift fa-2x"></i>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card p-4 shadow-sm border-start border-success border-4">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <h6 class="text-muted mb-1">Total Redemptions</h6>
              <h2 class="mb-0 text-success"><?= $total_redemptions ?></h2>
            </div>
            <div class="text-success">
              <i class="fas fa-shopping-cart fa-2x"></i>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card p-4 shadow-sm border-start border-warning border-4">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <h6 class="text-muted mb-1">Low Stock</h6>
              <h2 class="mb-0 text-warning"><?= $low_stock_rewards ?></h2>
            </div>
            <div class="text-warning">
              <i class="fas fa-exclamation-triangle fa-2x"></i>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card p-4 shadow-sm border-start border-info border-4">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <h6 class="text-muted mb-1">Available</h6>
              <h2 class="mb-0 text-info"><?= $total_rewards - $low_stock_rewards ?></h2>
            </div>
            <div class="text-info">
              <i class="fas fa-check-circle fa-2x"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Add Reward Form -->
    <div class="card mb-4">
      <div class="card-header bg-primary text-white">
        <h5 class="mb-0">
          <i class="fas fa-plus me-2"></i>Add New Reward
        </h5>
      </div>
      <div class="card-body">
        <form method="POST" id="rewardForm">
          <input type="hidden" name="action" value="add">
          <div class="row g-3">
            <div class="col-md-6">
              <label for="name" class="form-label">Reward Name *</label>
              <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="col-md-6">
              <label for="coin_cost" class="form-label">Coin Cost *</label>
              <input type="number" class="form-control" id="coin_cost" name="coin_cost" min="1" required>
            </div>
            <div class="col-md-6">
              <label for="stock" class="form-label">Stock Quantity</label>
              <input type="number" class="form-control" id="stock" name="stock" min="0" value="10">
            </div>
            <div class="col-md-6">
              <label for="partner" class="form-label">Partner/Provider</label>
              <input type="text" class="form-control" id="partner" name="partner" placeholder="e.g., Campus Cafe, GreenShop">
            </div>
            <div class="col-12">
              <label for="description" class="form-label">Description *</label>
              <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
            </div>
            <div class="col-12">
              <button type="submit" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i>Add Reward
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
    
    <!-- Rewards List -->
    <div class="card">
      <div class="card-header bg-success text-white">
        <h5 class="mb-0">
          <i class="fas fa-list me-2"></i>All Rewards
        </h5>
      </div>
      <div class="card-body">
        <?php if (empty($rewards)): ?>
          <div class="text-center py-5">
            <i class="fas fa-gift text-muted" style="font-size: 4rem;"></i>
            <h4 class="text-muted mt-3">No rewards found</h4>
            <p class="text-muted">Add your first reward to get started!</p>
          </div>
        <?php else: ?>
          <div class="row g-4">
            <?php foreach ($rewards as $reward): ?>
              <div class="col-md-6 col-lg-4">
                <div class="card reward-card h-100 <?= $reward['stock'] == 0 ? 'stock-out' : ($reward['stock'] < 5 ? 'stock-low' : '') ?>">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                      <h6 class="card-title mb-0"><?= htmlspecialchars($reward['name']) ?></h6>
                      <div class="dropdown">
                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                          <i class="fas fa-ellipsis-v"></i>
                        </button>
                        <ul class="dropdown-menu">
                          <li><a class="dropdown-item" href="#" onclick="editReward(<?= htmlspecialchars(json_encode($reward)) ?>)">
                            <i class="fas fa-edit me-2"></i>Edit
                          </a></li>
                          <li><a class="dropdown-item text-danger" href="#" onclick="deleteReward(<?= $reward['id'] ?>, '<?= htmlspecialchars($reward['name']) ?>')">
                            <i class="fas fa-trash me-2"></i>Delete
                          </a></li>
                        </ul>
                      </div>
                    </div>
                    
                    <p class="card-text text-muted small"><?= htmlspecialchars($reward['description']) ?></p>
                    
                    <div class="row g-2 mb-3">
                      <div class="col-6">
                        <small class="text-muted">Cost:</small>
                        <div class="fw-bold text-primary"><?= $reward['coin_cost'] ?> coins</div>
                      </div>
                      <div class="col-6">
                        <small class="text-muted">Stock:</small>
                        <div class="fw-bold <?= $reward['stock'] == 0 ? 'text-danger' : ($reward['stock'] < 5 ? 'text-warning' : 'text-success') ?>">
                          <?= $reward['stock'] ?> left
                        </div>
                      </div>
                    </div>
                    
                    <?php if ($reward['partner']): ?>
                      <div class="mb-2">
                        <small class="text-muted">Partner:</small>
                        <div class="fw-bold"><?= htmlspecialchars($reward['partner']) ?></div>
                      </div>
                    <?php endif; ?>
                    
                    <div class="text-muted small">
                      <i class="fas fa-calendar me-1"></i>
                      Added: <?= date('M j, Y', strtotime($reward['created_at'])) ?>
                    </div>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  
  <!-- Edit Reward Modal -->
  <div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Edit Reward</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <form method="POST" id="editForm">
          <div class="modal-body">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="edit_id">
            <div class="mb-3">
              <label for="edit_name" class="form-label">Reward Name *</label>
              <input type="text" class="form-control" id="edit_name" name="name" required>
            </div>
            <div class="mb-3">
              <label for="edit_description" class="form-label">Description *</label>
              <textarea class="form-control" id="edit_description" name="description" rows="3" required></textarea>
            </div>
            <div class="row g-3">
              <div class="col-md-6">
                <label for="edit_coin_cost" class="form-label">Coin Cost *</label>
                <input type="number" class="form-control" id="edit_coin_cost" name="coin_cost" min="1" required>
              </div>
              <div class="col-md-6">
                <label for="edit_stock" class="form-label">Stock Quantity</label>
                <input type="number" class="form-control" id="edit_stock" name="stock" min="0">
              </div>
              <div class="col-12">
                <label for="edit_partner" class="form-label">Partner/Provider</label>
                <input type="text" class="form-control" id="edit_partner" name="partner">
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">Update Reward</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  
  <!-- Delete Confirmation Modal -->
  <div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Confirm Delete</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to delete the reward "<span id="delete_reward_name"></span>"?</p>
          <p class="text-danger small">This action cannot be undone.</p>
        </div>
        <form method="POST" id="deleteForm">
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="id" id="delete_id">
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-danger">Delete Reward</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  
  <!-- Footer / Scripts -->
  <?php include('../includes/footer.php'); ?>
  
  <script>
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      sidebar.classList.toggle('-translate-x-full');
    }
    
    function editReward(reward) {
      document.getElementById('edit_id').value = reward.id;
      document.getElementById('edit_name').value = reward.name;
      document.getElementById('edit_description').value = reward.description;
      document.getElementById('edit_coin_cost').value = reward.coin_cost;
      document.getElementById('edit_stock').value = reward.stock;
      document.getElementById('edit_partner').value = reward.partner || '';
      
      const modal = new bootstrap.Modal(document.getElementById('editModal'));
      modal.show();
    }
    
    function deleteReward(id, name) {
      document.getElementById('delete_id').value = id;
      document.getElementById('delete_reward_name').textContent = name;
      
      const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
      modal.show();
    }
    
    // Form validation
    document.getElementById('rewardForm').addEventListener('submit', function(e) {
      const coinCost = parseInt(document.getElementById('coin_cost').value);
      const stock = parseInt(document.getElementById('stock').value);
      
      if (coinCost <= 0) {
        e.preventDefault();
        alert('Coin cost must be greater than 0');
        return;
      }
      
      if (stock < 0) {
        e.preventDefault();
        alert('Stock quantity cannot be negative');
        return;
      }
    });
  </script>
</body>
</html>
