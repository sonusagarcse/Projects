<?php
/**
 * Simple test page to check AI features page loading
 */

session_start();

// Check if user is admin (simplified check)
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    echo "<h1>❌ Access Denied</h1>";
    echo "<p>You need to be logged in as admin to access this page.</p>";
    echo "<p><a href='../public/login.php'>Go to Login</a></p>";
    exit;
}

echo "<h1>🧪 AI Features Page Test</h1>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .test-section { background: #f5f5f5; padding: 15px; margin: 10px 0; border-radius: 5px; }
    .success { color: green; }
    .error { color: red; }
    .info { color: blue; }
</style>";

// Test 1: Session check
echo "<div class='test-section'>";
echo "<h2>1. Session Check</h2>";
echo "<p class='success'>✅ User session: " . $_SESSION['user']['name'] . "</p>";
echo "<p class='success'>✅ User role: " . $_SESSION['user']['role'] . "</p>";
echo "</div>";

// Test 2: Database connection
echo "<div class='test-section'>";
echo "<h2>2. Database Connection</h2>";
try {
    $pdo = require __DIR__ . '/../config/db.php';
    echo "<p class='success'>✅ Database connection successful</p>";
} catch (Exception $e) {
    echo "<p class='error'>❌ Database connection failed: " . $e->getMessage() . "</p>";
}
echo "</div>";

// Test 3: AI config file
echo "<div class='test-section'>";
echo "<h2>3. AI Configuration</h2>";
if (file_exists('../config/ai_config.php')) {
    echo "<p class='success'>✅ AI config file exists</p>";
    try {
        require_once '../config/ai_config.php';
        echo "<p class='success'>✅ AI config loaded successfully</p>";
        echo "<p class='info'>📊 Google Vision API Key: " . (strlen(getAIConfig('google_vision_api_key')) > 10 ? 'Set' : 'Not set') . "</p>";
    } catch (Exception $e) {
        echo "<p class='error'>❌ AI config error: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p class='error'>❌ AI config file not found</p>";
}
echo "</div>";

// Test 4: AI classes
echo "<div class='test-section'>";
echo "<h2>4. AI Classes</h2>";
$ai_files = [
    '../ai/carbon_calculator.php',
    '../ai/photo_verification.php',
    '../ai/smart_suggestions.php',
    '../ai/eco_chatbot.php'
];

foreach ($ai_files as $file) {
    if (file_exists($file)) {
        echo "<p class='success'>✅ " . basename($file) . " exists</p>";
    } else {
        echo "<p class='error'>❌ " . basename($file) . " not found</p>";
    }
}
echo "</div>";

// Test 5: Try to load AI classes
echo "<div class='test-section'>";
echo "<h2>5. AI Classes Loading</h2>";
try {
    require_once '../ai/carbon_calculator.php';
    require_once '../ai/photo_verification.php';
    require_once '../ai/smart_suggestions.php';
    require_once '../ai/eco_chatbot.php';
    echo "<p class='success'>✅ All AI classes loaded successfully</p>";
    
    // Try to initialize
    $carbon_calc = new CarbonCalculator($pdo);
    $photo_verifier = new PhotoVerification($pdo);
    $suggestions = new SmartSuggestions($pdo);
    $chatbot = new EcoChatbot($pdo);
    echo "<p class='success'>✅ All AI classes initialized successfully</p>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ AI classes error: " . $e->getMessage() . "</p>";
    echo "<p class='error'>❌ Error in file: " . $e->getFile() . " line " . $e->getLine() . "</p>";
}
echo "</div>";

// Test 6: Database tables
echo "<div class='test-section'>";
echo "<h2>6. Database Tables</h2>";
$ai_tables = ['verification_logs', 'chatbot_conversations', 'ai_suggestions', 'carbon_footprint'];
foreach ($ai_tables as $table) {
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
        echo "<p class='success'>✅ Table '$table' exists</p>";
    } catch (PDOException $e) {
        echo "<p class='error'>❌ Table '$table' not found - run database migration</p>";
    }
}
echo "</div>";

echo "<div class='test-section'>";
echo "<h2>🎯 Next Steps</h2>";
echo "<p class='info'>If all tests pass, the AI features page should work.</p>";
echo "<p><a href='ai_features.php' target='_blank'>Try AI Features Page</a></p>";
echo "<p><a href='../test_ai_features.php' target='_blank'>Run Full AI Test</a></p>";
echo "</div>";
?>
