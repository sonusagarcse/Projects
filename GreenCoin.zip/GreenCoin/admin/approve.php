<?php
session_start();
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../public/login.php');
    exit;
}

$pdo = require __DIR__ . '/../config/db.php';

// Handle approve/reject actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $action = $_POST['action'];
    
    if ($action === 'approve') {
        $ua = $pdo->prepare('SELECT * FROM user_actions WHERE id=?');
        $ua->execute([$id]);
        $r = $ua->fetch();
        
        if ($r) {
            $ea = $pdo->prepare('SELECT coin_value FROM eco_actions WHERE id=?');
            $ea->execute([$r['action_id']]);
            $cv = $ea->fetchColumn();
            
            $pdo->beginTransaction();
            $pdo->prepare('UPDATE user_actions SET status=?, coins_awarded=? WHERE id=?')->execute(['approved', $cv, $id]);
            $pdo->prepare('UPDATE users SET coins = coins + ? WHERE id=?')->execute([$cv, $r['user_id']]);
            $pdo->prepare('INSERT INTO transactions (user_id,type,amount,meta,created_at) VALUES (?,?,?,?,NOW())')->execute([$r['user_id'], 'earn', $cv, '{"action_id":' . $r['action_id'] . '}']);
            $pdo->commit();
            
            $success_message = "Action approved successfully! User earned {$cv} coins.";
        }
    } else {
        $pdo->prepare('UPDATE user_actions SET status=? WHERE id=?')->execute(['rejected', $id]);
        $success_message = "Action rejected successfully.";
    }
}

// Get pending actions with user and eco_action details
$stmt = $pdo->query("
    SELECT ua.*, u.name as user_name, u.email, ea.name as action_name, ea.coin_value, ea.description as action_description
    FROM user_actions ua
    JOIN users u ON ua.user_id = u.id
    JOIN eco_actions ea ON ua.action_id = ea.id
    WHERE ua.status = 'pending'
    ORDER BY ua.created_at DESC
");
$pending_actions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get recent approved/rejected actions
$stmt = $pdo->query("
    SELECT ua.*, u.name as user_name, u.email, ea.name as action_name, ea.coin_value
    FROM user_actions ua
    JOIN users u ON ua.user_id = u.id
    JOIN eco_actions ea ON ua.action_id = ea.id
    WHERE ua.status IN ('approved', 'rejected')
    ORDER BY ua.created_at DESC
    LIMIT 10
");
$recent_actions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Approve Actions - GreenCoin Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { 
      background: #f9fafa; 
      margin: 0;
      padding: 0;
    }
    .content { 
      padding: 20px; 
      margin-left: 256px; /* Account for fixed sidebar width (w-64 = 256px) */
      min-height: 100vh;
    }
    .card { border-radius: 12px; }
    
    /* Mobile responsive */
    @media (max-width: 768px) {
      .content {
        margin-left: 0;
      }
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
  <?php include "components/sidebar.php"; ?>
  
  <!-- Content -->
  <div class="content">
    <h2 class="mb-4">✅ Approve Actions</h2>
    
    <?php if (isset($success_message)): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($success_message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>
    
    <!-- Pending Actions -->
    <div class="card mb-4">
      <div class="card-header bg-warning text-dark">
        <h5 class="mb-0">🕐 Pending Actions (<?= count($pending_actions) ?>)</h5>
      </div>
      <div class="card-body">
        <?php if (empty($pending_actions)): ?>
          <p class="text-muted">No pending actions to review.</p>
        <?php else: ?>
          <div class="row g-3">
            <?php foreach ($pending_actions as $action): ?>
              <div class="col-md-6 col-lg-4">
                <div class="card h-100">
                  <div class="card-body">
                    <h6 class="card-title"><?= htmlspecialchars($action['action_name']) ?></h6>
                    <p class="card-text">
                      <strong>User:</strong> <?= htmlspecialchars($action['user_name']) ?><br>
                      <strong>Email:</strong> <?= htmlspecialchars($action['email']) ?><br>
                      <strong>Coins:</strong> <?= $action['coin_value'] ?><br>
                      <strong>Date:</strong> <?= date('M j, Y g:i A', strtotime($action['created_at'])) ?>
                    </p>
                    <?php if ($action['notes']): ?>
                      <p class="card-text"><strong>Notes:</strong> <?= htmlspecialchars($action['notes']) ?></p>
                    <?php endif; ?>
                    <?php if ($action['photo_path']): ?>
                      <div class="mb-2">
                        <img src="../<?= htmlspecialchars($action['photo_path']) ?>" 
                             class="img-thumbnail" style="max-width: 100px; max-height: 100px;" 
                             alt="Action Photo">
                      </div>
                    <?php endif; ?>
                  </div>
                  <div class="card-footer bg-light">
                    <form method="POST" class="d-inline">
                      <input type="hidden" name="id" value="<?= $action['id'] ?>">
                      <button type="submit" name="action" value="approve" 
                              class="btn btn-success btn-sm me-2" 
                              onclick="return confirm('Approve this action?')">
                        ✅ Approve
                      </button>
                      <button type="submit" name="action" value="reject" 
                              class="btn btn-danger btn-sm"
                              onclick="return confirm('Reject this action?')">
                        ❌ Reject
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
    
    <!-- Recent Actions -->
    <div class="card">
      <div class="card-header bg-info text-white">
        <h5 class="mb-0">📋 Recent Actions</h5>
      </div>
      <div class="card-body">
        <?php if (empty($recent_actions)): ?>
          <p class="text-muted">No recent actions found.</p>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>User</th>
                  <th>Action</th>
                  <th>Status</th>
                  <th>Coins</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($recent_actions as $action): ?>
                  <tr>
                    <td><?= htmlspecialchars($action['user_name']) ?></td>
                    <td><?= htmlspecialchars($action['action_name']) ?></td>
                    <td>
                      <span class="badge <?= $action['status'] === 'approved' ? 'bg-success' : 'bg-danger' ?>">
                        <?= ucfirst($action['status']) ?>
                      </span>
                    </td>
                    <td><?= $action['coins_awarded'] ?></td>
                    <td><?= date('M j, Y g:i A', strtotime($action['created_at'])) ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  
  <!-- Footer / Scripts -->
  <?php include('../includes/footer.php'); ?>
  
  <script>
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      sidebar.classList.toggle('-translate-x-full');
    }
  </script>
</body>
</html>