
-- SQL schema for GreenCoin simple PHP project
CREATE DATABASE IF NOT EXISTS greencoin_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE greencoin_db;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(150) UNIQUE,
  password VARCHAR(255),
  role VARCHAR(30) DEFAULT 'user',
  coins INT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE eco_actions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150),
  coin_value INT DEFAULT 5,
  description TEXT
);

CREATE TABLE user_actions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  action_id INT,
  photo_path VARCHAR(255),
  notes TEXT,
  status VARCHAR(20) DEFAULT 'pending',
  coins_awarded INT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  type VARCHAR(20),
  amount INT,
  meta JSON,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE rewards (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150),
  description TEXT,
  coin_cost INT DEFAULT 50,
  stock INT DEFAULT 10,
  partner VARCHAR(150)
);

CREATE TABLE redemptions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  reward_id INT,
  status VARCHAR(30) DEFAULT 'requested',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Contacts table for landing page contact form
CREATE TABLE IF NOT EXISTS contacts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150),
  email VARCHAR(150),
  message TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Seed data (note: update password with password_hash in PHP or register manually)
INSERT INTO users (name,email,password,role,coins) VALUES
('Admin User','admin@example.com','__SET_PASSWORD_HASH__','admin',100),
('Test User','user@example.com','userpasshash','user',25);

INSERT INTO eco_actions (name,coin_value,description) VALUES
('Used Bicycle',10,'Traveled by bicycle'),
('Used Public Transport',5,'Bus or train used'),
('Planted a Tree',50,'Tree planting activity'),
('Recycled Plastic',8,'Recycled plastic waste');

INSERT INTO rewards (name,description,coin_cost,stock,partner) VALUES
('Cafeteria 10% Off','Discount at campus cafeteria',50,10,'Campus Cafe'),
('Reusable Bottle','Eco-friendly bottle',150,5,'GreenShop');
