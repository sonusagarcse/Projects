-- =====================================================
-- AI Features Database Migration
-- =====================================================
-- This script adds tables needed for AI features
-- =====================================================

-- Create verification logs table for photo verification
CREATE TABLE IF NOT EXISTS verification_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    action_id INT NOT NULL,
    verified TINYINT(1) DEFAULT 0,
    confidence DECIMAL(3,2) DEFAULT 0.00,
    reason TEXT,
    status ENUM('auto_approved', 'manual_review', 'rejected') DEFAULT 'manual_review',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (action_id) REFERENCES user_actions(id) ON DELETE CASCADE
);

-- Create chatbot conversations table
CREATE TABLE IF NOT EXISTS chatbot_conversations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    conversation_id VARCHAR(100) NOT NULL,
    user_id INT,
    user_message TEXT NOT NULL,
    bot_response TEXT NOT NULL,
    intent VARCHAR(50),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_conversation_id (conversation_id),
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at)
);

-- Create AI suggestions table
CREATE TABLE IF NOT EXISTS ai_suggestions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action_name VARCHAR(150) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    reason TEXT,
    priority ENUM('high', 'medium', 'low') DEFAULT 'medium',
    type ENUM('behavior_based', 'time_based', 'location_based', 'trending', 'default') DEFAULT 'default',
    score DECIMAL(5,2) DEFAULT 0.00,
    shown_at DATETIME,
    clicked_at DATETIME,
    action_taken_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_priority (priority),
    INDEX idx_type (type),
    INDEX idx_created_at (created_at)
);

-- Create carbon footprint tracking table
CREATE TABLE IF NOT EXISTS carbon_footprint (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action_id INT NOT NULL,
    co2_saved DECIMAL(8,2) DEFAULT 0.00,
    calculation_method VARCHAR(100),
    verified_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (action_id) REFERENCES user_actions(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_action_id (action_id),
    INDEX idx_created_at (created_at)
);

-- Create AI analytics table
CREATE TABLE IF NOT EXISTS ai_analytics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    feature_name VARCHAR(100) NOT NULL,
    user_id INT,
    action_type VARCHAR(50),
    data JSON,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_feature_name (feature_name),
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at)
);

-- Add AI-related columns to existing tables
ALTER TABLE user_actions 
ADD COLUMN ai_verified TINYINT(1) DEFAULT 0,
ADD COLUMN ai_confidence DECIMAL(3,2) DEFAULT 0.00,
ADD COLUMN ai_reason TEXT;

-- Add AI suggestion tracking to users table
ALTER TABLE users 
ADD COLUMN ai_suggestions_enabled TINYINT(1) DEFAULT 1,
ADD COLUMN last_ai_interaction DATETIME,
ADD COLUMN preferred_ai_features JSON;

-- Create indexes for better performance
CREATE INDEX idx_user_actions_ai_verified ON user_actions(ai_verified);
CREATE INDEX idx_user_actions_ai_confidence ON user_actions(ai_confidence);
CREATE INDEX idx_users_ai_suggestions_enabled ON users(ai_suggestions_enabled);

-- Insert default AI settings
INSERT INTO ai_analytics (feature_name, data, created_at) VALUES
('carbon_calculator', '{"enabled": true, "version": "1.0"}', NOW()),
('photo_verification', '{"enabled": true, "version": "1.0", "threshold": 0.7}', NOW()),
('smart_suggestions', '{"enabled": true, "version": "1.0"}', NOW()),
('eco_chatbot', '{"enabled": true, "version": "1.0"}', NOW())
ON DUPLICATE KEY UPDATE data = VALUES(data);

-- =====================================================
-- END OF AI DATABASE MIGRATION
-- =====================================================
