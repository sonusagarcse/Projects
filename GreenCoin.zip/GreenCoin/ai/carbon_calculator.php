<?php
/**
 * AI-Powered Carbon Footprint Calculator
 * Calculates real CO2 savings from eco actions using environmental data
 */

class CarbonCalculator {
    private $pdo;
    
    // CO2 emission factors (kg CO2 per unit)
    private $emission_factors = [
        'car_km' => 0.192,           // kg CO2 per km (average car)
        'bus_km' => 0.089,           // kg CO2 per km (bus)
        'train_km' => 0.041,         // kg CO2 per km (train)
        'bike_km' => 0.0,            // kg CO2 per km (bicycle)
        'walk_km' => 0.0,            // kg CO2 per km (walking)
        'plastic_bottle' => 0.082,   // kg CO2 per plastic bottle
        'tree_planted' => -22.0,     // kg CO2 absorbed per tree per year
        'led_bulb_hour' => 0.0001,   // kg CO2 per hour (vs incandescent)
        'local_food_kg' => -0.5,     // kg CO2 saved per kg local food
        'compost_kg' => -0.5,        // kg CO2 saved per kg composted
    ];
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Calculate CO2 savings for a specific eco action
     */
    public function calculateActionCO2($action_name, $quantity = 1, $unit = 'default') {
        $action_name = strtolower($action_name);
        
        switch($action_name) {
            case 'used bicycle':
                return $this->calculateBikeCO2($quantity);
            case 'used public transport':
                return $this->calculatePublicTransportCO2($quantity);
            case 'planted a tree':
                return $this->calculateTreeCO2($quantity);
            case 'recycled plastic':
                return $this->calculateRecycleCO2($quantity);
            case 'used reusable bottle':
                return $this->calculateBottleCO2($quantity);
            case 'carpooled':
                return $this->calculateCarpoolCO2($quantity);
            case 'walked to work':
                return $this->calculateWalkCO2($quantity);
            case 'used led bulbs':
                return $this->calculateLEDCO2($quantity);
            case 'composted':
                return $this->calculateCompostCO2($quantity);
            case 'bought local products':
                return $this->calculateLocalFoodCO2($quantity);
            default:
                return $this->calculateGenericCO2($action_name, $quantity);
        }
    }
    
    /**
     * Calculate CO2 savings for bicycle usage
     */
    private function calculateBikeCO2($km) {
        // Assume average trip is 5km if not specified
        $distance = $km > 0 ? $km : 5;
        $car_emissions = $distance * $this->emission_factors['car_km'];
        $bike_emissions = $distance * $this->emission_factors['bike_km'];
        
        return round($car_emissions - $bike_emissions, 2);
    }
    
    /**
     * Calculate CO2 savings for public transport
     */
    private function calculatePublicTransportCO2($km) {
        $distance = $km > 0 ? $km : 5;
        $car_emissions = $distance * $this->emission_factors['car_km'];
        $bus_emissions = $distance * $this->emission_factors['bus_km'];
        
        return round($car_emissions - $bus_emissions, 2);
    }
    
    /**
     * Calculate CO2 absorption for tree planting
     */
    private function calculateTreeCO2($trees) {
        $trees_planted = $trees > 0 ? $trees : 1;
        return round($trees_planted * $this->emission_factors['tree_planted'], 2);
    }
    
    /**
     * Calculate CO2 savings for plastic recycling
     */
    private function calculateRecycleCO2($bottles) {
        $bottles_recycled = $bottles > 0 ? $bottles : 1;
        return round($bottles_recycled * $this->emission_factors['plastic_bottle'], 2);
    }
    
    /**
     * Calculate CO2 savings for reusable bottle
     */
    private function calculateBottleCO2($bottles) {
        $bottles_saved = $bottles > 0 ? $bottles : 1;
        return round($bottles_saved * $this->emission_factors['plastic_bottle'], 2);
    }
    
    /**
     * Calculate CO2 savings for carpooling
     */
    private function calculateCarpoolCO2($km) {
        $distance = $km > 0 ? $km : 10;
        // Carpool reduces emissions by 50% (2 people sharing)
        $car_emissions = $distance * $this->emission_factors['car_km'];
        return round($car_emissions * 0.5, 2);
    }
    
    /**
     * Calculate CO2 savings for walking
     */
    private function calculateWalkCO2($km) {
        $distance = $km > 0 ? $km : 2;
        $car_emissions = $distance * $this->emission_factors['car_km'];
        $walk_emissions = $distance * $this->emission_factors['walk_km'];
        
        return round($car_emissions - $walk_emissions, 2);
    }
    
    /**
     * Calculate CO2 savings for LED bulbs
     */
    private function calculateLEDCO2($hours) {
        $hours_used = $hours > 0 ? $hours : 8; // 8 hours per day
        return round($hours_used * $this->emission_factors['led_bulb_hour'], 2);
    }
    
    /**
     * Calculate CO2 savings for composting
     */
    private function calculateCompostCO2($kg) {
        $kg_composted = $kg > 0 ? $kg : 1;
        return round($kg_composted * $this->emission_factors['compost_kg'], 2);
    }
    
    /**
     * Calculate CO2 savings for local food
     */
    private function calculateLocalFoodCO2($kg) {
        $kg_local = $kg > 0 ? $kg : 1;
        return round($kg_local * $this->emission_factors['local_food_kg'], 2);
    }
    
    /**
     * Calculate generic CO2 savings
     */
    private function calculateGenericCO2($action_name, $quantity) {
        // Default calculation based on action type
        if (strpos($action_name, 'bike') !== false || strpos($action_name, 'bicycle') !== false) {
            return $this->calculateBikeCO2($quantity);
        } elseif (strpos($action_name, 'transport') !== false || strpos($action_name, 'bus') !== false) {
            return $this->calculatePublicTransportCO2($quantity);
        } elseif (strpos($action_name, 'tree') !== false) {
            return $this->calculateTreeCO2($quantity);
        } else {
            // Default small positive impact
            return round($quantity * 0.1, 2);
        }
    }
    
    /**
     * Get total CO2 savings for a user
     */
    public function getUserTotalCO2($user_id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT ua.*, ea.name as action_name, ea.coin_value
                FROM user_actions ua
                JOIN eco_actions ea ON ua.action_id = ea.id
                WHERE ua.user_id = ? AND ua.status = 'approved'
                ORDER BY ua.created_at DESC
            ");
            $stmt->execute([$user_id]);
            $actions = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $total_co2 = 0;
            $co2_breakdown = [];
            
            foreach ($actions as $action) {
                $co2_saved = $this->calculateActionCO2($action['action_name']);
                $total_co2 += $co2_saved;
                
                if (!isset($co2_breakdown[$action['action_name']])) {
                    $co2_breakdown[$action['action_name']] = 0;
                }
                $co2_breakdown[$action['action_name']] += $co2_saved;
            }
            
            return [
                'total_co2' => round($total_co2, 2),
                'breakdown' => $co2_breakdown,
                'actions_count' => count($actions)
            ];
        } catch (PDOException $e) {
            return [
                'total_co2' => 0,
                'breakdown' => [],
                'actions_count' => 0,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get CO2 savings for all users (leaderboard)
     */
    public function getAllUsersCO2($limit = 20) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT u.id, u.name, u.email, u.coins,
                       COUNT(ua.id) as total_actions,
                       SUM(CASE WHEN ua.status = 'approved' THEN 1 ELSE 0 END) as approved_actions
                FROM users u
                LEFT JOIN user_actions ua ON u.id = ua.user_id
                WHERE u.role = 'user'
                GROUP BY u.id, u.name, u.email, u.coins
                ORDER BY approved_actions DESC, u.coins DESC
                LIMIT ?
            ");
            $stmt->execute([$limit]);
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $co2_leaderboard = [];
            foreach ($users as $user) {
                $co2_data = $this->getUserTotalCO2($user['id']);
                $co2_leaderboard[] = [
                    'user_id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'coins' => $user['coins'],
                    'total_actions' => $user['total_actions'],
                    'approved_actions' => $user['approved_actions'],
                    'co2_saved' => $co2_data['total_co2'],
                    'co2_breakdown' => $co2_data['breakdown']
                ];
            }
            
            // Sort by CO2 saved
            usort($co2_leaderboard, function($a, $b) {
                return $b['co2_saved'] <=> $a['co2_saved'];
            });
            
            return $co2_leaderboard;
        } catch (PDOException $e) {
            return [];
        }
    }
    
    /**
     * Get environmental impact summary
     */
    public function getEnvironmentalImpact() {
        try {
            // Total CO2 saved across all users
            $stmt = $this->pdo->query("
                SELECT ua.*, ea.name as action_name
                FROM user_actions ua
                JOIN eco_actions ea ON ua.action_id = ea.id
                WHERE ua.status = 'approved'
            ");
            $actions = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $total_co2 = 0;
            $action_counts = [];
            $trees_equivalent = 0;
            
            foreach ($actions as $action) {
                $co2_saved = $this->calculateActionCO2($action['action_name']);
                $total_co2 += $co2_saved;
                
                if (!isset($action_counts[$action['action_name']])) {
                    $action_counts[$action['action_name']] = 0;
                }
                $action_counts[$action['action_name']]++;
            }
            
            // Calculate trees equivalent (1 tree absorbs ~22kg CO2 per year)
            $trees_equivalent = round($total_co2 / 22, 1);
            
            return [
                'total_co2_saved' => round($total_co2, 2),
                'trees_equivalent' => $trees_equivalent,
                'total_actions' => count($actions),
                'action_breakdown' => $action_counts,
                'average_co2_per_action' => count($actions) > 0 ? round($total_co2 / count($actions), 2) : 0
            ];
        } catch (PDOException $e) {
            return [
                'total_co2_saved' => 0,
                'trees_equivalent' => 0,
                'total_actions' => 0,
                'action_breakdown' => [],
                'average_co2_per_action' => 0,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get CO2 savings for a specific time period
     */
    public function getCO2ByPeriod($days = 7) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT DATE(ua.created_at) as date,
                       ua.*, ea.name as action_name
                FROM user_actions ua
                JOIN eco_actions ea ON ua.action_id = ea.id
                WHERE ua.status = 'approved' 
                AND ua.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                ORDER BY ua.created_at DESC
            ");
            $stmt->execute([$days]);
            $actions = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $daily_co2 = [];
            $total_co2 = 0;
            
            foreach ($actions as $action) {
                $co2_saved = $this->calculateActionCO2($action['action_name']);
                $date = $action['date'];
                
                if (!isset($daily_co2[$date])) {
                    $daily_co2[$date] = 0;
                }
                $daily_co2[$date] += $co2_saved;
                $total_co2 += $co2_saved;
            }
            
            return [
                'daily_co2' => $daily_co2,
                'total_co2' => round($total_co2, 2),
                'period_days' => $days
            ];
        } catch (PDOException $e) {
            return [
                'daily_co2' => [],
                'total_co2' => 0,
                'period_days' => $days,
                'error' => $e->getMessage()
            ];
        }
    }
}

// Usage example:
/*
require_once '../config/db.php';
$carbon_calc = new CarbonCalculator($pdo);

// Calculate CO2 for a specific action
$co2_saved = $carbon_calc->calculateActionCO2('Used Bicycle', 5); // 5km bike ride
echo "CO2 saved: " . $co2_saved . " kg";

// Get user's total CO2 savings
$user_co2 = $carbon_calc->getUserTotalCO2(1);
echo "Total CO2 saved: " . $user_co2['total_co2'] . " kg";

// Get environmental impact summary
$impact = $carbon_calc->getEnvironmentalImpact();
echo "Total CO2 saved by all users: " . $impact['total_co2_saved'] . " kg";
echo "Equivalent to planting " . $impact['trees_equivalent'] . " trees";
*/
?>
