<?php
/**
 * AI-Powered Smart Suggestions System
 * Provides personalized eco-action recommendations based on user behavior
 */

class SmartSuggestions {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Get personalized suggestions for a user
     */
    public function getPersonalizedSuggestions($user_id, $limit = 5) {
        try {
            // Get user's action history
            $user_profile = $this->getUserProfile($user_id);
            
            // Get user's location (if available)
            $location = $this->getUserLocation($user_id);
            
            // Get weather data (if location available)
            $weather = $location ? $this->getWeatherData($location) : null;
            
            // Get time-based suggestions
            $time_suggestions = $this->getTimeBasedSuggestions();
            
            // Get behavior-based suggestions
            $behavior_suggestions = $this->getBehaviorBasedSuggestions($user_profile);
            
            // Get location-based suggestions
            $location_suggestions = $location ? $this->getLocationBasedSuggestions($location, $weather) : [];
            
            // Get trending suggestions
            $trending_suggestions = $this->getTrendingSuggestions();
            
            // Combine and rank suggestions
            $all_suggestions = array_merge(
                $time_suggestions,
                $behavior_suggestions,
                $location_suggestions,
                $trending_suggestions
            );
            
            // Remove duplicates and rank by relevance
            $ranked_suggestions = $this->rankSuggestions($all_suggestions, $user_profile);
            
            return array_slice($ranked_suggestions, 0, $limit);
            
        } catch (Exception $e) {
            error_log("Smart suggestions error: " . $e->getMessage());
            return $this->getDefaultSuggestions($limit);
        }
    }
    
    /**
     * Get user profile for suggestions
     */
    private function getUserProfile($user_id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    u.id, u.name, u.coins,
                    COUNT(ua.id) as total_actions,
                    COUNT(CASE WHEN ua.status = 'approved' THEN 1 END) as approved_actions,
                    COUNT(CASE WHEN ua.status = 'pending' THEN 1 END) as pending_actions,
                    AVG(ea.coin_value) as avg_coin_value,
                    GROUP_CONCAT(DISTINCT ea.name) as action_history
                FROM users u
                LEFT JOIN user_actions ua ON u.id = ua.user_id
                LEFT JOIN eco_actions ea ON ua.action_id = ea.id
                WHERE u.id = ?
                GROUP BY u.id, u.name, u.coins
            ");
            $stmt->execute([$user_id]);
            $profile = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Get recent actions (last 30 days)
            $stmt = $this->pdo->prepare("
                SELECT ea.name, ea.coin_value, ua.created_at
                FROM user_actions ua
                JOIN eco_actions ea ON ua.action_id = ea.id
                WHERE ua.user_id = ? AND ua.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                ORDER BY ua.created_at DESC
            ");
            $stmt->execute([$user_id]);
            $recent_actions = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $profile['recent_actions'] = $recent_actions;
            $profile['action_frequency'] = $this->calculateActionFrequency($recent_actions);
            
            return $profile;
        } catch (PDOException $e) {
            return [
                'id' => $user_id,
                'total_actions' => 0,
                'approved_actions' => 0,
                'coins' => 0,
                'recent_actions' => [],
                'action_frequency' => []
            ];
        }
    }
    
    /**
     * Calculate action frequency for user
     */
    private function calculateActionFrequency($actions) {
        $frequency = [];
        foreach ($actions as $action) {
            $action_name = $action['name'];
            if (!isset($frequency[$action_name])) {
                $frequency[$action_name] = 0;
            }
            $frequency[$action_name]++;
        }
        return $frequency;
    }
    
    /**
     * Get time-based suggestions
     */
    private function getTimeBasedSuggestions() {
        $hour = (int)date('H');
        $day_of_week = (int)date('w');
        $suggestions = [];
        
        // Morning suggestions (6-11 AM)
        if ($hour >= 6 && $hour < 12) {
            $suggestions[] = [
                'action' => 'Used Bicycle',
                'title' => '🚴‍♂️ Bike to Work',
                'description' => 'Start your day with a healthy bike ride to work',
                'reason' => 'Perfect morning weather for cycling',
                'priority' => 'high',
                'type' => 'time_based'
            ];
            
            $suggestions[] = [
                'action' => 'Walked to Work',
                'title' => '🚶‍♂️ Walk to Work',
                'description' => 'Enjoy a refreshing morning walk',
                'reason' => 'Great way to start your day',
                'priority' => 'medium',
                'type' => 'time_based'
            ];
        }
        
        // Lunch time suggestions (12-2 PM)
        if ($hour >= 12 && $hour < 14) {
            $suggestions[] = [
                'action' => 'Bought Local Products',
                'title' => '🛒 Buy Local Lunch',
                'description' => 'Support local businesses for lunch',
                'reason' => 'Lunch time is perfect for local shopping',
                'priority' => 'medium',
                'type' => 'time_based'
            ];
        }
        
        // Evening suggestions (6-9 PM)
        if ($hour >= 18 && $hour < 21) {
            $suggestions[] = [
                'action' => 'Used LED Bulbs',
                'title' => '💡 Switch to LED Lighting',
                'description' => 'Replace old bulbs with energy-efficient LEDs',
                'reason' => 'Evening is the best time to check your lighting',
                'priority' => 'medium',
                'type' => 'time_based'
            ];
        }
        
        // Weekend suggestions
        if ($day_of_week == 0 || $day_of_week == 6) {
            $suggestions[] = [
                'action' => 'Planted a Tree',
                'title' => '🌳 Plant a Tree',
                'description' => 'Perfect weekend activity for the environment',
                'reason' => 'Weekend is ideal for gardening activities',
                'priority' => 'high',
                'type' => 'time_based'
            ];
            
            $suggestions[] = [
                'action' => 'Composted',
                'title' => '♻️ Start Composting',
                'description' => 'Set up a composting system in your garden',
                'reason' => 'Weekend project for sustainable living',
                'priority' => 'medium',
                'type' => 'time_based'
            ];
        }
        
        return $suggestions;
    }
    
    /**
     * Get behavior-based suggestions
     */
    private function getBehaviorBasedSuggestions($user_profile) {
        $suggestions = [];
        $action_frequency = $user_profile['action_frequency'];
        $total_actions = $user_profile['total_actions'];
        
        // Suggest actions user hasn't tried yet
        $all_actions = $this->getAllEcoActions();
        $user_actions = array_keys($action_frequency);
        
        foreach ($all_actions as $action) {
            if (!in_array($action['name'], $user_actions)) {
                $suggestions[] = [
                    'action' => $action['name'],
                    'title' => '🆕 Try ' . $action['name'],
                    'description' => 'You haven\'t tried this eco action yet',
                    'reason' => 'New action to diversify your eco habits',
                    'priority' => 'high',
                    'type' => 'behavior_based'
                ];
            }
        }
        
        // Suggest more of actions user does frequently
        foreach ($action_frequency as $action_name => $frequency) {
            if ($frequency >= 3) { // User does this action regularly
                $suggestions[] = [
                    'action' => $action_name,
                    'title' => '🔄 Continue ' . $action_name,
                    'description' => 'Keep up your great eco habit',
                    'reason' => 'You\'re doing great with this action',
                    'priority' => 'medium',
                    'type' => 'behavior_based'
                ];
            }
        }
        
        // Suggest high-value actions for users with few actions
        if ($total_actions < 5) {
            $suggestions[] = [
                'action' => 'Planted a Tree',
                'title' => '🌳 Plant a Tree (High Value)',
                'description' => 'Get 50 coins for this impactful action',
                'reason' => 'High-value action to boost your coin balance',
                'priority' => 'high',
                'type' => 'behavior_based'
            ];
        }
        
        return $suggestions;
    }
    
    /**
     * Get location-based suggestions
     */
    private function getLocationBasedSuggestions($location, $weather) {
        $suggestions = [];
        
        // Weather-based suggestions
        if ($weather) {
            if ($weather['condition'] === 'sunny' || $weather['condition'] === 'clear') {
                $suggestions[] = [
                    'action' => 'Used Bicycle',
                    'title' => '☀️ Perfect Day for Cycling',
                    'description' => 'Sunny weather is ideal for bike riding',
                    'reason' => 'Great weather in ' . $location,
                    'priority' => 'high',
                    'type' => 'location_based'
                ];
            }
            
            if ($weather['condition'] === 'rainy') {
                $suggestions[] = [
                    'action' => 'Used Public Transport',
                    'title' => '🌧️ Use Public Transport',
                    'description' => 'Stay dry while being eco-friendly',
                    'reason' => 'Rainy weather in ' . $location,
                    'priority' => 'high',
                    'type' => 'location_based'
                ];
            }
        }
        
        // City-specific suggestions
        if (strpos(strtolower($location), 'city') !== false || strpos(strtolower($location), 'urban') !== false) {
            $suggestions[] = [
                'action' => 'Used Public Transport',
                'title' => '🚌 City Public Transport',
                'description' => 'Take advantage of city public transport',
                'reason' => 'Urban area with good public transport',
                'priority' => 'medium',
                'type' => 'location_based'
            ];
        }
        
        return $suggestions;
    }
    
    /**
     * Get trending suggestions based on community activity
     */
    private function getTrendingSuggestions() {
        try {
            $stmt = $this->pdo->query("
                SELECT ea.name, COUNT(ua.id) as action_count
                FROM user_actions ua
                JOIN eco_actions ea ON ua.action_id = ea.id
                WHERE ua.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                AND ua.status = 'approved'
                GROUP BY ea.name
                ORDER BY action_count DESC
                LIMIT 3
            ");
            $trending = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $suggestions = [];
            foreach ($trending as $trend) {
                $suggestions[] = [
                    'action' => $trend['name'],
                    'title' => '🔥 Trending: ' . $trend['name'],
                    'description' => 'Popular action this week (' . $trend['action_count'] . ' people did this)',
                    'reason' => 'Trending in the community',
                    'priority' => 'medium',
                    'type' => 'trending'
                ];
            }
            
            return $suggestions;
        } catch (PDOException $e) {
            return [];
        }
    }
    
    /**
     * Rank suggestions by relevance
     */
    private function rankSuggestions($suggestions, $user_profile) {
        $scored_suggestions = [];
        
        foreach ($suggestions as $suggestion) {
            $score = 0;
            
            // Priority scoring
            switch ($suggestion['priority']) {
                case 'high': $score += 10; break;
                case 'medium': $score += 5; break;
                case 'low': $score += 1; break;
            }
            
            // Type scoring
            switch ($suggestion['type']) {
                case 'behavior_based': $score += 8; break;
                case 'time_based': $score += 6; break;
                case 'location_based': $score += 7; break;
                case 'trending': $score += 4; break;
            }
            
            // User experience scoring
            if ($user_profile['total_actions'] < 5) {
                // New users get higher scores for easy actions
                if (strpos($suggestion['action'], 'Bottle') !== false || 
                    strpos($suggestion['action'], 'LED') !== false) {
                    $score += 5;
                }
            }
            
            $suggestion['score'] = $score;
            $scored_suggestions[] = $suggestion;
        }
        
        // Sort by score (highest first)
        usort($scored_suggestions, function($a, $b) {
            return $b['score'] <=> $a['score'];
        });
        
        return $scored_suggestions;
    }
    
    /**
     * Get all available eco actions
     */
    private function getAllEcoActions() {
        try {
            $stmt = $this->pdo->query("SELECT * FROM eco_actions ORDER BY coin_value DESC");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
    
    /**
     * Get user location (mock implementation)
     */
    private function getUserLocation($user_id) {
        // In a real implementation, you'd get this from user profile or IP geolocation
        return 'New York City'; // Mock location
    }
    
    /**
     * Get weather data (mock implementation)
     */
    private function getWeatherData($location) {
        // In a real implementation, you'd call a weather API
        return [
            'condition' => 'sunny',
            'temperature' => 22,
            'humidity' => 60
        ];
    }
    
    /**
     * Get default suggestions when AI fails
     */
    private function getDefaultSuggestions($limit) {
        return [
            [
                'action' => 'Used Bicycle',
                'title' => '🚴‍♂️ Ride a Bike',
                'description' => 'Eco-friendly transportation',
                'reason' => 'Great for the environment',
                'priority' => 'medium',
                'type' => 'default'
            ],
            [
                'action' => 'Used Reusable Bottle',
                'title' => '🍶 Use Reusable Bottle',
                'description' => 'Reduce plastic waste',
                'reason' => 'Easy daily habit',
                'priority' => 'high',
                'type' => 'default'
            ],
            [
                'action' => 'Recycled Plastic',
                'title' => '♻️ Recycle Plastic',
                'description' => 'Proper waste disposal',
                'reason' => 'Important for sustainability',
                'priority' => 'medium',
                'type' => 'default'
            ]
        ];
    }
}

// Usage example:
/*
require_once '../config/db.php';
$suggestions = new SmartSuggestions($pdo);

// Get personalized suggestions for user
$user_suggestions = $suggestions->getPersonalizedSuggestions(1, 5);
foreach ($user_suggestions as $suggestion) {
    echo $suggestion['title'] . ": " . $suggestion['description'] . "\n";
}
*/
?>
