<?php
/**
 * AI-Powered Photo Verification System
 * Uses Google Vision API to verify eco-action photos
 */

class PhotoVerification {
    private $pdo;
    private $google_vision_api_key;
    private $verification_threshold = 0.7; // Confidence threshold
    
    public function __construct($pdo, $api_key = null) {
        $this->pdo = $pdo;
        
        // Load AI configuration
        require_once __DIR__ . '/../config/ai_config.php';
        
        $this->google_vision_api_key = $api_key ?: getAIConfig('google_vision_api_key');
        $this->verification_threshold = getAIConfig('photo_verification_threshold') ?: 0.7;
    }
    
    /**
     * Verify photo using Google Vision API
     */
    public function verifyPhoto($photo_path, $expected_action) {
        if (!$this->google_vision_api_key) {
            return $this->fallbackVerification($photo_path, $expected_action);
        }
        
        try {
            // Resolve potentially relative paths (e.g., "assets/uploads/...") to absolute path
            $resolved_path = $this->resolvePhotoPath($photo_path);
            if (!file_exists($resolved_path)) {
                // Fall back early if file cannot be found
                return ['verified' => false, 'confidence' => 0, 'reason' => 'Photo file not found: ' . $photo_path];
            }

            $image_data = file_get_contents($resolved_path);
            $base64_image = base64_encode($image_data);
            
            $response = $this->callGoogleVisionAPI($base64_image);
            
            if ($response) {
                return $this->analyzeVisionResponse($response, $expected_action);
            }
            
            return $this->fallbackVerification($photo_path, $expected_action);
        } catch (Exception $e) {
            error_log("Photo verification error: " . $e->getMessage());
            return $this->fallbackVerification($photo_path, $expected_action);
        }
    }

    /**
     * Resolve a given photo path to an absolute filesystem path
     */
    private function resolvePhotoPath($photo_path) {
        // If already absolute (Windows drive or UNC), return as-is
        if (preg_match('/^[A-Za-z]:\\\\|^\\\\\\\\/', $photo_path)) {
            return $photo_path;
        }

        // Normalize directory separators
        $normalized = str_replace(['\\\
'], ['/'
        ], $photo_path);

        // Build from project root (one level up from this file's directory)
        $base_dir = realpath(__DIR__ . '/..');
        if ($base_dir === false) {
            $base_dir = dirname(__DIR__);
        }

        $candidate = $base_dir . '/' . ltrim($normalized, '/');
        $real = realpath($candidate);
        return $real ?: $candidate;
    }
    
    /**
     * Call Google Vision API
     */
    private function callGoogleVisionAPI($base64_image) {
        $url = 'https://vision.googleapis.com/v1/images:annotate?key=' . $this->google_vision_api_key;

        $payload = [
            'requests' => [
                [
                    'image' => [
                        'content' => $base64_image
                    ],
                    'features' => [
                        [
                            'type' => 'LABEL_DETECTION',
                            'maxResults' => 10
                        ],
                        [
                            'type' => 'OBJECT_LOCALIZATION',
                            'maxResults' => 10
                        ],
                        [
                            'type' => 'TEXT_DETECTION',
                            'maxResults' => 5
                        ]
                    ]
                ]
            ]
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
        ]);

        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr = curl_error($ch);
        curl_close($ch);

        if ($result === false || $httpCode >= 400) {
            // Log and return null so caller can fallback gracefully
            error_log('Google Vision API request failed. HTTP ' . $httpCode . ' Error: ' . ($curlErr ?: $result));
            return null;
        }

        return json_decode($result, true);
    }
    
    /**
     * Analyze Google Vision API response
     */
    private function analyzeVisionResponse($response, $expected_action) {
        if (!isset($response['responses'][0])) {
            return ['verified' => false, 'confidence' => 0, 'reason' => 'No response from API'];
        }
        
        $annotations = $response['responses'][0];
        $labels = $annotations['labelAnnotations'] ?? [];
        $objects = $annotations['localizedObjectAnnotations'] ?? [];
        $text = $annotations['textAnnotations'] ?? [];
        
        $expected_action = strtolower($expected_action);
        $confidence = 0;
        $matched_elements = [];
        
        // Check labels
        foreach ($labels as $label) {
            $label_name = strtolower($label['description']);
            $label_confidence = $label['score'];
            
            if ($this->isActionMatch($label_name, $expected_action)) {
                $confidence = max($confidence, $label_confidence);
                $matched_elements[] = $label_name;
            }
        }
        
        // Check objects
        foreach ($objects as $object) {
            $object_name = strtolower($object['name']);
            $object_confidence = $object['score'];
            
            if ($this->isActionMatch($object_name, $expected_action)) {
                $confidence = max($confidence, $object_confidence);
                $matched_elements[] = $object_name;
            }
        }
        
        // Check text for relevant keywords
        foreach ($text as $text_annotation) {
            $text_content = strtolower($text_annotation['description']);
            if ($this->isActionMatch($text_content, $expected_action)) {
                $confidence = max($confidence, 0.6); // Lower confidence for text
                $matched_elements[] = 'text: ' . substr($text_content, 0, 50);
            }
        }
        
        $verified = $confidence >= $this->verification_threshold;
        
        return [
            'verified' => $verified,
            'confidence' => round($confidence, 2),
            'matched_elements' => $matched_elements,
            'reason' => $verified ? 'Photo verified by AI' : 'Photo does not match expected action'
        ];
    }
    
    /**
     * Check if detected elements match expected action
     */
    private function isActionMatch($detected, $expected) {
        $action_keywords = [
            'used bicycle' => ['bicycle', 'bike', 'cycling', 'cyclist', 'bicycle wheel', 'bike frame'],
            'used public transport' => ['bus', 'train', 'metro', 'subway', 'public transport', 'transit'],
            'planted a tree' => ['tree', 'plant', 'sapling', 'forest', 'garden', 'planting', 'soil'],
            'recycled plastic' => ['plastic', 'bottle', 'recycling', 'bin', 'waste', 'container'],
            'used reusable bottle' => ['bottle', 'water bottle', 'reusable', 'container', 'drink'],
            'carpooled' => ['car', 'vehicle', 'automobile', 'multiple people', 'passengers'],
            'walked to work' => ['person', 'walking', 'pedestrian', 'sidewalk', 'street'],
            'used led bulbs' => ['light', 'bulb', 'lamp', 'illumination', 'lighting'],
            'composted' => ['compost', 'organic', 'food waste', 'decomposition', 'garden'],
            'bought local products' => ['shopping', 'store', 'market', 'food', 'products']
        ];
        
        $keywords = $action_keywords[$expected] ?? [];
        
        foreach ($keywords as $keyword) {
            if (strpos($detected, $keyword) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Fallback verification when API is not available
     */
    private function fallbackVerification($photo_path, $expected_action) {
        // Basic file validation
        if (!file_exists($photo_path)) {
            return ['verified' => false, 'confidence' => 0, 'reason' => 'Photo file not found'];
        }
        
        // Check file size (should be reasonable)
        $file_size = filesize($photo_path);
        if ($file_size < 1000 || $file_size > 10000000) { // 1KB to 10MB
            return ['verified' => false, 'confidence' => 0, 'reason' => 'Invalid photo file size'];
        }
        
        // Check if it's a valid image
        $image_info = getimagesize($photo_path);
        if (!$image_info) {
            return ['verified' => false, 'confidence' => 0, 'reason' => 'Invalid image file'];
        }
        
        // Basic approval for valid images (manual review required)
        return [
            'verified' => true,
            'confidence' => 0.5,
            'reason' => 'Photo appears valid - manual review recommended',
            'requires_manual_review' => true
        ];
    }
    
    /**
     * Batch verify multiple photos
     */
    public function batchVerifyPhotos($photos) {
        $results = [];
        
        foreach ($photos as $photo) {
            $results[] = [
                'photo_id' => $photo['id'],
                'verification' => $this->verifyPhoto($photo['path'], $photo['action'])
            ];
        }
        
        return $results;
    }
    
    /**
     * Get verification statistics
     */
    public function getVerificationStats() {
        try {
            $stmt = $this->pdo->query("
                SELECT 
                    COUNT(*) as total_photos,
                    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_photos,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_photos,
                    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_photos
                FROM user_actions 
                WHERE photo_path IS NOT NULL
            ");
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [
                'total_photos' => 0,
                'approved_photos' => 0,
                'pending_photos' => 0,
                'rejected_photos' => 0
            ];
        }
    }
    
    /**
     * Auto-verify photos with high confidence
     */
    public function autoVerifyHighConfidencePhotos() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT ua.id, ua.photo_path, ea.name as action_name
                FROM user_actions ua
                JOIN eco_actions ea ON ua.action_id = ea.id
                WHERE ua.status = 'pending' AND ua.photo_path IS NOT NULL
            ");
            $stmt->execute();
            $pending_actions = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $auto_approved = 0;
            $manual_review = 0;
            
            foreach ($pending_actions as $action) {
                $verification = $this->verifyPhoto($action['photo_path'], $action['action_name']);
                
                if ($verification['verified'] && $verification['confidence'] >= 0.8) {
                    // Auto-approve high confidence photos
                    $this->approveAction($action['id'], $verification);
                    $auto_approved++;
                } elseif ($verification['verified'] && $verification['confidence'] >= 0.6) {
                    // Flag for manual review
                    $this->flagForManualReview($action['id'], $verification);
                    $manual_review++;
                }
            }
            
            return [
                'auto_approved' => $auto_approved,
                'manual_review' => $manual_review,
                'total_processed' => count($pending_actions)
            ];
        } catch (PDOException $e) {
            return [
                'auto_approved' => 0,
                'manual_review' => 0,
                'total_processed' => 0,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Approve action with verification data
     */
    private function approveAction($action_id, $verification) {
        try {
            $stmt = $this->pdo->prepare("
                UPDATE user_actions 
                SET status = 'approved', 
                    coins_awarded = (SELECT coin_value FROM eco_actions ea 
                                   JOIN user_actions ua ON ea.id = ua.action_id 
                                   WHERE ua.id = ?)
                WHERE id = ?
            ");
            $stmt->execute([$action_id, $action_id]);
            
            // Update user coins
            $stmt = $this->pdo->prepare("
                UPDATE users 
                SET coins = coins + (SELECT coin_value FROM eco_actions ea 
                                   JOIN user_actions ua ON ea.id = ua.action_id 
                                   WHERE ua.id = ?)
                WHERE id = (SELECT user_id FROM user_actions WHERE id = ?)
            ");
            $stmt->execute([$action_id, $action_id]);
            
            // Log verification
            $this->logVerification($action_id, $verification, 'auto_approved');
            
        } catch (PDOException $e) {
            error_log("Error approving action: " . $e->getMessage());
        }
    }
    
    /**
     * Flag action for manual review
     */
    private function flagForManualReview($action_id, $verification) {
        try {
            $stmt = $this->pdo->prepare("
                UPDATE user_actions 
                SET status = 'pending_review'
                WHERE id = ?
            ");
            $stmt->execute([$action_id]);
            
            // Log verification
            $this->logVerification($action_id, $verification, 'manual_review');
            
        } catch (PDOException $e) {
            error_log("Error flagging action for review: " . $e->getMessage());
        }
    }
    
    /**
     * Log verification results
     */
    private function logVerification($action_id, $verification, $status) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO verification_logs (action_id, verified, confidence, reason, status, created_at)
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $action_id,
                $verification['verified'] ? 1 : 0,
                $verification['confidence'],
                $verification['reason'],
                $status
            ]);
        } catch (PDOException $e) {
            error_log("Error logging verification: " . $e->getMessage());
        }
    }
}

// Usage example:
/*
require_once '../config/db.php';
$photo_verifier = new PhotoVerification($pdo, 'YOUR_GOOGLE_VISION_API_KEY');

// Verify a single photo
$result = $photo_verifier->verifyPhoto('uploads/bike_photo.jpg', 'Used Bicycle');
echo "Verified: " . ($result['verified'] ? 'Yes' : 'No');
echo "Confidence: " . $result['confidence'];

// Auto-verify pending photos
$stats = $photo_verifier->autoVerifyHighConfidencePhotos();
echo "Auto-approved: " . $stats['auto_approved'];
echo "Manual review: " . $stats['manual_review'];
*/
?>
