<?php
/**
 * AI-Powered Eco Guidance Chatbot
 * Provides 24/7 AI assistance for eco tips, action guidance, and support
 */

class EcoChatbot {
    private $pdo;
    private $openai_api_key;
    
    public function __construct($pdo, $api_key = null) {
        $this->pdo = $pdo;
        
        // Load AI configuration
        require_once __DIR__ . '/../config/ai_config.php';
        
        $this->openai_api_key = $api_key ?: getAIConfig('openai_api_key');
    }
    
    /**
     * Process user message and generate AI response
     */
    public function processMessage($user_message, $user_id = null, $conversation_id = null) {
        try {
            // Get user context if available
            $user_context = $user_id ? $this->getUserContext($user_id) : null;
            
            // Determine message intent
            $intent = $this->classifyIntent($user_message);
            
            // Generate appropriate response
            $response = $this->generateResponse($user_message, $intent, $user_context);
            
            // Save conversation if conversation_id provided
            if ($conversation_id) {
                $this->saveConversation($conversation_id, $user_message, $response, $user_id);
            }
            
            return [
                'success' => true,
                'response' => $response,
                'intent' => $intent,
                'suggestions' => $this->getQuickSuggestions($intent)
            ];
            
        } catch (Exception $e) {
            error_log("Chatbot error: " . $e->getMessage());
            return [
                'success' => false,
                'response' => 'Sorry, I encountered an error. Please try again later.',
                'intent' => 'error',
                'suggestions' => []
            ];
        }
    }
    
    /**
     * Classify user message intent
     */
    private function classifyIntent($message) {
        $message = strtolower($message);
        
        // Eco action guidance
        if (preg_match('/\b(bike|bicycle|cycling|ride)\b/', $message)) {
            return 'bike_guidance';
        }
        if (preg_match('/\b(bus|train|metro|public transport|transit)\b/', $message)) {
            return 'transport_guidance';
        }
        if (preg_match('/\b(tree|plant|planting|garden)\b/', $message)) {
            return 'tree_guidance';
        }
        if (preg_match('/\b(recycle|recycling|waste|plastic)\b/', $message)) {
            return 'recycle_guidance';
        }
        if (preg_match('/\b(bottle|water|reusable)\b/', $message)) {
            return 'bottle_guidance';
        }
        
        // General eco questions
        if (preg_match('/\b(eco|environment|green|sustainable|climate)\b/', $message)) {
            return 'eco_general';
        }
        if (preg_match('/\b(coins|points|rewards|earn)\b/', $message)) {
            return 'coins_help';
        }
        if (preg_match('/\b(how|what|why|when|where)\b/', $message)) {
            return 'question';
        }
        if (preg_match('/\b(help|support|problem|issue)\b/', $message)) {
            return 'help';
        }
        if (preg_match('/\b(hello|hi|hey|greetings)\b/', $message)) {
            return 'greeting';
        }
        
        return 'general';
    }
    
    /**
     * Generate AI response based on intent
     */
    private function generateResponse($message, $intent, $user_context) {
        switch ($intent) {
            case 'bike_guidance':
                return $this->getBikeGuidance($message, $user_context);
            case 'transport_guidance':
                return $this->getTransportGuidance($message, $user_context);
            case 'tree_guidance':
                return $this->getTreeGuidance($message, $user_context);
            case 'recycle_guidance':
                return $this->getRecycleGuidance($message, $user_context);
            case 'bottle_guidance':
                return $this->getBottleGuidance($message, $user_context);
            case 'eco_general':
                return $this->getEcoGeneralResponse($message, $user_context);
            case 'coins_help':
                return $this->getCoinsHelp($message, $user_context);
            case 'question':
                return $this->getQuestionResponse($message, $user_context);
            case 'help':
                return $this->getHelpResponse($message, $user_context);
            case 'greeting':
                return $this->getGreetingResponse($message, $user_context);
            default:
                return $this->getGeneralResponse($message, $user_context);
        }
    }
    
    /**
     * Get bike guidance response
     */
    private function getBikeGuidance($message, $user_context) {
        $responses = [
            "🚴‍♂️ Great choice! Biking is one of the most eco-friendly ways to get around. You'll earn 10 GreenCoins for each bike trip you log!",
            "🚴‍♀️ Biking is fantastic for the environment and your health! Make sure to wear a helmet and follow traffic rules. You can earn 10 coins per trip!",
            "🚴‍♂️ Awesome! Biking reduces CO2 emissions significantly. Don't forget to take a photo of your bike to verify your eco action and earn 10 GreenCoins!"
        ];
        
        $tips = [
            "💡 Tip: Check your bike's tire pressure regularly for better efficiency",
            "💡 Tip: Use bike lanes when available for safety",
            "💡 Tip: Consider using a bike lock to secure your bicycle"
        ];
        
        $response = $responses[array_rand($responses)];
        $response .= "\n\n" . $tips[array_rand($tips)];
        
        if ($user_context && $user_context['coins'] < 50) {
            $response .= "\n\n🎯 You're close to earning more rewards! Keep up the great work!";
        }
        
        return $response;
    }
    
    /**
     * Get transport guidance response
     */
    private function getTransportGuidance($message, $user_context) {
        $responses = [
            "🚌 Excellent! Public transport is much more eco-friendly than driving alone. You'll earn 5 GreenCoins for each public transport trip!",
            "🚇 Great choice! Using public transport reduces traffic congestion and emissions. Don't forget to log your trip for 5 GreenCoins!",
            "🚌 Smart move! Public transport is efficient and environmentally friendly. You can earn 5 coins per trip when you verify your journey!"
        ];
        
        $tips = [
            "💡 Tip: Check schedules in advance to plan your journey",
            "💡 Tip: Consider getting a monthly pass for regular commuters",
            "💡 Tip: Use apps to track real-time arrivals"
        ];
        
        $response = $responses[array_rand($responses)];
        $response .= "\n\n" . $tips[array_rand($tips)];
        
        return $response;
    }
    
    /**
     * Get tree guidance response
     */
    private function getTreeGuidance($message, $user_context) {
        $responses = [
            "🌳 Amazing! Tree planting is one of the most impactful eco actions. You'll earn 50 GreenCoins for planting a tree!",
            "🌲 Fantastic! Trees absorb CO2 and provide oxygen. This high-value action gives you 50 GreenCoins!",
            "🌳 Wonderful! Tree planting helps combat climate change. You can earn 50 coins for this impactful action!"
        ];
        
        $tips = [
            "💡 Tip: Choose native species for your area",
            "💡 Tip: Plant in spring or fall for best results",
            "💡 Tip: Water regularly during the first year",
            "💡 Tip: Consider joining local tree planting events"
        ];
        
        $response = $responses[array_rand($responses)];
        $response .= "\n\n" . $tips[array_rand($tips)];
        
        return $response;
    }
    
    /**
     * Get recycle guidance response
     */
    private function getRecycleGuidance($message, $user_context) {
        $responses = [
            "♻️ Great! Recycling reduces waste and conserves resources. You'll earn 8 GreenCoins for recycling plastic!",
            "♻️ Excellent! Proper recycling helps the environment. Don't forget to rinse containers before recycling for 8 coins!",
            "♻️ Awesome! Recycling is easy and impactful. You can earn 8 GreenCoins for each recycling action you verify!"
        ];
        
        $tips = [
            "💡 Tip: Rinse containers before recycling",
            "💡 Tip: Check your local recycling guidelines",
            "💡 Tip: Remove labels and caps when possible",
            "💡 Tip: Consider reducing plastic use altogether"
        ];
        
        $response = $responses[array_rand($responses)];
        $response .= "\n\n" . $tips[array_rand($tips)];
        
        return $response;
    }
    
    /**
     * Get bottle guidance response
     */
    private function getBottleGuidance($message, $user_context) {
        $responses = [
            "🍶 Smart choice! Reusable bottles reduce plastic waste. You'll earn 3 GreenCoins for using a reusable bottle!",
            "🍶 Excellent! Reusable bottles are eco-friendly and cost-effective. You can earn 3 coins each time you use one!",
            "🍶 Great habit! Reusable bottles help reduce single-use plastic. Don't forget to log your usage for 3 GreenCoins!"
        ];
        
        $tips = [
            "💡 Tip: Choose stainless steel or glass bottles",
            "💡 Tip: Clean your bottle regularly",
            "💡 Tip: Keep it with you to avoid buying bottled water",
            "💡 Tip: Consider insulated bottles for hot/cold drinks"
        ];
        
        $response = $responses[array_rand($responses)];
        $response .= "\n\n" . $tips[array_rand($tips)];
        
        return $response;
    }
    
    /**
     * Get eco general response
     */
    private function getEcoGeneralResponse($message, $user_context) {
        $responses = [
            "🌱 I'm here to help you with all things eco-friendly! You can earn GreenCoins for various environmental actions.",
            "🌍 Great to see you're interested in environmental sustainability! Let me know how I can help you make a positive impact.",
            "🌿 I love helping people with eco-friendly practices! What specific environmental action would you like to know about?"
        ];
        
        $response = $responses[array_rand($responses)];
        $response .= "\n\n💡 You can ask me about:\n• Biking and transportation\n• Tree planting\n• Recycling\n• Reusable products\n• Earning GreenCoins";
        
        return $response;
    }
    
    /**
     * Get coins help response
     */
    private function getCoinsHelp($message, $user_context) {
        $response = "🪙 GreenCoins are rewards for eco-friendly actions! Here's how it works:\n\n";
        
        if ($user_context) {
            $response .= "💰 Your current balance: " . $user_context['coins'] . " GreenCoins\n\n";
        }
        
        $response .= "📊 Earn coins for:\n";
        $response .= "• 🚴‍♂️ Biking: 10 coins\n";
        $response .= "• 🚌 Public transport: 5 coins\n";
        $response .= "• 🌳 Tree planting: 50 coins\n";
        $response .= "• ♻️ Recycling: 8 coins\n";
        $response .= "• 🍶 Reusable bottle: 3 coins\n\n";
        
        $response .= "🎁 Redeem coins for:\n";
        $response .= "• Discounts at partner stores\n";
        $response .= "• Eco-friendly products\n";
        $response .= "• Gift cards\n";
        $response .= "• And more!";
        
        return $response;
    }
    
    /**
     * Get question response
     */
    private function getQuestionResponse($message, $user_context) {
        $responses = [
            "🤔 That's a great question! Let me help you with that. Could you be more specific about what you'd like to know?",
            "💭 I'd be happy to help! What specific aspect of eco-friendly living are you curious about?",
            "🧠 Interesting question! I'm here to help with all your eco-related inquiries. What would you like to explore?"
        ];
        
        return $responses[array_rand($responses)];
    }
    
    /**
     * Get help response
     */
    private function getHelpResponse($message, $user_context) {
        $response = "🆘 I'm here to help! Here's what I can assist you with:\n\n";
        $response .= "🌱 Eco Action Guidance:\n";
        $response .= "• How to earn GreenCoins\n";
        $response .= "• Tips for eco-friendly living\n";
        $response .= "• Action verification help\n\n";
        $response .= "💬 Just ask me about:\n";
        $response .= "• Biking and transportation\n";
        $response .= "• Tree planting and gardening\n";
        $response .= "• Recycling and waste reduction\n";
        $response .= "• Reusable products\n";
        $response .= "• Your GreenCoin balance\n\n";
        $response .= "What would you like help with?";
        
        return $response;
    }
    
    /**
     * Get greeting response
     */
    private function getGreetingResponse($message, $user_context) {
        $greetings = [
            "👋 Hello! I'm your eco-friendly AI assistant. How can I help you make a positive environmental impact today?",
            "🌱 Hi there! Welcome to GreenCoin! I'm here to help you with all things eco-friendly. What would you like to know?",
            "🌍 Hey! Great to see you! I'm your AI guide for sustainable living. How can I assist you today?"
        ];
        
        $response = $greetings[array_rand($greetings)];
        
        if ($user_context) {
            $response .= "\n\n💰 You currently have " . $user_context['coins'] . " GreenCoins!";
        }
        
        return $response;
    }
    
    /**
     * Get general response
     */
    private function getGeneralResponse($message, $user_context) {
        $responses = [
            "🤖 I'm your eco-friendly AI assistant! I can help you with environmental actions, GreenCoins, and sustainable living tips.",
            "🌿 I'm here to help you with eco-friendly practices and GreenCoin rewards. What would you like to know?",
            "🌱 I can assist you with environmental actions, earning GreenCoins, and sustainable living advice. How can I help?"
        ];
        
        return $responses[array_rand($responses)];
    }
    
    /**
     * Get quick suggestions based on intent
     */
    private function getQuickSuggestions($intent) {
        $suggestions = [
            'bike_guidance' => ['How do I log a bike trip?', 'What safety tips do you have?', 'How many coins do I earn?'],
            'transport_guidance' => ['How do I verify public transport?', 'What counts as public transport?', 'How many coins do I get?'],
            'tree_guidance' => ['Where can I plant trees?', 'What types of trees are best?', 'How do I verify tree planting?'],
            'recycle_guidance' => ['What can I recycle?', 'How do I verify recycling?', 'What about other materials?'],
            'bottle_guidance' => ['What bottles are best?', 'How do I log bottle usage?', 'Any cleaning tips?'],
            'eco_general' => ['What actions can I take?', 'How do I earn more coins?', 'What are the benefits?'],
            'coins_help' => ['How do I check my balance?', 'What can I redeem?', 'How do I earn more?'],
            'default' => ['Tell me about biking', 'How do I earn coins?', 'What eco actions are available?']
        ];
        
        return $suggestions[$intent] ?? $suggestions['default'];
    }
    
    /**
     * Get user context for personalized responses
     */
    private function getUserContext($user_id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT u.coins, COUNT(ua.id) as total_actions
                FROM users u
                LEFT JOIN user_actions ua ON u.id = ua.user_id
                WHERE u.id = ?
                GROUP BY u.id, u.coins
            ");
            $stmt->execute([$user_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return null;
        }
    }
    
    /**
     * Save conversation to database
     */
    private function saveConversation($conversation_id, $user_message, $bot_response, $user_id) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO chatbot_conversations (conversation_id, user_id, user_message, bot_response, created_at)
                VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$conversation_id, $user_id, $user_message, $bot_response]);
        } catch (PDOException $e) {
            error_log("Error saving conversation: " . $e->getMessage());
        }
    }
    
    /**
     * Get conversation history
     */
    public function getConversationHistory($conversation_id, $limit = 10) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT user_message, bot_response, created_at
                FROM chatbot_conversations
                WHERE conversation_id = ?
                ORDER BY created_at DESC
                LIMIT ?
            ");
            $stmt->execute([$conversation_id, $limit]);
            return array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));
        } catch (PDOException $e) {
            return [];
        }
    }
}

// Usage example:
/*
require_once '../config/db.php';
$chatbot = new EcoChatbot($pdo, 'YOUR_OPENAI_API_KEY');

// Process a message
$response = $chatbot->processMessage('How do I earn coins for biking?', 1, 'conv_123');
echo $response['response'];

// Get conversation history
$history = $chatbot->getConversationHistory('conv_123');
foreach ($history as $message) {
    echo "User: " . $message['user_message'] . "\n";
    echo "Bot: " . $message['bot_response'] . "\n\n";
}
*/
?>
