
GreenCoin - Simple PHP Edition (Skeleton)

Setup:
1. Copy project to web root (e.g., C:/xampp/htdocs/GreenCoin or /var/www/html/GreenCoin)
2. Create DB and import sql/schema_and_seed.sql
3. Update DB credentials in config/db.php or set DB_* env vars.
4. Register a user, then change role to 'admin' in DB to access admin panel.
5. Open public/index.php in browser.

Landing Page:
- public/index.php is a TailwindCSS + AOS animated landing page.
- Contact form submits to public/contact.php and stores messages in contacts table.


Final: Landing page enhanced with GSAP, VanillaTilt, back-to-top button, navbar scroll behavior.
