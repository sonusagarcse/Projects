<?php
session_start();

// If already logged in → redirect
if (isset($_SESSION['user'])) {
    if ($_SESSION['user']['role'] === 'admin') {
        header("Location: ../admin/index.php");
        exit;
    } else {
        header("Location: dashboard.php");
        exit;
    }
}

$error = "";

// When form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if ($email === "" || $password === "") {
        $error = "Please enter both email and password.";
    } else {
        try {
            // DB Connection
            $pdo = require __DIR__ . '/../config/db.php';
            
            $stmt = $pdo->prepare("SELECT id, name, password, role FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                // Save session
                $_SESSION['user'] = [
                    'id'   => $user['id'],
                    'name' => $user['name'],
                    'role' => $user['role']
                ];
                if ($user['role'] === 'admin') {
                    header("Location: ../admin/index.php");
                    exit;
                } else {
                    header("Location: dashboard.php");
                    exit;
                }
            } else {
                $error = "Invalid email or password.";
            }
        } catch (PDOException $e) {
            $error = "DB error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GreenCoin Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .error-box {
            background-color: #ffe5e5;
            color: #d32f2f;
            border: 1px solid #d32f2f;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 8px;
            font-weight: bold;
        }
  </style>
</head>
<body class="h-screen flex items-center justify-center bg-gradient-to-br from-green-700 via-emerald-600 to-green-500 relative overflow-hidden">

  <!-- Floating eco icons background -->
  <div class="absolute inset-0 opacity-20 pointer-events-none">
    <div class="absolute top-10 left-20 text-6xl">🌱</div>
    <div class="absolute bottom-20 right-24 text-7xl">♻️</div>
    <div class="absolute top-1/2 left-10 text-5xl">🌍</div>
    <div class="absolute bottom-10 left-1/3 text-6xl">☀️</div>
  </div>
  <!-- Login Card -->
  <div class="relative bg-white/10 backdrop-blur-xl p-10 rounded-2xl shadow-2xl w-96 text-white">
      <!-- Error Box -->
      <?php if ($error): ?>
          <div class="error-box"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
    <!-- Logo -->
    <div class="flex flex-col items-center mb-6">
      <svg xmlns="http://www.w3.org/2000/svg" class="w-12 h-12 text-yellow-300" viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="3">
        <path d="M32 2C20 10 10 22 10 36c0 14 10 26 22 26s22-12 22-26C54 22 44 10 32 2z"/>
        <path d="M32 10v44" stroke-linecap="round"/>
      </svg>
      <h1 class="text-2xl font-extrabold mt-2 bg-gradient-to-r from-yellow-300 to-green-200 bg-clip-text text-transparent">
        GreenCoin Login
      </h1>
    </div>

    <!-- Form -->
    <form method="post">
      <div class="mb-5">
        <label class="block mb-2 text-sm font-semibold">Email</label>
        <input type="email" name="email" class="w-full p-3 rounded-lg border border-white/30 bg-white/20 focus:outline-none focus:ring-2 focus:ring-yellow-300" placeholder="you@example.com" required>
      </div>

      <div class="mb-5">
        <label class="block mb-2 text-sm font-semibold">Password</label>
        <div class="relative">
          <input type="password" id="password" name="password" class="w-full p-3 rounded-lg border border-white/30 bg-white/20 focus:outline-none focus:ring-2 focus:ring-yellow-300" placeholder="••••••••" required>
          <button type="button" onclick="togglePassword()" class="absolute inset-y-0 right-3 flex items-center text-sm">👁️</button>
        </div>
      </div>

      <button type="submit"  class="w-full py-3 rounded-lg bg-yellow-300 text-green-900 font-bold shadow-md hover:scale-105 transition">
        🌱 Login
      </button>

      <div class="flex justify-between text-sm mt-4">
        <a href="register.php" class="hover:underline">Create Account</a>
        <a href="#" class="hover:underline">Forgot Password?</a>
      </div>
    </form>
  </div>

  <script>
    function togglePassword() {
      const pass = document.getElementById("password");
      pass.type = pass.type === "password" ? "text" : "password";
    }
    
  </script>
</body>
</html>
