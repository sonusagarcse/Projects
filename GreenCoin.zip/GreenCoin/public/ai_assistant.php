<?php
session_start();
require_once '../config/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$pdo = require_once '../config/db.php';

// Include AI classes
require_once '../ai/carbon_calculator.php';
require_once '../ai/smart_suggestions.php';
require_once '../ai/eco_chatbot.php';

// Initialize AI classes
$carbon_calc = new CarbonCalculator($pdo);
$suggestions = new SmartSuggestions($pdo);
$chatbot = new EcoChatbot($pdo);

// Get user data
$user_id = $_SESSION['user_id'];
$user_co2_data = $carbon_calc->getUserTotalCO2($user_id);
$user_suggestions = $suggestions->getPersonalizedSuggestions($user_id, 5);

// Handle chatbot messages
$chat_response = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['chat_message'])) {
    $chat_message = trim($_POST['chat_message']);
    if (!empty($chat_message)) {
        $conversation_id = $_POST['conversation_id'] ?? 'conv_' . $user_id . '_' . time();
        $chat_response = $chatbot->processMessage($chat_message, $user_id, $conversation_id);
    }
}

// Get conversation history
$conversation_id = $_POST['conversation_id'] ?? 'conv_' . $user_id . '_' . time();
$chat_history = $chatbot->getConversationHistory($conversation_id, 20);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Assistant - GreenCoin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <a href="index.php" class="text-2xl font-bold text-green-600">🌱 GreenCoin</a>
                </div>
                <nav class="hidden md:flex space-x-8">
                    <a href="dashboard.php" class="text-gray-600 hover:text-green-600">Dashboard</a>
                    <a href="ai_assistant.php" class="text-green-600 font-semibold">AI Assistant</a>
                    <a href="profile.php" class="text-gray-600 hover:text-green-600">Profile</a>
                    <a href="logout.php" class="text-gray-600 hover:text-red-600">Logout</a>
                </nav>
            </div>
        </div>
    </header>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-800 mb-2">
                <i class="fas fa-robot text-blue-600"></i> AI Assistant
            </h1>
            <p class="text-gray-600">Your personal eco-friendly AI guide and carbon footprint tracker</p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- AI Chatbot -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4">
                        <i class="fas fa-comments text-blue-600"></i> Eco Chatbot
                    </h2>
                    
                    <!-- Chat Messages -->
                    <div id="chat-messages" class="h-96 overflow-y-auto border rounded-lg p-4 mb-4 bg-gray-50">
                        <?php foreach ($chat_history as $message): ?>
                            <div class="mb-4">
                                <div class="flex items-start">
                                    <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3 mt-1">
                                        <i class="fas fa-user text-blue-600 text-sm"></i>
                                    </div>
                                    <div class="bg-white rounded-lg p-3 shadow-sm max-w-xs">
                                        <p class="text-sm text-gray-800"><?= htmlspecialchars($message['user_message']) ?></p>
                                    </div>
                                </div>
                                
                                <div class="flex items-start justify-end mt-2">
                                    <div class="bg-blue-600 text-white rounded-lg p-3 shadow-sm max-w-xs">
                                        <p class="text-sm"><?= htmlspecialchars($message['bot_response']) ?></p>
                                    </div>
                                    <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center ml-3 mt-1">
                                        <i class="fas fa-robot text-green-600 text-sm"></i>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <?php if ($chat_response): ?>
                            <div class="mb-4">
                                <div class="flex items-start">
                                    <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3 mt-1">
                                        <i class="fas fa-user text-blue-600 text-sm"></i>
                                    </div>
                                    <div class="bg-white rounded-lg p-3 shadow-sm max-w-xs">
                                        <p class="text-sm text-gray-800"><?= htmlspecialchars($_POST['chat_message']) ?></p>
                                    </div>
                                </div>
                                
                                <div class="flex items-start justify-end mt-2">
                                    <div class="bg-blue-600 text-white rounded-lg p-3 shadow-sm max-w-xs">
                                        <p class="text-sm"><?= htmlspecialchars($chat_response['response']) ?></p>
                                    </div>
                                    <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center ml-3 mt-1">
                                        <i class="fas fa-robot text-green-600 text-sm"></i>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Chat Input -->
                    <form method="POST" class="flex space-x-2">
                        <input type="hidden" name="conversation_id" value="<?= htmlspecialchars($conversation_id) ?>">
                        <input type="text" name="chat_message" placeholder="Ask me about eco-friendly actions..." 
                               class="flex-1 border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </form>
                    
                    <!-- Quick Suggestions -->
                    <div class="mt-4">
                        <p class="text-sm text-gray-600 mb-2">Quick questions:</p>
                        <div class="flex flex-wrap gap-2">
                            <button onclick="sendQuickMessage('How do I earn coins for biking?')" 
                                    class="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-gray-200">
                                Biking coins
                            </button>
                            <button onclick="sendQuickMessage('What eco actions can I take?')" 
                                    class="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-gray-200">
                                Eco actions
                            </button>
                            <button onclick="sendQuickMessage('How do I check my carbon footprint?')" 
                                    class="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-gray-200">
                                Carbon footprint
                            </button>
                            <button onclick="sendQuickMessage('What rewards can I get?')" 
                                    class="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-gray-200">
                                Rewards
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="space-y-6">
                <!-- Carbon Footprint -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">
                        <i class="fas fa-leaf text-green-600"></i> Your Carbon Impact
                    </h3>
                    
                    <div class="text-center mb-4">
                        <div class="text-3xl font-bold text-green-600"><?= $user_co2_data['total_co2'] ?> kg</div>
                        <div class="text-sm text-gray-600">CO₂ Saved</div>
                    </div>
                    
                    <div class="space-y-2">
                        <div class="flex justify-between text-sm">
                            <span>Actions Taken:</span>
                            <span class="font-semibold"><?= $user_co2_data['actions_count'] ?></span>
                        </div>
                        <div class="flex justify-between text-sm">
                            <span>Average per Action:</span>
                            <span class="font-semibold"><?= $user_co2_data['actions_count'] > 0 ? round($user_co2_data['total_co2'] / $user_co2_data['actions_count'], 2) : 0 ?> kg</span>
                        </div>
                    </div>
                    
                    <div class="mt-4 p-3 bg-green-50 rounded-lg">
                        <div class="text-sm text-green-800">
                            <i class="fas fa-tree"></i> Equivalent to planting 
                            <strong><?= round($user_co2_data['total_co2'] / 22, 1) ?></strong> trees!
                        </div>
                    </div>
                </div>

                <!-- AI Suggestions -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">
                        <i class="fas fa-lightbulb text-purple-600"></i> AI Suggestions
                    </h3>
                    
                    <div class="space-y-3">
                        <?php foreach ($user_suggestions as $suggestion): ?>
                            <div class="p-3 bg-gray-50 rounded-lg">
                                <div class="flex items-start">
                                    <div class="text-2xl mr-3"><?= $suggestion['title'][0] ?></div>
                                    <div class="flex-1">
                                        <div class="font-semibold text-gray-800 text-sm"><?= htmlspecialchars($suggestion['title']) ?></div>
                                        <div class="text-xs text-gray-600 mt-1"><?= htmlspecialchars($suggestion['description']) ?></div>
                                        <div class="text-xs text-blue-600 mt-1"><?= htmlspecialchars($suggestion['reason']) ?></div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">
                        <i class="fas fa-bolt text-yellow-600"></i> Quick Actions
                    </h3>
                    
                    <div class="space-y-2">
                        <a href="dashboard.php" class="block w-full bg-green-600 text-white text-center py-2 rounded-lg hover:bg-green-700">
                            <i class="fas fa-tachometer-alt mr-2"></i> View Dashboard
                        </a>
                        <a href="actions.php" class="block w-full bg-blue-600 text-white text-center py-2 rounded-lg hover:bg-blue-700">
                            <i class="fas fa-plus mr-2"></i> Add Eco Action
                        </a>
                        <a href="rewards.php" class="block w-full bg-purple-600 text-white text-center py-2 rounded-lg hover:bg-purple-700">
                            <i class="fas fa-gift mr-2"></i> Browse Rewards
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function sendQuickMessage(message) {
            const form = document.querySelector('form');
            const input = form.querySelector('input[name="chat_message"]');
            input.value = message;
            form.submit();
        }
        
        // Auto-scroll to bottom of chat
        document.addEventListener('DOMContentLoaded', function() {
            const chatMessages = document.getElementById('chat-messages');
            chatMessages.scrollTop = chatMessages.scrollHeight;
        });
    </script>
</body>
</html>
