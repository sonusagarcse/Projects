<?php // public/contact.php ?>
<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){ header('Location: index.php'); exit; }
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$message = trim($_POST['message'] ?? '');
if(!$name || !$email || !$message){ die('All fields required.'); }
$pdo = require_once __DIR__.'/../config/db.php';
$stmt = $pdo->prepare('INSERT INTO contacts (name,email,message,created_at) VALUES (?,?,?,NOW())');
$stmt->execute([$name,$email,$message]);
?>
<!doctype html><html><head><meta charset="utf-8"><title>Thanks</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head><body>
<div class="container py-5 text-center"><h2>Thanks — we will be in touch!</h2><p class="mt-3"><a href="index.php" class="btn btn-success">Back to Home</a></p></div></body></html>
