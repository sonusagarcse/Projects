<?php
session_start();
if (empty($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$pdo = require_once __DIR__ . '/../config/db.php';
$rewards = $pdo->query('SELECT * FROM rewards WHERE stock > 0')->fetchAll();

$msg = $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['reward_id'])) {
    $rid = intval($_POST['reward_id']);
    $uid = $_SESSION['user']['id'];

    $r = $pdo->prepare('SELECT * FROM rewards WHERE id=? AND stock > 0');
    $r->execute([$rid]);
    $rdata = $r->fetch();

    if ($rdata) {
        $u = $pdo->prepare('SELECT coins FROM users WHERE id=?');
        $u->execute([$uid]);
        $ud = $u->fetch();

        if ($ud['coins'] >= $rdata['coin_cost']) {
            try {
                $pdo->beginTransaction();
                $pdo->prepare('UPDATE users SET coins = coins - ? WHERE id=?')->execute([$rdata['coin_cost'], $uid]);
                $pdo->prepare('INSERT INTO redemptions (user_id, reward_id, status, created_at) VALUES (?, ?, ?, NOW())')
                    ->execute([$uid, $rid, 'requested']);
                $pdo->prepare('UPDATE rewards SET stock = stock - 1 WHERE id=?')->execute([$rid]);
                $pdo->commit();
                $msg = 'Redeemed successfully.';
            } catch (Exception $e) {
                $pdo->rollBack();
                $err = 'Something went wrong. Please try again.';
            }
        } else {
            $err = 'Not enough coins.';
        }
    } else {
        $err = 'Invalid reward selected.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Rewards</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 min-h-screen flex">

    <!-- Sidebar Html Code -->
    <?php include('../includes/sidebar.php'); ?>

    <!-- Main Content -->
    <main class="flex-1 md:ml-64 p-6">
        <h2 class="text-2xl font-bold mb-4">🎁 Rewards Marketplace</h2>

        <?php if (!empty($msg)) : ?>
            <div class="mb-4 p-3 bg-green-100 text-green-800 rounded"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <?php if (!empty($err)) : ?>
            <div class="mb-4 p-3 bg-red-100 text-red-800 rounded"><?= htmlspecialchars($err) ?></div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($rewards as $r) : ?>
                <div class="bg-white p-5 rounded shadow">
                    <h3 class="text-lg font-semibold mb-2"><?= htmlspecialchars($r['name']) ?></h3>
                    <p class="text-gray-600 mb-2"><?= htmlspecialchars($r['description']) ?></p>
                    <p class="text-green-700 font-semibold mb-3">Cost: <?= (int)$r['coin_cost'] ?> coins</p>
                    <form method="post">
                        <input type="hidden" name="reward_id" value="<?= (int)$r['id'] ?>">
                        <button type="submit"
                            class="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded">Redeem</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <!-- Sidebar toggle script -->
    <?php include('../includes/footer.php'); ?>
</body>

</html>
