<?php
session_start();

// Redirect if already logged in
if (isset($_SESSION['user'])) {
    if ($_SESSION['user']['role'] === 'admin') {
        header("Location: ../admin/index.php");
        exit;
    } else {
        header("Location: dashboard.php");
        exit;
    }
}

$error = "";
$success = "";

// Form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    // Basic validation
    if (!$name || !$email || !$password || !$confirm_password) {
        $error = "Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        try {
            // DB Connection
            $pdo = require __DIR__ . '/../config/db.php';

            // Check if email already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = "Email already registered.";
            } else {
                // Hash password
                $hash = password_hash($password, PASSWORD_DEFAULT);

                // Insert user
                $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
                $stmt->execute([$name, $email, $hash, 'user']);

                header("Location: dashboard.php");
            }

        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GreenCoin Register</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    .error-box {
        background-color: #ffe5e5;
        color: #d32f2f;
        border: 1px solid #d32f2f;
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 8px;
        font-weight: bold;
    }
    .success-box {
        background-color: #e6ffed;
        color: #2e7d32;
        border: 1px solid #2e7d32;
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 8px;
        font-weight: bold;
    }
</style>
</head>
<body class="h-screen flex items-center justify-center bg-gradient-to-br from-green-700 via-emerald-600 to-green-500 relative overflow-hidden">

  <!-- Floating eco icons background -->
  <div class="absolute inset-0 opacity-20 pointer-events-none">
    <div class="absolute top-10 left-20 text-6xl">🌱</div>
    <div class="absolute bottom-20 right-24 text-7xl">♻️</div>
    <div class="absolute top-1/2 left-10 text-5xl">🌍</div>
    <div class="absolute bottom-10 left-1/3 text-6xl">☀️</div>
  </div>

  <!-- Registration Card -->
  <div class="relative bg-white/10 backdrop-blur-xl p-10 rounded-2xl shadow-2xl w-96 text-white">
      <!-- Error Box -->
      <?php if ($error): ?>
          <div class="error-box"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <?php if ($success): ?>
          <div class="success-box"><?= $success ?></div>
      <?php endif; ?>

    <!-- Logo -->
    <div class="flex flex-col items-center mb-6">
      <h1 class="text-2xl font-extrabold mt-2 bg-gradient-to-r from-yellow-300 to-green-200 bg-clip-text text-transparent">
        🌱 GreenCoin Register
      </h1>
    </div>

    <!-- Form -->
    <form method="post">
        <div class="mb-5">
          <label class="block mb-2 text-sm font-semibold">Full Name</label>
          <input type="text" name="name" class="w-full p-3 rounded-lg border border-white/30 bg-white/20 focus:outline-none focus:ring-2 focus:ring-yellow-300" placeholder="John Doe" required>
        </div>

        <div class="mb-5">
          <label class="block mb-2 text-sm font-semibold">Email</label>
          <input type="email" name="email" class="w-full p-3 rounded-lg border border-white/30 bg-white/20 focus:outline-none focus:ring-2 focus:ring-yellow-300" placeholder="you@example.com" required>
        </div>

        <div class="mb-5">
          <label class="block mb-2 text-sm font-semibold">Password</label>
          <input type="password" id="password" name="password" class="w-full p-3 rounded-lg border border-white/30 bg-white/20 focus:outline-none focus:ring-2 focus:ring-yellow-300" placeholder="••••••••" required>
        </div>

        <div class="mb-5">
          <label class="block mb-2 text-sm font-semibold">Confirm Password</label>
          <input type="password" id="confirm_password" name="confirm_password" class="w-full p-3 rounded-lg border border-white/30 bg-white/20 focus:outline-none focus:ring-2 focus:ring-yellow-300" placeholder="••••••••" required>
        </div>

        <button type="submit" class="w-full py-3 rounded-lg bg-yellow-300 text-green-900 font-bold shadow-md hover:scale-105 transition">
          🌱 Sign Up
        </button>

        <div class="flex justify-between text-sm mt-4">
          <a href="login.php" class="hover:underline">Already have an account? Login</a>
        </div>
    </form>
  </div>

</body>
</html>
