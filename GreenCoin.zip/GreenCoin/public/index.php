
<?php
// Database connection
$pdo = require __DIR__ . '/../config/db.php';

// Get active users count (users who have taken at least one action)
$active_users = $pdo->query("
    SELECT COUNT(DISTINCT u.id) as count 
    FROM users u 
    INNER JOIN user_actions ua ON u.id = ua.user_id 
    WHERE ua.status = 'approved'
")->fetchColumn();

// Get tree planting data
$tree_data = $pdo->query("
    SELECT 
        COUNT(CASE WHEN ea.name LIKE '%tree%' OR ea.name LIKE '%plant%' THEN 1 END) as trees_planted,
        SUM(CASE WHEN ea.name LIKE '%tree%' OR ea.name LIKE '%plant%' THEN ea.coin_value ELSE 0 END) as tree_coins
    FROM user_actions ua
    INNER JOIN eco_actions ea ON ua.action_id = ea.id
    WHERE ua.status = 'approved'
")->fetch(PDO::FETCH_ASSOC);

// Get CO2 saved data (estimated based on actions)
$co2_data = $pdo->query("
    SELECT 
        COUNT(CASE WHEN ea.name LIKE '%bicycle%' OR ea.name LIKE '%bike%' THEN 1 END) * 0.5 as bike_co2,
        COUNT(CASE WHEN ea.name LIKE '%transport%' OR ea.name LIKE '%bus%' THEN 1 END) * 0.3 as transport_co2,
        COUNT(CASE WHEN ea.name LIKE '%tree%' OR ea.name LIKE '%plant%' THEN 1 END) * 22 as tree_co2
    FROM user_actions ua
    INNER JOIN eco_actions ea ON ua.action_id = ea.id
    WHERE ua.status = 'approved'
")->fetch(PDO::FETCH_ASSOC);

$total_co2_saved = round(($co2_data['bike_co2'] + $co2_data['transport_co2'] + $co2_data['tree_co2']), 1);

// Get total coins earned by all users
$total_coins = $pdo->query("SELECT SUM(coins) FROM users")->fetchColumn() ?: 0;

// Get total actions taken
$total_actions = $pdo->query("SELECT COUNT(*) FROM user_actions WHERE status = 'approved'")->fetchColumn();

// Get total users registered
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>GreenCoin — Turn Eco Actions Into Rewards</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <style>
    :root {
      --green-600: #16a34a;
      --green-500: #22c55e;
    }

    .btn-cta {
      background: linear-gradient(90deg, var(--green-600), var(--green-500));
      color: white
    }

    .glass {
      background: rgba(255, 255, 255, 0.6);
      backdrop-filter: blur(6px)
    }

    .navbar-top {
      background: transparent;
      transition: all 300ms ease;
    }

    .navbar-scrolled {
      background: white;
      box-shadow: 0 6px 18px rgba(2, 6, 23, 0.08);
      transition: all 300ms ease;
    }

    #backToTop {
      position: fixed;
      right: 20px;
      bottom: 24px;
      z-index: 60;
      display: none;
    }
  </style>
</head>

<body class="bg-gradient-to-br from-emerald-50 to-emerald-100 text-slate-800">

  <nav id="nav" class="navbar-top fixed w-full z-50 bg-transparent transition-colors duration-300">
    <div class="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
      <!-- Logo -->
      <a href="#" class="flex items-center gap-2 text-lg font-semibold">
        🌱 <span class="text-green-700">GreenCoin</span>
         <!-- <img src="../assets/img/EcoNova PNG.png" alt="" height="20px"> -->
      </a>

      <!-- Desktop Menu -->
      <div class="hidden md:flex items-center gap-3">
        <a href="#features" class="text-sm">Features</a>
        <a href="#pricing" class="text-sm">Pricing</a>
        <a href="#contact" class="text-sm">Contact</a>
        <a href="login.php" class="px-3 py-1 rounded border border-green-200 text-sm">Login</a>
        <a href="register.php" class="px-3 py-1 rounded btn-cta text-sm">Sign Up</a>
      </div>

      <!-- Mobile Hamburger -->
      <div class="md:hidden">
        <button id="menu-btn" class="text-green-700 focus:outline-none">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
    </div>

    <!-- Mobile Menu -->
    <div id="mobile-menu" class="hidden md:hidden bg-green-700">
      <a href="#features" class="block px-4 py-2 text-white hover:bg-green-600">Features</a>
      <a href="#pricing" class="block px-4 py-2 text-white hover:bg-green-600">Pricing</a>
      <a href="#contact" class="block px-4 py-2 text-white hover:bg-green-600">Contact</a>
      <a href="login.php" class="block px-4 py-2 text-white hover:bg-green-600">Login</a>
      <a href="register.php" class="block px-4 py-2 text-white hover:bg-green-600">Sign Up</a>
    </div>
  </nav>

  <header class="pt-24 max-w-6xl mx-auto px-4 py-20 flex flex-col md:flex-row items-center gap-8 overflow-hidden">

    <!-- floating icons here start from here  -->

    <div class="absolute inset-0 overflow-hidden pointer-events-none">
      <!-- Floating Icons -->
      <div class="eco-icon absolute text-5xl text-green-300 opacity-30">🌱</div>
      <div class="eco-icon absolute text-6xl text-emerald-400 opacity-20">♻️</div>
      <div class="eco-icon absolute text-5xl text-green-500 opacity-25">🌍</div>
      <div class="eco-icon absolute text-6xl text-yellow-400 opacity-20">☀️</div>
      <div class="eco-icon absolute text-5xl text-blue-400 opacity-20">💧</div>
    </div>


    <div class="md:w-1/2" id="heroText">
      <h1 class="text-4xl md:text-5xl font-extrabold leading-tight">Turn Eco Actions Into Rewards</h1>
      <p class="mt-4 text-slate-700">Log sustainable actions, earn GreenCoins, and redeem rewards from campus partners.
      </p>
      <div class="mt-6 flex gap-3">
        <a href="register.php" class="px-5 py-3 btn-cta rounded-lg shadow transform hover:-translate-y-1 transition">Get
          Started — It's Free</a>
        <a href="#how" class="px-5 py-3 border rounded-lg bg-green-600 text-white hover:bg-green-700">How it works</a>
      </div>
      <div class="mt-8 grid grid-cols-3 gap-4 text-center" id="counters">
        <div class="p-4 glass rounded tilt" data-tilt data-tilt-scale="1.03">
          <div class="text-2xl font-bold" ><?= $tree_data['trees_planted'] ?></div>
          <div class="text-sm text-slate-600">Trees planted</div>
        </div>
        <div class="p-4 glass rounded tilt" data-tilt data-tilt-scale="1.03">
          <div class="text-2xl font-bold" data-target="<?= $total_co2_saved ?>">0</div>
          <div class="text-sm text-slate-600">kg CO₂ saved</div>
        </div>
        <div class="p-4 glass rounded tilt" data-tilt data-tilt-scale="1.03">
          <div class="text-2xl font-bold" ><?= $total_users ?></div>
          <div class="text-sm text-slate-600">Active Users</div>
        </div>
      </div>
    </div>
    <div class="md:w-1/2 flex justify-center" id="heroVisual">
      <img id="coin" src="../assets/img/coin.webp" alt="coin" style="width: 300px; height: 300px;" />
      <!-- <div class="w-96 h-96 rounded-3xl bg-white shadow-xl flex items-center justify-center relative tilt" data-tilt data-tilt-scale="1.02"> -->
      <div class="absolute right-6 top-6 text-xs text-slate-500">Live Wallet</div>
    </div>
    </div>
  </header>

  

  <!-- How Section start from here  -->

  <section id="how" class="bg-gradient-to-b from-green-50 to-white py-20">
    <div class="max-w-6xl mx-auto px-6 text-center">
      <h2
        class="text-3xl md:text-4xl font-extrabold mb-10 bg-clip-text text-transparent bg-gradient-to-r from-green-700 to-emerald-500">
        🌱 How GreenCoin Works
      </h2>

      <div class="grid md:grid-cols-4 gap-8">
        <!-- Step 1 -->
        <div class="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition transform">
          <div class="text-4xl mb-4">♻️</div>
          <h3 class="text-lg font-semibold">Take Eco Actions</h3>
          <p class="mt-2 text-slate-600">Recycle, plant trees, save electricity, use public transport & more.</p>
        </div>

    <!-- Step 2 -->
    <div class="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition transform">
          <div class="text-4xl mb-4">📷</div>
          <h3 class="text-lg font-semibold">Upload Proof</h3>
          <p class="mt-2 text-slate-600">Recycle, plant trees, save electricity, use public transport & more.</p>
        </div>

        <!-- Step 2 -->
        <div class="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition transform">
          <div class="text-4xl mb-4">🎁</div>
          <h3 class="text-lg font-semibold">Earn GreenCoins</h3>
          <p class="mt-2 text-slate-600">Every verified eco action gives you GreenCoin rewards instantly.</p>
        </div>

        <!-- Step 3 -->
        <div class="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition transform">
          <div class="text-4xl mb-4">🏪</div>
          <h3 class="text-lg font-semibold">Spend & Redeem</h3>
          <p class="mt-2 text-slate-600">Redeem GreenCoins on discounts, eco-products, and gift cards.</p>
        </div>

        
      </div>
    </div>
  </section>


  <!-- Features Section from here  -->

  <section id="features" class="bg-gradient-to-r from-emerald-600 via-green-700 to-emerald-800 text-white py-20">
    <div class="max-w-6xl mx-auto px-6 text-center">
      <h2 class="text-3xl md:text-4xl font-extrabold mb-12">
        ✨ Key Features of GreenCoin
      </h2>

      <div class="grid md:grid-cols-3 gap-10">
        <!-- Feature 1 -->
        <div class="bg-white/10 backdrop-blur-lg p-8 rounded-2xl shadow-lg hover:scale-105 transition">
          <div class="text-4xl mb-4">📊</div>
          <h3 class="text-xl font-bold">Real-Time Dashboard</h3>
          <p class="mt-2 opacity-90">Track eco actions, rewards earned, and your sustainability score.</p>
        </div>

        <!-- Feature 2 -->
        <div class="bg-white/10 backdrop-blur-lg p-8 rounded-2xl shadow-lg hover:scale-105 transition">
          <div class="text-4xl mb-4">🔗</div>
          <h3 class="text-xl font-bold">Partner Integration</h3>
          <p class="mt-2 opacity-90">Use GreenCoins at eco-friendly stores, e-commerce, and local partners.</p>
        </div>

        <!-- Feature 3 -->
        <div class="bg-white/10 backdrop-blur-lg p-8 rounded-2xl shadow-lg hover:scale-105 transition">
          <div class="text-4xl mb-4">🪙</div>
          <h3 class="text-xl font-bold">Blockchain Security</h3>
          <p class="mt-2 opacity-90">All transactions are transparent, secure, and tamper-proof.</p>
        </div>

        <!-- Feature 4 -->
        <div class="bg-white/10 backdrop-blur-lg p-8 rounded-2xl shadow-lg hover:scale-105 transition">
          <div class="text-4xl mb-4">🏆</div>
          <h3 class="text-xl font-bold">Gamification</h3>
          <p class="mt-2 opacity-90">Leaderboards, badges & streak rewards keep users motivated.</p>
        </div>

        <!-- Feature 5 -->
        <div class="bg-white/10 backdrop-blur-lg p-8 rounded-2xl shadow-lg hover:scale-105 transition">
          <div class="text-4xl mb-4">🌍</div>
          <h3 class="text-xl font-bold">Carbon Impact Tracker</h3>
          <p class="mt-2 opacity-90">See how much CO₂ you’ve reduced compared to others globally.</p>
        </div>

        <!-- Feature 6 -->
        <div class="bg-white/10 backdrop-blur-lg p-8 rounded-2xl shadow-lg hover:scale-105 transition">
          <div class="text-4xl mb-4">💳</div>
          <h3 class="text-xl font-bold">Easy Payouts</h3>
          <p class="mt-2 opacity-90">Withdraw GreenCoins to PayPal, UPI, or use in our partner network.</p>
        </div>
      </div>
    </div>
  </section>

  <section id="pricing" class="max-w-6xl mx-auto px-4 py-16 text-center relative">
    <h2
      class="text-3xl md:text-4xl font-extrabold bg-gradient-to-r from-green-600 to-emerald-400 bg-clip-text text-transparent">
      Pricing & Monetization</h2>
    <p class="mt-3 text-slate-600">Choose the plan that fits you — whether you’re a student, eco-hero, or a business.
    </p>

    <div class="mt-12 grid md:grid-cols-3 gap-8">

      <!-- Free -->
      <div class="p-8 bg-white rounded-2xl shadow-lg hover:shadow-xl transform hover:-translate-y-2 transition">
        <div class="text-4xl">🎓</div>
        <h3 class="mt-3 text-xl font-bold">Free</h3>
        <p class="text-slate-600">Perfect for individuals starting eco-journeys.</p>
        <p class="mt-4 text-3xl font-extrabold text-green-600">₹0</p>
        <ul class="mt-4 space-y-2 text-sm text-slate-600">
          <li>✔ Track eco-actions</li>
          <li>✔ Earn GreenCoins</li>
          <li>✔ Redeem small rewards</li>
        </ul>
        <a href="register.php" class="mt-6 block w-full btn-cta px-4 py-2 rounded-lg">Get Started</a>
      </div>

      <!-- Premium -->
      <div
        class="p-8 bg-gradient-to-b from-green-600 to-emerald-500 text-white rounded-2xl shadow-xl scale-105 transform hover:-translate-y-2 transition relative">
        <div
          class="absolute -top-3 left-1/2 -translate-x-1/2 bg-yellow-400 text-green-900 text-xs px-3 py-1 rounded-full">
          Most Popular</div>
        <div class="text-4xl">🌱</div>
        <h3 class="mt-3 text-xl font-bold">Premium</h3>
        <p>For eco-heroes who want to maximize rewards.</p>
        <p class="mt-4 text-3xl font-extrabold">₹199<span class="text-sm">/month</span></p>
        <ul class="mt-4 space-y-2 text-sm">
          <li>✔ All Free features</li>
          <li>✔ Bonus GreenCoins</li>
          <li>✔ Exclusive eco-badges</li>
          <li>✔ Early access to campaigns</li>
        </ul>
        <a href="#" class="mt-6 block w-full bg-yellow-400 text-green-800 font-bold px-4 py-2 rounded-lg">Subscribe
          Now</a>
      </div>

      <!-- Business -->
      <div class="p-8 bg-white rounded-2xl shadow-lg hover:shadow-xl transform hover:-translate-y-2 transition">
        <div class="text-4xl">🏢</div>
        <h3 class="mt-3 text-xl font-bold">Business</h3>
        <p class="text-slate-600">For eco-brands, shops, and institutions.</p>
        <p class="mt-4 text-3xl font-extrabold text-green-600">Custom</p>
        <ul class="mt-4 space-y-2 text-sm text-slate-600">
          <li>✔ Promote eco-products</li>
          <li>✔ Access GreenCoin API</li>
          <li>✔ CSR impact reports</li>
          <li>✔ Partner reward integration</li>
        </ul>
        <a href="#contact" class="mt-6 block w-full btn-cta px-4 py-2 rounded-lg">Contact Sales</a>
      </div>

    </div>
  </section>


  <section id="contact" class="bg-gradient-to-b from-slate-50 to-white py-16">
    <div class="max-w-6xl mx-auto px-6 md:px-12">
      <div class="text-center mb-12">
        <h2
          class="text-3xl md:text-4xl font-extrabold bg-gradient-to-r from-green-600 to-emerald-400 bg-clip-text text-transparent">
          Get in Touch
        </h2>
        <p class="mt-3 text-slate-600">Have questions or want to collaborate? We’d love to hear from you.</p>
      </div>

      <div class="grid md:grid-cols-2 gap-10 items-start">

        <!-- Contact Form -->
        <form id="contactForm" class="bg-white rounded-2xl shadow-xl p-8 space-y-6">
          <div>
            <label class="block text-sm font-semibold text-slate-600">Name</label>
            <input type="text" name="name" required
              class="w-full mt-2 p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              placeholder="Your full name">
          </div>

          <div>
            <label class="block text-sm font-semibold text-slate-600">Email</label>
            <input type="email" name="email" required
              class="w-full mt-2 p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              placeholder="you@example.com">
          </div>

          <div>
            <label class="block text-sm font-semibold text-slate-600">Message</label>
            <textarea name="message" required rows="4"
              class="w-full mt-2 p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              placeholder="Write your message..."></textarea>
          </div>

          <button type="submit"
            class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg transition">
            Send Message
          </button>
          <p id="formMessage" class="hidden text-sm mt-3"></p>
        </form>

        <!-- Contact Info -->
        <div class="space-y-6">
          <div class="bg-white p-6 rounded-2xl shadow-lg">
            <h3 class="text-lg font-semibold text-green-600">📍 Office</h3>
            <p class="mt-2 text-slate-600">Lok Kala Vikas Manch, Patna, Bihar</p>
          </div>
          <div class="bg-white p-6 rounded-2xl shadow-lg">
            <h3 class="text-lg font-semibold text-green-600">📧 Email</h3>
            <p class="mt-2 text-slate-600">support@greeneco.com</p>
          </div>
          <div class="bg-white p-6 rounded-2xl shadow-lg">
            <h3 class="text-lg font-semibold text-green-600">📞 Phone</h3>
            <p class="mt-2 text-slate-600">+91 9523012888</p>
          </div>

          <!-- Optional: Google Map Embed -->
          <!-- <iframe class="rounded-2xl shadow-lg w-full h-64" 
          src="https://www.google.com/maps/embed?pb=!1m18!...your-location..." 
          allowfullscreen="" loading="lazy"></iframe> -->
        </div>

      </div>
    </div>
  </section>

  <script>
    // Simple form submission handler
    const form = document.getElementById('contactForm');
    const formMessage = document.getElementById('formMessage');

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      formMessage.classList.remove("hidden");
      formMessage.textContent = "✅ Thank you! Your message has been sent.";
      formMessage.classList.add("text-green-600", "font-semibold");
      form.reset();
    });
  </script>


  <footer class="mt-12 py-8 bg-white/60 glass">
    <div class="max-w-6xl mx-auto px-4 text-center text-sm text-slate-600">© 2025 GreenCoin</div>
  </footer>

  <!-- Back to top button -->
  <button id="backToTop" aria-label="Back to top" class="p-3 rounded-full shadow-lg bg-white/90 hover:scale-105">
    ↑
  </button>

  <!-- Libraries -->
  <script src="https://unpkg.com/vanilla-tilt@1.7.2/dist/vanilla-tilt.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollToPlugin.min.js"></script>

  <script>
    // Init AOS
    AOS.init({ duration: 700, once: true });

    // Init VanillaTilt for elements with class tilt or data-tilt
    VanillaTilt.init(document.querySelectorAll(".tilt"), {
      max: 12, speed: 400, glare: true, "max-glare": 0.15
    });

    // GSAP hero animation
    gsap.from("#heroText h1", { y: 40, opacity: 0, duration: 0.9, ease: "power3.out", delay: 0.1 });
    gsap.from("#heroText p", { y: 30, opacity: 0, duration: 0.8, ease: "power3.out", delay: 0.25 });
    gsap.from("#heroText a", { y: 20, opacity: 0, stagger: 0.08, duration: 0.6, delay: 0.4 });

    // spin the coin slowly
    gsap.to("#coin", { rotation: 360, duration: 10, repeat: -1, ease: "none" });

    // Counters - count up when in view
    const counters = document.querySelectorAll('[data-target]');
    counters.forEach(c => {
      c.innerText = '0';
      let target = +c.getAttribute('data-target');
      const animate = () => {
        let tl = gsap.timeline();
        tl.to(c, { innerText: target, duration: 2.2, ease: "power1.out", snap: { innerText: 1 }, onUpdate: function () { c.innerText = Math.floor(c.innerText); } });
      };
      // trigger when visible using AOS hooks
      c.addEventListener('aos:in', animate);
    });

    // Navbar background change on scroll
    const nav = document.getElementById('nav');
    const backToTop = document.getElementById('backToTop');
    window.addEventListener('scroll', () => {
      if (window.scrollY > 60) {
        nav.classList.add('navbar-scrolled'); nav.classList.remove('navbar-top');
        backToTop.style.display = 'block';
      } else {
        nav.classList.add('navbar-top'); nav.classList.remove('navbar-scrolled');
        backToTop.style.display = 'none';
      }
    });

    // Back to top smooth scroll using GSAP
    backToTop.addEventListener('click', () => {
      gsap.to(window, { duration: 0.8, scrollTo: 0, ease: "power2.out" });
    });

    // Smooth link scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(a => {
      a.addEventListener('click', function (e) {
        e.preventDefault();
        let target = document.querySelector(this.getAttribute('href'));
        if (target) gsap.to(window, { duration: 0.8, scrollTo: target, ease: "power2.out" });
      });
    });


    // Animate floating eco icons
    document.querySelectorAll(".eco-icon").forEach((icon, i) => {
      gsap.fromTo(icon,
        { x: Math.random() * window.innerWidth, y: window.innerHeight + 100 },
        {
          x: "+=" + (Math.random() * 200 - 100),
          y: -100,
          repeat: -1,
          duration: 10 + Math.random() * 10,
          ease: "linear",
          delay: i * 2
        }
      );
    });

    // Toggle mobile menu
    const btn = document.getElementById('menu-btn');
    const menu = document.getElementById('mobile-menu');
    btn.addEventListener('click', () => menu.classList.toggle('hidden'));

    // Navbar background on scroll
    window.addEventListener('scroll', () => {
      const nav = document.getElementById('nav');
      if (window.scrollY > 50) {
        nav.classList.add('bg-white', 'shadow-lg');
        nav.querySelectorAll('a').forEach(a => a.classList.replace('text-green-700', 'text-green-900'));
      } else {
        nav.classList.remove('bg-white', 'shadow-lg');
        nav.querySelectorAll('a').forEach(a => a.classList.replace('text-green-900', 'text-green-700'));
      }
    });

  </script>
  <?php include("tawk.php"); ?>
</body>

</html>