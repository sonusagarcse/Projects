<?php
session_start();
if (empty($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$pdo = require_once __DIR__ . '/../config/db.php';
$acts = $pdo->query('SELECT * FROM eco_actions')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action_id = intval($_POST['action_id'] ?? 0);
    $notes = trim($_POST['notes'] ?? '');
    $user_id = $_SESSION['user']['id'];
    $photo = null;

    if ($action_id > 0) {
        // Handle photo upload
        if (!empty($_FILES['photo']['name'])) {
            $target = __DIR__ . '/../assets/uploads/';
            if (!is_dir($target)) mkdir($target, 0777, true);
            $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $safeName = time() . '_' . uniqid() . '.' . $ext;
            $filePath = $target . $safeName;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $filePath)) {
                $photo = 'assets/uploads/' . $safeName;
            }
        }

        // Insert user action
        $stmt = $pdo->prepare('INSERT INTO user_actions (user_id, action_id, photo_path, notes, status, coins_awarded, created_at) 
                               VALUES (?, ?, ?, ?, ?, 0, NOW())');
        $stmt->execute([$user_id, $action_id, $photo, $notes, 'pending']);

        header('Location: dashboard.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Log Eco Action</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 min-h-screen flex">

    <!-- Sidebar Include -->
    <?php include('../includes/sidebar.php'); ?>

    <!-- Main Content -->
    <main class="flex-1 md:ml-64 p-6">
        <h2 class="text-2xl font-bold mb-4">➕ Log Eco Action</h2>

        <form method="post" enctype="multipart/form-data" class="bg-white shadow rounded p-6 max-w-xl">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Select Action:</label>
                <select name="action_id" class="w-full p-2 border rounded" required>
                    <option value="">-- Choose an Action --</option>
                    <?php foreach ($acts as $a): ?>
                        <option value="<?= $a['id'] ?>">
                            <?= htmlspecialchars($a['name']) ?> (<?= $a['coin_value'] ?> coins)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Upload Photo (optional):</label>
                <input type="file" name="photo" class="w-full border rounded p-2">
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Notes (optional):</label>
                <textarea name="notes" class="w-full border rounded p-2" rows="4"
                    placeholder="Describe your action..."></textarea>
            </div>

            <button type="submit"
                class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">Submit for Approval</button>
        </form>
    </main>

    <!-- Footer / Scripts -->
    <?php include('../includes/footer.php'); ?>
</body>

</html>
