<?php
session_start();
if (empty($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$pdo = require_once __DIR__ . '/../config/db.php';
$user_id = $_SESSION['user']['id'];

// Fetch user info
$stmt = $pdo->prepare("SELECT name, email, coins FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Total actions logged
$actionCount = $pdo->prepare("SELECT COUNT(*) FROM user_actions WHERE user_id = ?");
$actionCount->execute([$user_id]);
$totalActions = $actionCount->fetchColumn();

// Redemption history
$redemptions = $pdo->prepare("
    SELECT r.name AS reward_name, rd.status, rd.created_at 
    FROM redemptions rd
    JOIN rewards r ON r.id = rd.reward_id
    WHERE rd.user_id = ?
    ORDER BY rd.created_at DESC
");
$redemptions->execute([$user_id]);
$history = $redemptions->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 min-h-screen flex">

    <!-- Sidebar Include -->
    <?php include('../includes/sidebar.php'); ?>

    <!-- Main Content -->
    <main class="flex-1 md:ml-64 p-6">
        <h2 class="text-2xl font-bold mb-4">👤 User Profile</h2>

        <div class="bg-white rounded shadow p-6 max-w-xl mb-6">
            <h3 class="text-lg font-semibold mb-2">Your Information</h3>
            <p><strong>Name:</strong> <?= htmlspecialchars($user['name']) ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
            <p><strong>Current Coins:</strong> <span class="text-green-600 font-semibold"><?= $user['coins'] ?></span></p>
            <p><strong>Actions Logged:</strong> <?= $totalActions ?></p>
        </div>

        <div class="bg-white rounded shadow p-6 max-w-3xl">
            <h3 class="text-lg font-semibold mb-4">🎁 Redemption History</h3>
            <?php if (count($history) > 0): ?>
                <table class="w-full text-left table-auto border-collapse">
                    <thead>
                        <tr class="bg-gray-200">
                            <th class="p-2 border-b">Reward</th>
                            <th class="p-2 border-b">Status</th>
                            <th class="p-2 border-b">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($history as $h): ?>
                            <tr>
                                <td class="p-2 border-b"><?= htmlspecialchars($h['reward_name']) ?></td>
                                <td class="p-2 border-b capitalize">
                                    <span class="px-2 py-1 rounded text-white 
                                        <?= $h['status'] === 'approved' ? 'bg-green-600' : ($h['status'] === 'pending' ? 'bg-yellow-500' : 'bg-red-600') ?>">
                                        <?= $h['status'] ?>
                                    </span>
                                </td>
                                <td class="p-2 border-b"><?= date('d M Y, h:i A', strtotime($h['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-gray-600">No redemptions yet.</p>
            <?php endif; ?>
        </div>
    </main>

    <?php include('../includes/footer.php'); ?>
</body>

</html>
