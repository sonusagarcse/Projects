<?php
session_start();
if (empty($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
$pdo = require __DIR__ . '/../config/db.php';

// Include AI classes
require_once '../ai/carbon_calculator.php';
require_once '../ai/smart_suggestions.php';

// Initialize AI classes
$carbon_calc = new CarbonCalculator($pdo);
$suggestions = new SmartSuggestions($pdo);

if (empty($_SESSION['user']) || !is_array($_SESSION['user']) || empty($_SESSION['user']['id'])) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];

// Get AI-powered data
$user_co2_data = $carbon_calc->getUserTotalCO2($user_id);
$ai_suggestions = $suggestions->getPersonalizedSuggestions($user_id, 3);

// Fetch comprehensive user data
$stmt = $pdo->prepare("SELECT coins, name, email, created_at FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Fetch user statistics
$stats = $pdo->prepare("
    SELECT 
        COUNT(ua.id) as total_actions,
        COUNT(CASE WHEN ua.status = 'approved' THEN 1 END) as approved_actions,
        COUNT(CASE WHEN ua.status = 'pending' THEN 1 END) as pending_actions,
        SUM(CASE WHEN ua.status = 'approved' THEN ea.coin_value ELSE 0 END) as total_coins_earned,
        COUNT(CASE WHEN ea.name LIKE '%tree%' OR ea.name LIKE '%plant%' THEN 1 END) as trees_planted,
        COUNT(CASE WHEN ea.name LIKE '%bicycle%' OR ea.name LIKE '%bike%' THEN 1 END) as bike_trips,
        COUNT(CASE WHEN ea.name LIKE '%transport%' OR ea.name LIKE '%bus%' THEN 1 END) as public_transport
    FROM user_actions ua
    LEFT JOIN eco_actions ea ON ua.action_id = ea.id
    WHERE ua.user_id = ?
");
$stats->execute([$user_id]);
$user_stats = $stats->fetch(PDO::FETCH_ASSOC);

// Fetch recent actions with more details
$recent_actions = $pdo->prepare("
    SELECT ua.*, ea.name as action_name, ea.coin_value, ea.description
                        FROM user_actions ua 
                        JOIN eco_actions ea ON ua.action_id = ea.id 
                        WHERE ua.user_id = ? 
    ORDER BY ua.created_at DESC LIMIT 10
");
$recent_actions->execute([$user_id]);
$actions = $recent_actions->fetchAll(PDO::FETCH_ASSOC);

// Fetch weekly data for charts
$weekly_data = $pdo->prepare("
    SELECT 
        DATE(ua.created_at) as date,
        COUNT(ua.id) as actions_count,
        SUM(CASE WHEN ua.status = 'approved' THEN ea.coin_value ELSE 0 END) as coins_earned
    FROM user_actions ua
    LEFT JOIN eco_actions ea ON ua.action_id = ea.id
    WHERE ua.user_id = ? AND ua.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(ua.created_at)
    ORDER BY date ASC
");
$weekly_data->execute([$user_id]);
$weekly_chart_data = $weekly_data->fetchAll(PDO::FETCH_ASSOC);

// Calculate carbon footprint saved
$carbon_saved = ($user_stats['bike_trips'] * 0.5) + ($user_stats['public_transport'] * 0.3) + ($user_stats['trees_planted'] * 22);

// Calculate user level based on total actions
$user_level = floor($user_stats['approved_actions'] / 10) + 1;
$next_level_actions = ($user_level * 10) - $user_stats['approved_actions'];

// Fetch available rewards
$rewards = $pdo->query("SELECT * FROM rewards WHERE stock > 0 ORDER BY coin_cost ASC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);

// Fetch leaderboard position
$leaderboard_position = $pdo->prepare("
    SELECT COUNT(*) + 1 as position
    FROM users 
    WHERE coins > ?
");
$leaderboard_position->execute([$user['coins']]);
$position = $leaderboard_position->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - GreenCoin</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <style>
    :root {
      --primary-green: #10b981;
      --dark-green: #059669;
      --light-green: #d1fae5;
      --accent-blue: #3b82f6;
      --accent-purple: #8b5cf6;
      --accent-orange: #f59e0b;
    }
    
    .gradient-bg {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    
    .glass-effect {
      background: rgba(255, 255, 255, 0.25);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.18);
    }
    
    .card-hover {
      transition: all 0.3s ease;
    }
    
    .card-hover:hover {
      transform: translateY(-5px);
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
    
    .progress-ring {
      transform: rotate(-90deg);
    }
    
    .pulse-animation {
      animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }
    
    .floating {
      animation: floating 3s ease-in-out infinite;
    }
    
    @keyframes floating {
      0%, 100% { transform: translateY(0px); }
      50% { transform: translateY(-10px); }
    }
    
    /* Chart container fixes */
    .chart-container {
      position: relative;
      height: 300px;
      width: 100%;
      overflow: hidden;
    }
    
    canvas {
      max-width: 100% !important;
      max-height: 100% !important;
    }
    
    /* Prevent chart overflow */
    #weeklyChart, #actionTypesChart {
      max-width: 100%;
      max-height: 300px;
    }
  </style>
</head>
<body class="bg-gradient-to-br from-green-50 via-blue-50 to-purple-50 min-h-screen">

  <!-- Sidebar -->
    <aside id="sidebar"
        class="fixed top-0 left-0 h-full w-64 bg-green-800 text-white flex flex-col transform -translate-x-full md:translate-x-0 transition-transform duration-300 z-40">
        <div class="p-6 flex items-center justify-between border-b border-green-700">
            <span class="text-2xl font-bold">🌱 GreenCoin</span>
            <button onclick="toggleSidebar()" class="md:hidden text-white text-xl">✖</button>
        </div>
        <nav class="flex-1 p-4 space-y-3">
            <a href="dashboard.php" class="block px-3 py-2 rounded hover:bg-green-700">🏠 Dashboard</a>
            <a href="log_action.php" class="block px-3 py-2 rounded hover:bg-green-700">➕ Log Action</a>
            <a href="rewards.php" class="block px-3 py-2 rounded hover:bg-green-700 font-semibold bg-green-700">🎁 Rewards</a>
            <a href="profile.php" class="block px-3 py-2 rounded hover:bg-green-700">👤 Profile</a>
        </nav>
        <div class="p-4 border-t border-green-700">
            <a href="logout.php"
                class="block px-3 py-2 rounded bg-red-600 hover:bg-red-700 text-center">🚪 Logout</a>
        </div>
    </aside>

  <!-- Mobile Menu Button -->
  <button onclick="toggleSidebar()" class="fixed top-4 left-4 md:hidden z-50 bg-green-700 text-white p-2 rounded">☰</button>

  <!-- Main Content -->
  <main class="flex-1 md:ml-64 p-6">
    <!-- Welcome Header -->
    <div class="mb-8">
      <h1 class="text-4xl font-bold text-gray-800 mb-2">
        Welcome back, <?= htmlspecialchars($_SESSION['user']['name']) ?>! 👋
      </h1>
      <p class="text-gray-600">Track your eco-journey and make a positive impact</p>
    </div>

    <!-- Stats Overview Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <!-- Wallet Card -->
      <div class="bg-gradient-to-br from-green-400 to-green-600 text-white p-6 rounded-2xl card-hover floating">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-green-100 text-sm font-medium">Total Coins</p>
            <p class="text-3xl font-bold"><?= $user['coins'] ?? 0 ?></p>
          </div>
          <div class="text-4xl opacity-80">
            <i class="fas fa-coins"></i>
          </div>
        </div>
        <div class="mt-4 flex items-center text-sm">
          <i class="fas fa-arrow-up mr-1"></i>
          <span>+<?= $user_stats['total_coins_earned'] ?? 0 ?> earned</span>
        </div>
      </div>

      <!-- Actions Card -->
      <div class="bg-gradient-to-br from-blue-400 to-blue-600 text-white p-6 rounded-2xl card-hover">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-blue-100 text-sm font-medium">Actions Taken</p>
            <p class="text-3xl font-bold"><?= $user_stats['approved_actions'] ?? 0 ?></p>
          </div>
          <div class="text-4xl opacity-80">
            <i class="fas fa-leaf"></i>
          </div>
        </div>
        <div class="mt-4 flex items-center text-sm">
          <i class="fas fa-check-circle mr-1"></i>
          <span><?= $user_stats['pending_actions'] ?? 0 ?> pending</span>
        </div>
      </div>

      <!-- Carbon Saved Card -->
      <div class="bg-gradient-to-br from-purple-400 to-purple-600 text-white p-6 rounded-2xl card-hover">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-purple-100 text-sm font-medium">CO₂ Saved</p>
            <p class="text-3xl font-bold"><?= round($carbon_saved, 1) ?>kg</p>
          </div>
          <div class="text-4xl opacity-80">
            <i class="fas fa-globe-americas"></i>
          </div>
        </div>
        <div class="mt-4 flex items-center text-sm">
          <i class="fas fa-tree mr-1"></i>
          <span><?= $user_stats['trees_planted'] ?? 0 ?> trees planted</span>
        </div>
      </div>

      <!-- Level Card -->
      <div class="bg-gradient-to-br from-orange-400 to-orange-600 text-white p-6 rounded-2xl card-hover">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-orange-100 text-sm font-medium">Eco Level</p>
            <p class="text-3xl font-bold"><?= $user_level ?></p>
          </div>
          <div class="text-4xl opacity-80">
            <i class="fas fa-trophy"></i>
          </div>
        </div>
        <div class="mt-4 flex items-center text-sm">
          <i class="fas fa-star mr-1"></i>
          <span><?= $next_level_actions ?> to next level</span>
        </div>
      </div>
    </div>

    <!-- Progress Section -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
      <!-- Level Progress -->
      <div class="bg-white p-6 rounded-2xl shadow-lg card-hover">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Level Progress</h3>
        <div class="relative">
          <div class="w-full bg-gray-200 rounded-full h-3">
            <div class="bg-gradient-to-r from-green-400 to-green-600 h-3 rounded-full" 
                 style="width: <?= min(100, ($user_stats['approved_actions'] % 10) * 10) ?>%"></div>
          </div>
          <p class="text-sm text-gray-600 mt-2">
            <?= $user_stats['approved_actions'] % 10 ?>/10 actions to level <?= $user_level + 1 ?>
          </p>
        </div>
      </div>

      <!-- Leaderboard Position -->
      <div class="bg-white p-6 rounded-2xl shadow-lg card-hover">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Leaderboard</h3>
        <div class="flex items-center">
          <div class="text-3xl mr-4">
            <?php if ($position <= 3): ?>
              <i class="fas fa-medal text-yellow-500"></i>
            <?php else: ?>
              <i class="fas fa-trophy text-gray-400"></i>
            <?php endif; ?>
          </div>
          <div>
            <p class="text-2xl font-bold text-gray-800">#<?= $position ?></p>
            <p class="text-sm text-gray-600">Global Rank</p>
          </div>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="bg-white p-6 rounded-2xl shadow-lg card-hover">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h3>
        <div class="space-y-3">
          <a href="log_action.php" class="block w-full bg-green-600 text-white text-center py-2 px-4 rounded-lg hover:bg-green-700 transition">
            <i class="fas fa-plus mr-2"></i>Log New Action
          </a>
          <a href="rewards.php" class="block w-full bg-blue-600 text-white text-center py-2 px-4 rounded-lg hover:bg-blue-700 transition">
            <i class="fas fa-gift mr-2"></i>View Rewards
          </a>
        </div>
      </div>
    </div>

    <!-- Charts Section -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
      <!-- Weekly Activity Chart -->
      <div class="bg-white p-6 rounded-2xl shadow-lg card-hover">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Weekly Activity</h3>
        <div class="chart-container">
          <canvas id="weeklyChart"></canvas>
        </div>
      </div>

      <!-- Action Types Chart -->
      <div class="bg-white p-6 rounded-2xl shadow-lg card-hover">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Action Breakdown</h3>
        <div class="chart-container">
          <canvas id="actionTypesChart"></canvas>
        </div>
      </div>
    </div>

    <!-- Recent Activity & Rewards -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
      <!-- Recent Activity -->
      <div class="bg-white p-6 rounded-2xl shadow-lg card-hover">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Recent Activity</h3>
        <div class="space-y-4">
          <?php if (empty($actions)): ?>
            <div class="text-center py-8 text-gray-500">
              <i class="fas fa-leaf text-4xl mb-4"></i>
              <p>No actions yet. Start your eco-journey!</p>
              <a href="log_action.php" class="inline-block mt-4 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                Log First Action
              </a>
            </div>
          <?php else: ?>
            <?php foreach(array_slice($actions, 0, 5) as $action): ?>
              <div class="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                <div class="flex-shrink-0">
                  <?php if ($action['status'] === 'approved'): ?>
                    <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <i class="fas fa-check text-green-600 text-sm"></i>
                    </div>
                  <?php elseif ($action['status'] === 'pending'): ?>
                    <div class="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                      <i class="fas fa-clock text-yellow-600 text-sm"></i>
                    </div>
                  <?php else: ?>
                    <div class="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                      <i class="fas fa-times text-red-600 text-sm"></i>
                    </div>
                  <?php endif; ?>
                </div>
                <div class="flex-1">
                  <p class="font-medium text-gray-800"><?= htmlspecialchars($action['action_name']) ?></p>
                  <p class="text-sm text-gray-600">
                    <?= date('M j, Y', strtotime($action['created_at'])) ?>
                    <?php if ($action['status'] === 'approved'): ?>
                      <span class="text-green-600 font-medium">+<?= $action['coin_value'] ?> coins</span>
                    <?php endif; ?>
                  </p>
                </div>
                <div class="text-right">
                  <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                    <?= $action['status'] === 'approved' ? 'bg-green-100 text-green-800' : 
                        ($action['status'] === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800') ?>">
                    <?= ucfirst($action['status']) ?>
                  </span>
                </div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>

      <!-- Available Rewards -->
      <div class="bg-white p-6 rounded-2xl shadow-lg card-hover">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Available Rewards</h3>
        <div class="space-y-3">
          <?php if (empty($rewards)): ?>
            <div class="text-center py-8 text-gray-500">
              <i class="fas fa-gift text-4xl mb-4"></i>
              <p>No rewards available at the moment</p>
            </div>
          <?php else: ?>
            <?php foreach($rewards as $reward): ?>
              <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p class="font-medium text-gray-800"><?= htmlspecialchars($reward['name']) ?></p>
                  <p class="text-sm text-gray-600"><?= htmlspecialchars($reward['description']) ?></p>
                </div>
                <div class="text-right">
                  <p class="text-lg font-bold text-green-600"><?= $reward['coin_cost'] ?> coins</p>
                  <p class="text-xs text-gray-500"><?= $reward['stock'] ?> left</p>
                </div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
        <div class="mt-4">
          <a href="rewards.php" class="block w-full bg-blue-600 text-white text-center py-2 px-4 rounded-lg hover:bg-blue-700 transition">
            View All Rewards
          </a>
        </div>
    </div>
    </div>

    <!-- AI Features Section -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
      <!-- Carbon Footprint Tracker -->
      <div class="bg-gradient-to-br from-green-500 to-emerald-600 p-6 rounded-2xl shadow-lg text-white">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-xl font-semibold">
            <i class="fas fa-leaf mr-2"></i> Your Carbon Impact
          </h3>
          <div class="text-3xl">
            <i class="fas fa-globe"></i>
          </div>
        </div>
        
        <div class="text-center mb-4">
          <div class="text-4xl font-bold mb-2"><?= $user_co2_data['total_co2'] ?> kg</div>
          <div class="text-green-100">CO₂ Saved</div>
        </div>
        
        <div class="grid grid-cols-2 gap-4 mb-4">
          <div class="text-center">
            <div class="text-2xl font-bold"><?= $user_co2_data['actions_count'] ?></div>
            <div class="text-sm text-green-100">Actions</div>
          </div>
          <div class="text-center">
            <div class="text-2xl font-bold"><?= round($user_co2_data['total_co2'] / 22, 1) ?></div>
            <div class="text-sm text-green-100">Trees Equivalent</div>
          </div>
        </div>
        
        <div class="bg-white/20 rounded-lg p-3">
          <div class="text-sm">
            <i class="fas fa-tree mr-1"></i> 
            You've made a positive impact equivalent to planting 
            <strong><?= round($user_co2_data['total_co2'] / 22, 1) ?></strong> trees!
          </div>
        </div>
      </div>

      <!-- AI Suggestions -->
      <div class="bg-white p-6 rounded-2xl shadow-lg">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-xl font-semibold text-gray-800">
            <i class="fas fa-robot text-purple-600 mr-2"></i> AI Suggestions
          </h3>
          <a href="ai_assistant.php" class="text-purple-600 hover:text-purple-700 text-sm">
            <i class="fas fa-external-link-alt mr-1"></i> Full Assistant
          </a>
        </div>
        
        <div class="space-y-3">
          <?php foreach ($ai_suggestions as $suggestion): ?>
            <div class="p-3 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border-l-4 border-purple-400">
              <div class="flex items-start">
                <div class="text-2xl mr-3"><?= $suggestion['title'][0] ?></div>
                <div class="flex-1">
                  <div class="font-semibold text-gray-800 text-sm"><?= htmlspecialchars($suggestion['title']) ?></div>
                  <div class="text-xs text-gray-600 mt-1"><?= htmlspecialchars($suggestion['description']) ?></div>
                  <div class="text-xs text-purple-600 mt-1">
                    <i class="fas fa-lightbulb mr-1"></i>
                    <?= htmlspecialchars($suggestion['reason']) ?>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
        
        <div class="mt-4">
          <a href="ai_assistant.php" class="block w-full bg-purple-600 text-white text-center py-2 px-4 rounded-lg hover:bg-purple-700 transition">
            <i class="fas fa-comments mr-2"></i> Chat with AI Assistant
          </a>
        </div>
      </div>
    </div>

  </main>

  <script>
    function toggleSidebar() {
      document.getElementById('sidebar').classList.toggle('-translate-x-full');
    }

    // Real data from PHP with error handling
    const weeklyData = <?= json_encode($weekly_chart_data) ?> || [];
    const userStats = <?= json_encode($user_stats) ?> || {};

    // Helper function to safely parse numbers
    function safeParseInt(value, defaultValue = 0) {
      const parsed = parseInt(value);
      return isNaN(parsed) ? defaultValue : Math.max(0, parsed);
    }

    // Process weekly data for chart with validation
    const last7Days = [];
    const actionsData = [];
    const coinsData = [];
    
    // Generate last 7 days
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      last7Days.push(date.toLocaleDateString('en-US', { weekday: 'short' }));
      
      // Find data for this date with error handling
      let dayData = null;
      try {
        dayData = weeklyData.find(d => {
          if (!d || !d.date) return false;
          const dataDate = new Date(d.date);
          return dataDate.toDateString() === date.toDateString();
        });
      } catch (e) {
        console.warn('Error processing date data:', e);
      }
      
      actionsData.push(dayData ? safeParseInt(dayData.actions_count, 0) : 0);
      coinsData.push(dayData ? safeParseInt(dayData.coins_earned, 0) : 0);
    }

    // Ensure we have valid data arrays
    const maxActions = Math.max(...actionsData, 1);
    const maxCoins = Math.max(...coinsData, 1);

    // Weekly Activity Chart with proper limits
    const weeklyCtx = document.getElementById('weeklyChart');
    if (weeklyCtx) {
      new Chart(weeklyCtx.getContext('2d'), {
        type: 'line',
        data: {
          labels: last7Days,
          datasets: [{
            label: 'Actions',
            data: actionsData,
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 4,
            pointHoverRadius: 6
          }, {
            label: 'Coins Earned',
            data: coinsData,
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            tension: 0.4,
            fill: true,
            yAxisID: 'y1',
            pointRadius: 4,
            pointHoverRadius: 6
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: {
            intersect: false,
            mode: 'index'
          },
          plugins: {
            legend: {
              position: 'top',
            },
            tooltip: {
              mode: 'index',
              intersect: false,
            }
          },
          scales: {
            x: {
              display: true,
              title: {
                display: true,
                text: 'Days'
              }
            },
            y: {
              type: 'linear',
              display: true,
              position: 'left',
              beginAtZero: true,
              max: Math.ceil(maxActions * 1.2), // Add 20% padding
              title: {
                display: true,
                text: 'Actions'
              },
              ticks: {
                stepSize: 1
              }
            },
            y1: {
              type: 'linear',
              display: true,
              position: 'right',
              beginAtZero: true,
              max: Math.ceil(maxCoins * 1.2), // Add 20% padding
              title: {
                display: true,
                text: 'Coins'
              },
              grid: {
                drawOnChartArea: false,
              },
              ticks: {
                stepSize: 1
              }
            }
          }
        }
      });
    }

    // Action Types Chart with validation
    const actionTypesCtx = document.getElementById('actionTypesChart');
    if (actionTypesCtx) {
      const treesPlanted = safeParseInt(userStats.trees_planted, 0);
      const bikeTrips = safeParseInt(userStats.bike_trips, 0);
      const publicTransport = safeParseInt(userStats.public_transport, 0);
      const approvedActions = safeParseInt(userStats.approved_actions, 0);
      const otherActions = Math.max(0, approvedActions - treesPlanted - bikeTrips - publicTransport);

      // Only show chart if there's data
      if (approvedActions > 0) {
        new Chart(actionTypesCtx.getContext('2d'), {
          type: 'doughnut',
          data: {
            labels: ['Trees Planted', 'Bike Trips', 'Public Transport', 'Other Actions'],
            datasets: [{
              data: [treesPlanted, bikeTrips, publicTransport, otherActions],
              backgroundColor: [
                '#10b981',
                '#3b82f6',
                '#8b5cf6',
                '#f59e0b'
              ],
              borderWidth: 2,
              borderColor: '#ffffff'
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'bottom',
              },
              tooltip: {
                callbacks: {
                  label: function(context) {
                    const label = context.label || '';
                    const value = context.parsed || 0;
                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                    const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                    return `${label}: ${value} (${percentage}%)`;
                  }
                }
              }
            }
          }
        });
      } else {
        // Show empty state
        actionTypesCtx.style.display = 'none';
        const emptyState = document.createElement('div');
        emptyState.className = 'text-center py-8 text-gray-500';
        emptyState.innerHTML = '<i class="fas fa-chart-pie text-4xl mb-4"></i><p>No data available yet</p>';
        actionTypesCtx.parentNode.appendChild(emptyState);
      }
    }

    // Add some interactive features
    document.addEventListener('DOMContentLoaded', function() {
      // Add pulse animation to cards on hover
      const cards = document.querySelectorAll('.card-hover');
      cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
          this.style.transform = 'translateY(-5px) scale(1.02)';
        });
        card.addEventListener('mouseleave', function() {
          this.style.transform = 'translateY(0) scale(1)';
        });
      });

      // Add floating animation to specific elements
      const floatingElements = document.querySelectorAll('.floating');
      floatingElements.forEach((element, index) => {
        element.style.animationDelay = `${index * 0.5}s`;
      });
    });
  </script>
  <?php include("tawk.php"); ?>
</body>
</html>
