<?php
$host = "localhost";
$db   = "green_coin";   // your DB name
$user = "root";        // XAMPP default user
$pass = "";            // XAMPP default password is empty

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $pdo;   // ✅ this makes require() return the PDO object
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}
    