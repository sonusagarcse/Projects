<?php
/**
 * AI Configuration File
 * Store API keys and AI settings here
 */

// Google Vision API Configuration
define('GOOGLE_VISION_API_KEY', 'YOUR API');

// AIzaSyBa652UiSrWZdzYZhmslvdA_kwhL9WQtrE = diwakar

// OpenAI API Configuration (optional)
define('OPENAI_API_KEY', ''); // Add your OpenAI API key here if you have one

// AI Feature Settings
define('AI_PHOTO_VERIFICATION_ENABLED', true);
define('AI_PHOTO_VERIFICATION_THRESHOLD', 0.7); // Confidence threshold for auto-approval
define('AI_SUGGESTIONS_ENABLED', true);
define('AI_CHATBOT_ENABLED', true);
define('AI_CARBON_CALCULATOR_ENABLED', true);

// Photo Verification Settings
define('AUTO_APPROVE_HIGH_CONFIDENCE', true);
define('MANUAL_REVIEW_THRESHOLD', 0.6);
define('REJECTION_THRESHOLD', 0.3);

// Smart Suggestions Settings
define('MAX_SUGGESTIONS_PER_USER', 5);
define('SUGGESTION_CACHE_DURATION', 3600); // 1 hour in seconds

// Carbon Calculator Settings
define('DEFAULT_TREE_CO2_ABSORPTION', 22); // kg CO2 per tree per year
define('DEFAULT_CAR_EMISSIONS', 0.192); // kg CO2 per km
define('DEFAULT_BUS_EMISSIONS', 0.089); // kg CO2 per km

// Chatbot Settings
define('CHATBOT_MAX_CONVERSATION_HISTORY', 20);
define('CHATBOT_RESPONSE_TIMEOUT', 30); // seconds
define('CHATBOT_ENABLE_LEARNING', true);

// Error Logging
define('AI_ERROR_LOG_ENABLED', true);
define('AI_ERROR_LOG_FILE', '../logs/ai_errors.log');

// API Rate Limiting
define('GOOGLE_VISION_RATE_LIMIT', 1000); // requests per day
define('OPENAI_RATE_LIMIT', 100); // requests per day

// Debug Mode
define('AI_DEBUG_MODE', false); // Set to true for debugging

// Environment Detection
$is_production = (strpos($_SERVER['HTTP_HOST'], 'localhost') === false);
define('AI_PRODUCTION_MODE', $is_production);

// Security Settings
if (AI_PRODUCTION_MODE) {
    // In production, you might want to load API keys from environment variables
    // instead of hardcoding them
    $google_vision_key = getenv('GOOGLE_VISION_API_KEY') ?: GOOGLE_VISION_API_KEY;
    $openai_key = getenv('OPENAI_API_KEY') ?: OPENAI_API_KEY;
} else {
    // In development, use the hardcoded keys
    $google_vision_key = GOOGLE_VISION_API_KEY;
    $openai_key = OPENAI_API_KEY;
}

// Export API keys for use in other files
$GLOBALS['AI_CONFIG'] = [
    'google_vision_api_key' => $google_vision_key,
    'openai_api_key' => $openai_key,
    'photo_verification_enabled' => AI_PHOTO_VERIFICATION_ENABLED,
    'photo_verification_threshold' => AI_PHOTO_VERIFICATION_THRESHOLD,
    'suggestions_enabled' => AI_SUGGESTIONS_ENABLED,
    'chatbot_enabled' => AI_CHATBOT_ENABLED,
    'carbon_calculator_enabled' => AI_CARBON_CALCULATOR_ENABLED,
    'debug_mode' => AI_DEBUG_MODE,
    'production_mode' => AI_PRODUCTION_MODE
];

// Function to get AI configuration
function getAIConfig($key = null) {
    global $AI_CONFIG;
    if ($key === null) {
        return $AI_CONFIG;
    }
    return isset($AI_CONFIG[$key]) ? $AI_CONFIG[$key] : null;
}

// Function to log AI errors
function logAIError($message, $context = []) {
    if (!AI_ERROR_LOG_ENABLED) {
        return;
    }
    
    $log_dir = dirname(AI_ERROR_LOG_FILE);
    if (!is_dir($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    
    $timestamp = date('Y-m-d H:i:s');
    $context_str = !empty($context) ? ' | Context: ' . json_encode($context) : '';
    $log_message = "[$timestamp] $message$context_str" . PHP_EOL;
    
    file_put_contents(AI_ERROR_LOG_FILE, $log_message, FILE_APPEND | LOCK_EX);
}

// Function to check if API key is valid (basic validation)
function validateGoogleVisionAPIKey($api_key) {
    if (empty($api_key)) {
        return false;
    }
    
    // Basic format validation
    if (strlen($api_key) < 30 || !preg_match('/^[A-Za-z0-9_-]+$/', $api_key)) {
        return false;
    }
    
    return true;
}

// Validate the API key on load
if (!validateGoogleVisionAPIKey($google_vision_key)) {
    logAIError('Invalid Google Vision API key format', ['api_key' => substr($google_vision_key, 0, 10) . '...']);
}

// Test API connectivity (optional, can be disabled in production)
if (AI_DEBUG_MODE && !AI_PRODUCTION_MODE) {
    // You can add API connectivity tests here
    // This is useful for development to ensure the API key works
}
?>
