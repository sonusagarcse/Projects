<?php
/**
 * Google Vision API Test Script
 * Test the Google Vision API key and connectivity
 */

require_once 'config/ai_config.php';

echo "<h1>🔍 Google Vision API Test</h1>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .test-section { background: #f5f5f5; padding: 15px; margin: 10px 0; border-radius: 5px; }
    .success { color: green; }
    .error { color: red; }
    .info { color: blue; }
    .warning { color: orange; }
</style>";

// Get API key
$api_key = getAIConfig('google_vision_api_key');
echo "<div class='test-section'>";
echo "<h2>API Key Information</h2>";
echo "<p class='info'>📊 API Key: " . substr($api_key, 0, 20) . "...</p>";
echo "<p class='info'>📊 Key Length: " . strlen($api_key) . " characters</p>";

// Validate API key format
if (validateGoogleVisionAPIKey($api_key)) {
    echo "<p class='success'>✅ API Key format is valid</p>";
} else {
    echo "<p class='error'>❌ API Key format is invalid</p>";
    echo "</div>";
    exit;
}
echo "</div>";

// Test API connectivity
echo "<div class='test-section'>";
echo "<h2>API Connectivity Test</h2>";

// Create a simple test image (base64 encoded 1x1 pixel)
$test_image_base64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

$url = 'https://vision.googleapis.com/v1/images:annotate?key=' . $api_key;

$data = [
    'requests' => [
        [
            'image' => [
                'content' => $test_image_base64
            ],
            'features' => [
                [
                    'type' => 'LABEL_DETECTION',
                    'maxResults' => 1
                ]
            ]
        ]
    ]
];

echo "<p class='info'>📡 Testing API connection...</p>";

$start_time = microtime(true);
$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode($data),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 15,
]);
$result = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr = curl_error($ch);
curl_close($ch);
$end_time = microtime(true);

$response_time = round(($end_time - $start_time) * 1000, 2);

if ($result === false || $httpCode >= 400) {
    echo "<p class='error'>❌ Failed to connect to Google Vision API</p>";
    if (!empty($curlErr)) {
        echo "<p class='warning'>cURL error: " . htmlspecialchars($curlErr) . "</p>";
    }
    if (!empty($httpCode)) {
        echo "<p class='warning'>HTTP status: " . htmlspecialchars((string)$httpCode) . "</p>";
        if (!empty($result)) {
            echo "<p class='warning'>Response: " . htmlspecialchars(substr($result, 0, 400)) . "...</p>";
        }
    }
    echo "<p class='warning'>⚠️ This could be due to:</p>";
    echo "<ul class='ml-4'>";
    echo "<li>• API key not enabled for Vision API</li>";
    echo "<li>• API key has restrictions (IP, referrer, etc.)</li>";
    echo "<li>• Billing not enabled for the project</li>";
    echo "<li>• Internet connection issues</li>";
    echo "</ul>";
} else {
    $response = json_decode($result, true);
    
    if (isset($response['responses'][0])) {
        echo "<p class='success'>✅ API connection successful!</p>";
        echo "<p class='info'>📊 Response time: {$response_time}ms</p>";
        echo "<p class='info'>📊 API is ready for photo verification</p>";
        
        // Show sample response
        if (isset($response['responses'][0]['labelAnnotations'])) {
            $labels = $response['responses'][0]['labelAnnotations'];
            echo "<p class='info'>📝 Sample labels detected: " . count($labels) . "</p>";
        }
    } else {
        echo "<p class='error'>❌ API returned unexpected response</p>";
        echo "<p class='warning'>⚠️ Response: " . htmlspecialchars(substr($result, 0, 200)) . "...</p>";
        
        if (isset($response['error'])) {
            echo "<p class='error'>❌ API Error: " . $response['error']['message'] . "</p>";
            echo "<p class='warning'>⚠️ Error Code: " . ($response['error']['code'] ?? 'Unknown') . "</p>";
            
            // Provide specific guidance based on error
            if (isset($response['error']['code']) && $response['error']['code'] == 403) {
                echo "<div class='bg-yellow-100 p-3 rounded mt-2'>";
                echo "<p class='font-semibold'>🔧 How to fix 403 Forbidden error:</p>";
                echo "<ol class='ml-4 mt-2'>";
                echo "<li>1. Go to <a href='https://console.cloud.google.com/' target='_blank'>Google Cloud Console</a></li>";
                echo "<li>2. Select your project</li>";
                echo "<li>3. Enable the Vision API</li>";
                echo "<li>4. Check API key restrictions</li>";
                echo "<li>5. Ensure billing is enabled</li>";
                echo "</ol>";
                echo "</div>";
            }
        }
    }
}
echo "</div>";

// Test photo verification class
echo "<div class='test-section'>";
echo "<h2>Photo Verification Class Test</h2>";

try {
    require_once 'config/db.php';
    require_once 'ai/photo_verification.php';
    
    $pdo = require_once 'config/db.php';
    $photo_verifier = new PhotoVerification($pdo);
    
    echo "<p class='success'>✅ Photo Verification class loaded successfully</p>";
    echo "<p class='info'>📊 API key configured: " . (strlen($api_key) > 10 ? 'Yes' : 'No') . "</p>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Photo Verification class failed: " . $e->getMessage() . "</p>";
}
echo "</div>";

// Usage instructions
echo "<div class='test-section'>";
echo "<h2>📚 Usage Instructions</h2>";
echo "<p class='info'>Your Google Vision API key is now configured and ready to use!</p>";
echo "<ul>";
echo "<li>✅ Photo verification will work automatically</li>";
echo "<li>✅ Admin can auto-verify photos in the AI Features panel</li>";
echo "<li>✅ Users can upload photos for eco actions</li>";
echo "<li>✅ High-confidence photos will be auto-approved</li>";
echo "</ul>";

echo "<p class='info'><strong>Next steps:</strong></p>";
echo "<ol>";
echo "<li>Run the database migration: <code>SOURCE ai/ai_database_migration.sql;</code></li>";
echo "<li>Test the admin AI features panel</li>";
echo "<li>Upload test photos to verify the system works</li>";
echo "<li>Monitor the verification logs for any issues</li>";
echo "</ol>";
echo "</div>";

echo "<div class='test-section'>";
echo "<h2>🔗 Quick Links</h2>";
echo "<p><a href='admin/ai_features.php' target='_blank'>🤖 Admin AI Features Panel</a></p>";
echo "<p><a href='public/ai_assistant.php' target='_blank'>💬 User AI Assistant</a></p>";
echo "<p><a href='test_ai_features.php' target='_blank'>🧪 Full AI Features Test</a></p>";
echo "</div>";
?>
