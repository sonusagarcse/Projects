-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2025 at 02:23 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `green_coin`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ApproveUserAction` (IN `action_id` INT)   BEGIN
    DECLARE user_id INT;
    DECLARE coin_value INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Get user_id and coin_value
    SELECT ua.user_id, ea.coin_value INTO user_id, coin_value
    FROM user_actions ua
    JOIN eco_actions ea ON ua.action_id = ea.id
    WHERE ua.id = action_id AND ua.status = 'pending';
    
    -- Update user_actions
    UPDATE user_actions 
    SET status = 'approved', coins_awarded = coin_value
    WHERE id = action_id;
    
    -- Update user coins
    UPDATE users 
    SET coins = coins + coin_value
    WHERE id = user_id;
    
    -- Insert transaction record
    INSERT INTO transactions (user_id, type, amount, meta, created_at)
    VALUES (user_id, 'earn', coin_value, JSON_OBJECT('action_id', action_id), NOW());
    
    COMMIT;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RejectUserAction` (IN `action_id` INT)   BEGIN
    UPDATE user_actions 
    SET status = 'rejected'
    WHERE id = action_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ai_analytics`
--

CREATE TABLE `ai_analytics` (
  `id` int(11) NOT NULL,
  `feature_name` varchar(100) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action_type` varchar(50) DEFAULT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ai_analytics`
--

INSERT INTO `ai_analytics` (`id`, `feature_name`, `user_id`, `action_type`, `data`, `created_at`) VALUES
(1, 'carbon_calculator', NULL, NULL, '{\"enabled\": true, \"version\": \"1.0\"}', '2025-09-13 16:58:28'),
(2, 'photo_verification', NULL, NULL, '{\"enabled\": true, \"version\": \"1.0\", \"threshold\": 0.7}', '2025-09-13 16:58:28'),
(3, 'smart_suggestions', NULL, NULL, '{\"enabled\": true, \"version\": \"1.0\"}', '2025-09-13 16:58:28'),
(4, 'eco_chatbot', NULL, NULL, '{\"enabled\": true, \"version\": \"1.0\"}', '2025-09-13 16:58:28');

-- --------------------------------------------------------

--
-- Table structure for table `ai_suggestions`
--

CREATE TABLE `ai_suggestions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action_name` varchar(150) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `priority` enum('high','medium','low') DEFAULT 'medium',
  `type` enum('behavior_based','time_based','location_based','trending','default') DEFAULT 'default',
  `score` decimal(5,2) DEFAULT 0.00,
  `shown_at` datetime DEFAULT NULL,
  `clicked_at` datetime DEFAULT NULL,
  `action_taken_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `carbon_footprint`
--

CREATE TABLE `carbon_footprint` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action_id` int(11) NOT NULL,
  `co2_saved` decimal(8,2) DEFAULT 0.00,
  `calculation_method` varchar(100) DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chatbot_conversations`
--

CREATE TABLE `chatbot_conversations` (
  `id` int(11) NOT NULL,
  `conversation_id` varchar(100) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_message` text NOT NULL,
  `bot_response` text NOT NULL,
  `intent` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `message`, `created_at`) VALUES
(1, 'Alice Johnson', 'alice@example.com', 'Great initiative! How can I get involved?', '2025-09-12 16:01:29'),
(2, 'Bob Wilson', 'bob@example.com', 'Love the concept of earning coins for eco actions', '2025-09-11 16:01:29'),
(3, 'Carol Davis', 'carol@example.com', 'Would like to partner with your program', '2025-09-10 16:01:29');

-- --------------------------------------------------------

--
-- Stand-in structure for view `daily_activity`
-- (See below for the actual view)
--
CREATE TABLE `daily_activity` (
`date` date
,`total_actions` bigint(21)
,`approved_actions` bigint(21)
,`pending_actions` bigint(21)
,`coins_awarded` decimal(32,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `eco_actions`
--

CREATE TABLE `eco_actions` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `coin_value` int(11) DEFAULT 5,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eco_actions`
--

INSERT INTO `eco_actions` (`id`, `name`, `coin_value`, `description`, `created_at`) VALUES
(1, 'Used Bicycle', 10, 'Traveled by bicycle instead of car', '2025-09-13 16:01:29'),
(2, 'Used Public Transport', 5, 'Used bus, train, or metro', '2025-09-13 16:01:29'),
(3, 'Planted a Tree', 50, 'Planted a tree or participated in tree planting', '2025-09-13 16:01:29'),
(4, 'Recycled Plastic', 8, 'Recycled plastic waste properly', '2025-09-13 16:01:29'),
(5, 'Used Reusable Bottle', 3, 'Used reusable water bottle instead of plastic', '2025-09-13 16:01:29'),
(6, 'Carpooled', 7, 'Shared a ride with others', '2025-09-13 16:01:29'),
(7, 'Walked to Work', 5, 'Walked to work instead of driving', '2025-09-13 16:01:29'),
(8, 'Used LED Bulbs', 4, 'Switched to energy-efficient LED lighting', '2025-09-13 16:01:29'),
(9, 'Composted', 6, 'Started composting organic waste', '2025-09-13 16:01:29'),
(10, 'Bought Local Products', 3, 'Purchased locally produced goods', '2025-09-13 16:01:29');

-- --------------------------------------------------------

--
-- Table structure for table `redemptions`
--

CREATE TABLE `redemptions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `reward_id` int(11) NOT NULL,
  `status` varchar(30) DEFAULT 'requested',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `redemptions`
--

INSERT INTO `redemptions` (`id`, `user_id`, `reward_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 'approved', '2025-09-12 16:01:29', '2025-09-13 16:01:29'),
(2, 3, 2, 'approved', '2025-09-11 16:01:29', '2025-09-13 16:01:29'),
(3, 4, 3, 'requested', '2025-09-13 16:01:29', '2025-09-13 16:01:29'),
(4, 2, 1, 'requested', '2025-09-13 16:06:25', '2025-09-13 16:06:25'),
(5, 2, 1, 'requested', '2025-09-13 16:07:08', '2025-09-13 16:07:08'),
(6, 2, 1, 'requested', '2025-09-13 16:07:09', '2025-09-13 16:07:09');

--
-- Triggers `redemptions`
--
DELIMITER $$
CREATE TRIGGER `update_reward_stock_after_redemption` AFTER UPDATE ON `redemptions` FOR EACH ROW BEGIN
    IF NEW.status = 'approved' AND OLD.status != 'approved' THEN
        UPDATE rewards 
        SET stock = stock - 1 
        WHERE id = NEW.reward_id AND stock > 0;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `rewards`
--

CREATE TABLE `rewards` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `coin_cost` int(11) DEFAULT 50,
  `stock` int(11) DEFAULT 10,
  `partner` varchar(150) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rewards`
--

INSERT INTO `rewards` (`id`, `name`, `description`, `coin_cost`, `stock`, `partner`, `created_at`, `updated_at`) VALUES
(1, 'Cafeteria 10% Off', 'Get 10% discount at campus cafeteria', 50, 17, 'Campus Cafe', '2025-09-13 16:01:29', '2025-09-13 16:07:09'),
(2, 'Reusable Water Bottle', 'Eco-friendly stainless steel water bottle', 150, 15, 'GreenShop', '2025-09-13 16:01:29', '2025-09-13 16:01:29'),
(3, 'Coffee Voucher', 'Free coffee at local coffee shop', 75, 30, 'Green Beans Cafe', '2025-09-13 16:01:29', '2025-09-13 16:01:29'),
(4, 'Movie Ticket', 'Free movie ticket for eco-friendly films', 200, 10, 'Cinema Green', '2025-09-13 16:01:29', '2025-09-13 16:01:29'),
(5, 'Bookstore Discount', '15% off at campus bookstore', 100, 25, 'Eco Books', '2025-09-13 16:01:29', '2025-09-13 16:01:29'),
(6, 'Gym Membership', '1 month free gym membership', 300, 5, 'FitLife Gym', '2025-09-13 16:01:29', '2025-09-13 16:01:29'),
(7, 'Plant Seed Pack', 'Assorted seeds for home gardening', 40, 50, 'Garden Center', '2025-09-13 16:01:29', '2025-09-13 16:01:29'),
(8, 'Eco Tote Bag', 'Reusable shopping tote bag', 60, 40, 'GreenShop', '2025-09-13 16:01:29', '2025-09-13 16:01:29'),
(9, 'Bike Repair Voucher', 'Free bike maintenance service', 120, 8, 'Bike Shop', '2025-09-13 16:01:29', '2025-09-13 16:01:29'),
(10, 'Organic Snack Pack', 'Healthy organic snacks', 80, 20, 'Health Foods', '2025-09-13 16:01:29', '2025-09-13 16:01:29'),
(11, 'Dominoz 30% Off', 'Claim in shop', 200, 2, 'Dominoz', '2025-09-13 16:05:30', '2025-09-13 16:05:30');

-- --------------------------------------------------------

--
-- Stand-in structure for view `reward_stats`
-- (See below for the actual view)
--
CREATE TABLE `reward_stats` (
`id` int(11)
,`name` varchar(150)
,`coin_cost` int(11)
,`stock` int(11)
,`partner` varchar(150)
,`total_redemptions` bigint(21)
,`approved_redemptions` bigint(21)
,`pending_redemptions` bigint(21)
);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `amount` int(11) NOT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `type`, `amount`, `meta`, `created_at`) VALUES
(1, 2, 'earn', 10, '{\"action_id\": 1, \"description\": \"Used Bicycle\"}', '2025-09-11 16:01:29'),
(2, 2, 'earn', 5, '{\"action_id\": 2, \"description\": \"Used Public Transport\"}', '2025-09-12 16:01:29'),
(3, 3, 'earn', 50, '{\"action_id\": 3, \"description\": \"Planted a Tree\"}', '2025-09-10 16:01:29'),
(4, 3, 'earn', 8, '{\"action_id\": 4, \"description\": \"Recycled Plastic\"}', '2025-09-12 16:01:29'),
(5, 4, 'earn', 10, '{\"action_id\": 1, \"description\": \"Used Bicycle\"}', '2025-09-13 16:01:29'),
(6, 4, 'earn', 3, '{\"action_id\": 5, \"description\": \"Used Reusable Bottle\"}', '2025-09-13 16:01:29'),
(7, 3, 'earn', 10, '{\"action_id\": 1, \"description\": \"Used Bicycle\"}', '2025-09-08 16:01:29'),
(8, 2, 'earn', 3, '{\"action_id\":5}', '2025-09-13 16:07:26'),
(9, 2, 'earn', 10, '{\"action_id\":1}', '2025-09-13 16:08:13');

--
-- Triggers `transactions`
--
DELIMITER $$
CREATE TRIGGER `update_user_coins_after_transaction` AFTER INSERT ON `transactions` FOR EACH ROW BEGIN
    IF NEW.type = 'earn' THEN
        UPDATE users 
        SET coins = coins + NEW.amount 
        WHERE id = NEW.user_id;
    ELSEIF NEW.type = 'spend' THEN
        UPDATE users 
        SET coins = coins - NEW.amount 
        WHERE id = NEW.user_id;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(30) DEFAULT 'user',
  `coins` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ai_suggestions_enabled` tinyint(1) DEFAULT 1,
  `last_ai_interaction` datetime DEFAULT NULL,
  `preferred_ai_features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`preferred_ai_features`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `coins`, `created_at`, `updated_at`, `ai_suggestions_enabled`, `last_ai_interaction`, `preferred_ai_features`) VALUES
(1, 'Admin User', 'admin@example.com', '$2y$10$zLhyFgTn5bPlTu5DbGotlubf5PkgAOvTh9LzN3ebZnP/8fTmN1JXW', 'admin', 1000, '2025-09-13 16:01:29', '2025-09-13 16:04:55', 1, NULL, NULL),
(2, 'John Doe', 'sonusagarpoly@gmail.com', '$2y$10$CeN2gQv5dWAFQdPJE3IAuOAj9cLhVte/CIBcCZ0MhZZvUCS9yBifW', 'user', 26, '2025-09-13 16:01:29', '2025-09-13 16:08:13', 1, NULL, NULL),
(3, 'Jane Smith', 'jane@example.com', '$2y$10$yT.d1jQIEgnLaWF97QHbA.Aw.oJM/s.8N0lwHW7044pYTDP.r2MPe', 'user', 75, '2025-09-13 16:01:29', '2025-09-13 16:01:29', 1, NULL, NULL),
(4, 'Eco Warrior', 'eco@example.com', '$2y$10$yT.d1jQIEgnLaWF97QHbA.Aw.oJM/s.8N0lwHW7044pYTDP.r2MPe', 'user', 300, '2025-09-13 16:01:29', '2025-09-13 16:01:29', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_actions`
--

CREATE TABLE `user_actions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action_id` int(11) NOT NULL,
  `photo_path` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `coins_awarded` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ai_verified` tinyint(1) DEFAULT 0,
  `ai_confidence` decimal(3,2) DEFAULT 0.00,
  `ai_reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_actions`
--

INSERT INTO `user_actions` (`id`, `user_id`, `action_id`, `photo_path`, `notes`, `status`, `coins_awarded`, `created_at`, `updated_at`, `ai_verified`, `ai_confidence`, `ai_reason`) VALUES
(1, 2, 1, 'uploads/bike_photo.jpg', 'Rode bike to work today', 'approved', 10, '2025-09-11 16:01:29', '2025-09-13 16:01:29', 0, 0.00, NULL),
(2, 2, 2, 'uploads/bus_photo.jpg', 'Took the bus to campus', 'approved', 5, '2025-09-12 16:01:29', '2025-09-13 16:01:29', 0, 0.00, NULL),
(3, 3, 3, 'uploads/tree_photo.jpg', 'Planted a tree in the park', 'approved', 50, '2025-09-10 16:01:29', '2025-09-13 16:01:29', 0, 0.00, NULL),
(4, 3, 4, 'uploads/recycle_photo.jpg', 'Recycled plastic bottles', 'approved', 8, '2025-09-12 16:01:29', '2025-09-13 16:01:29', 0, 0.00, NULL),
(5, 4, 1, 'uploads/eco_bike.jpg', 'Daily bike commute', 'approved', 10, '2025-09-13 16:01:29', '2025-09-13 16:01:29', 0, 0.00, NULL),
(6, 4, 5, 'uploads/bottle_photo.jpg', 'Using reusable bottle', 'approved', 3, '2025-09-13 16:01:29', '2025-09-13 16:01:29', 0, 0.00, NULL),
(7, 2, 5, NULL, 'Started using reusable bottle', 'approved', 3, '2025-09-13 16:01:29', '2025-09-13 16:07:26', 0, 0.00, NULL),
(8, 3, 1, 'uploads/jane_bike.jpg', 'First time biking to work', 'approved', 10, '2025-09-08 16:01:29', '2025-09-13 16:01:29', 0, 0.00, NULL),
(9, 2, 1, 'assets/uploads/1757759882_68c5498aaa794.jpg', '', 'approved', 10, '2025-09-13 16:08:02', '2025-09-13 16:08:13', 0, 0.00, NULL),
(10, 2, 2, 'assets/uploads/1757764756_68c55c945879e.png', '', 'pending', 0, '2025-09-13 17:29:16', '2025-09-13 17:29:16', 0, 0.00, NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_stats`
-- (See below for the actual view)
--
CREATE TABLE `user_stats` (
`id` int(11)
,`name` varchar(100)
,`email` varchar(150)
,`coins` int(11)
,`total_actions` bigint(21)
,`approved_actions` bigint(21)
,`pending_actions` bigint(21)
,`rejected_actions` bigint(21)
,`total_coins_earned` decimal(32,0)
,`total_redemptions` bigint(21)
);

-- --------------------------------------------------------

--
-- Table structure for table `verification_logs`
--

CREATE TABLE `verification_logs` (
  `id` int(11) NOT NULL,
  `action_id` int(11) NOT NULL,
  `verified` tinyint(1) DEFAULT 0,
  `confidence` decimal(3,2) DEFAULT 0.00,
  `reason` text DEFAULT NULL,
  `status` enum('auto_approved','manual_review','rejected') DEFAULT 'manual_review',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure for view `daily_activity`
--
DROP TABLE IF EXISTS `daily_activity`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `daily_activity`  AS SELECT cast(`ua`.`created_at` as date) AS `date`, count(`ua`.`id`) AS `total_actions`, count(case when `ua`.`status` = 'approved' then 1 end) AS `approved_actions`, count(case when `ua`.`status` = 'pending' then 1 end) AS `pending_actions`, sum(case when `ua`.`status` = 'approved' then `ea`.`coin_value` else 0 end) AS `coins_awarded` FROM (`user_actions` `ua` left join `eco_actions` `ea` on(`ua`.`action_id` = `ea`.`id`)) GROUP BY cast(`ua`.`created_at` as date) ORDER BY cast(`ua`.`created_at` as date) DESC ;

-- --------------------------------------------------------

--
-- Structure for view `reward_stats`
--
DROP TABLE IF EXISTS `reward_stats`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reward_stats`  AS SELECT `r`.`id` AS `id`, `r`.`name` AS `name`, `r`.`coin_cost` AS `coin_cost`, `r`.`stock` AS `stock`, `r`.`partner` AS `partner`, count(`rd`.`id`) AS `total_redemptions`, count(case when `rd`.`status` = 'approved' then 1 end) AS `approved_redemptions`, count(case when `rd`.`status` = 'requested' then 1 end) AS `pending_redemptions` FROM (`rewards` `r` left join `redemptions` `rd` on(`r`.`id` = `rd`.`reward_id`)) GROUP BY `r`.`id`, `r`.`name`, `r`.`coin_cost`, `r`.`stock`, `r`.`partner` ;

-- --------------------------------------------------------

--
-- Structure for view `user_stats`
--
DROP TABLE IF EXISTS `user_stats`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `user_stats`  AS SELECT `u`.`id` AS `id`, `u`.`name` AS `name`, `u`.`email` AS `email`, `u`.`coins` AS `coins`, count(`ua`.`id`) AS `total_actions`, count(case when `ua`.`status` = 'approved' then 1 end) AS `approved_actions`, count(case when `ua`.`status` = 'pending' then 1 end) AS `pending_actions`, count(case when `ua`.`status` = 'rejected' then 1 end) AS `rejected_actions`, sum(case when `ua`.`status` = 'approved' then `ea`.`coin_value` else 0 end) AS `total_coins_earned`, count(`r`.`id`) AS `total_redemptions` FROM (((`users` `u` left join `user_actions` `ua` on(`u`.`id` = `ua`.`user_id`)) left join `eco_actions` `ea` on(`ua`.`action_id` = `ea`.`id`)) left join `redemptions` `r` on(`u`.`id` = `r`.`user_id`)) GROUP BY `u`.`id`, `u`.`name`, `u`.`email`, `u`.`coins` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ai_analytics`
--
ALTER TABLE `ai_analytics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_feature_name` (`feature_name`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `ai_suggestions`
--
ALTER TABLE `ai_suggestions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_priority` (`priority`),
  ADD KEY `idx_type` (`type`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `carbon_footprint`
--
ALTER TABLE `carbon_footprint`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_action_id` (`action_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `chatbot_conversations`
--
ALTER TABLE `chatbot_conversations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_conversation_id` (`conversation_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eco_actions`
--
ALTER TABLE `eco_actions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `redemptions`
--
ALTER TABLE `redemptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_redemptions_user_id` (`user_id`),
  ADD KEY `idx_redemptions_reward_id` (`reward_id`),
  ADD KEY `idx_redemptions_status` (`status`);

--
-- Indexes for table `rewards`
--
ALTER TABLE `rewards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_transactions_user_id` (`user_id`),
  ADD KEY `idx_transactions_type` (`type`),
  ADD KEY `idx_transactions_created_at` (`created_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_users_email` (`email`),
  ADD KEY `idx_users_role` (`role`),
  ADD KEY `idx_users_coins` (`coins`),
  ADD KEY `idx_users_ai_suggestions_enabled` (`ai_suggestions_enabled`);

--
-- Indexes for table `user_actions`
--
ALTER TABLE `user_actions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_actions_user_id` (`user_id`),
  ADD KEY `idx_user_actions_action_id` (`action_id`),
  ADD KEY `idx_user_actions_status` (`status`),
  ADD KEY `idx_user_actions_created_at` (`created_at`),
  ADD KEY `idx_user_actions_ai_verified` (`ai_verified`),
  ADD KEY `idx_user_actions_ai_confidence` (`ai_confidence`);

--
-- Indexes for table `verification_logs`
--
ALTER TABLE `verification_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `action_id` (`action_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ai_analytics`
--
ALTER TABLE `ai_analytics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ai_suggestions`
--
ALTER TABLE `ai_suggestions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `carbon_footprint`
--
ALTER TABLE `carbon_footprint`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chatbot_conversations`
--
ALTER TABLE `chatbot_conversations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `eco_actions`
--
ALTER TABLE `eco_actions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `redemptions`
--
ALTER TABLE `redemptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `rewards`
--
ALTER TABLE `rewards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_actions`
--
ALTER TABLE `user_actions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `verification_logs`
--
ALTER TABLE `verification_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ai_analytics`
--
ALTER TABLE `ai_analytics`
  ADD CONSTRAINT `ai_analytics_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `ai_suggestions`
--
ALTER TABLE `ai_suggestions`
  ADD CONSTRAINT `ai_suggestions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `carbon_footprint`
--
ALTER TABLE `carbon_footprint`
  ADD CONSTRAINT `carbon_footprint_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `carbon_footprint_ibfk_2` FOREIGN KEY (`action_id`) REFERENCES `user_actions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `chatbot_conversations`
--
ALTER TABLE `chatbot_conversations`
  ADD CONSTRAINT `chatbot_conversations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `redemptions`
--
ALTER TABLE `redemptions`
  ADD CONSTRAINT `redemptions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `redemptions_ibfk_2` FOREIGN KEY (`reward_id`) REFERENCES `rewards` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_actions`
--
ALTER TABLE `user_actions`
  ADD CONSTRAINT `user_actions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_actions_ibfk_2` FOREIGN KEY (`action_id`) REFERENCES `eco_actions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `verification_logs`
--
ALTER TABLE `verification_logs`
  ADD CONSTRAINT `verification_logs_ibfk_1` FOREIGN KEY (`action_id`) REFERENCES `user_actions` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
