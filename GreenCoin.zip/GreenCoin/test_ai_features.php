<?php
/**
 * AI Features Test Script
 * Test all AI features to ensure they're working correctly
 */

// Load configuration
require_once 'config/ai_config.php';
require_once 'config/db.php';

echo "<h1>🤖 GreenCoin AI Features Test</h1>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .test-section { background: #f5f5f5; padding: 15px; margin: 10px 0; border-radius: 5px; }
    .success { color: green; }
    .error { color: red; }
    .info { color: blue; }
    .warning { color: orange; }
</style>";

// Test 1: Configuration Loading
echo "<div class='test-section'>";
echo "<h2>1. Configuration Test</h2>";

$config = getAIConfig();
if ($config) {
    echo "<p class='success'>✅ AI Configuration loaded successfully</p>";
    echo "<p class='info'>📊 Google Vision API Key: " . (strlen($config['google_vision_api_key']) > 10 ? 'Set (' . substr($config['google_vision_api_key'], 0, 10) . '...)' : 'Not set') . "</p>";
    echo "<p class='info'>📊 OpenAI API Key: " . (strlen($config['openai_api_key']) > 10 ? 'Set (' . substr($config['openai_api_key'], 0, 10) . '...)' : 'Not set') . "</p>";
    echo "<p class='info'>📊 Photo Verification Enabled: " . ($config['photo_verification_enabled'] ? 'Yes' : 'No') . "</p>";
    echo "<p class='info'>📊 Debug Mode: " . ($config['debug_mode'] ? 'Yes' : 'No') . "</p>";
} else {
    echo "<p class='error'>❌ Failed to load AI configuration</p>";
}
echo "</div>";

// Test 2: Database Connection
echo "<div class='test-section'>";
echo "<h2>2. Database Connection Test</h2>";

try {
    $pdo = require_once 'config/db.php';
    echo "<p class='success'>✅ Database connection successful</p>";
    
    // Test AI tables
    $tables = ['verification_logs', 'chatbot_conversations', 'ai_suggestions', 'carbon_footprint'];
    foreach ($tables as $table) {
        try {
            $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
            echo "<p class='success'>✅ Table '$table' exists and accessible</p>";
        } catch (PDOException $e) {
            echo "<p class='warning'>⚠️ Table '$table' not found - run database migration</p>";
        }
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Database connection failed: " . $e->getMessage() . "</p>";
}
echo "</div>";

// Test 3: Carbon Calculator
echo "<div class='test-section'>";
echo "<h2>3. Carbon Calculator Test</h2>";

try {
    require_once 'ai/carbon_calculator.php';
    $carbon_calc = new CarbonCalculator($pdo);
    
    // Test CO2 calculation
    $co2_saved = $carbon_calc->calculateActionCO2('Used Bicycle', 5);
    echo "<p class='success'>✅ Carbon Calculator working - 5km bike ride saves " . $co2_saved . " kg CO₂</p>";
    
    // Test environmental impact
    $impact = $carbon_calc->getEnvironmentalImpact();
    echo "<p class='info'>📊 Total CO₂ saved by all users: " . $impact['total_co2_saved'] . " kg</p>";
    echo "<p class='info'>📊 Trees equivalent: " . $impact['trees_equivalent'] . "</p>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Carbon Calculator failed: " . $e->getMessage() . "</p>";
}
echo "</div>";

// Test 4: Smart Suggestions
echo "<div class='test-section'>";
echo "<h2>4. Smart Suggestions Test</h2>";

try {
    require_once 'ai/smart_suggestions.php';
    $suggestions = new SmartSuggestions($pdo);
    
    // Test suggestions for user ID 1
    $user_suggestions = $suggestions->getPersonalizedSuggestions(1, 3);
    echo "<p class='success'>✅ Smart Suggestions working - Generated " . count($user_suggestions) . " suggestions</p>";
    
    foreach ($user_suggestions as $i => $suggestion) {
        echo "<p class='info'>📝 Suggestion " . ($i + 1) . ": " . htmlspecialchars($suggestion['title']) . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Smart Suggestions failed: " . $e->getMessage() . "</p>";
}
echo "</div>";

// Test 5: Eco Chatbot
echo "<div class='test-section'>";
echo "<h2>5. Eco Chatbot Test</h2>";

try {
    require_once 'ai/eco_chatbot.php';
    $chatbot = new EcoChatbot($pdo);
    
    // Test chatbot response
    $response = $chatbot->processMessage('How do I earn coins for biking?', 1, 'test_conv');
    if ($response['success']) {
        echo "<p class='success'>✅ Eco Chatbot working</p>";
        echo "<p class='info'>🤖 Response: " . htmlspecialchars(substr($response['response'], 0, 100)) . "...</p>";
        echo "<p class='info'>🎯 Intent: " . $response['intent'] . "</p>";
    } else {
        echo "<p class='error'>❌ Chatbot response failed: " . $response['response'] . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Eco Chatbot failed: " . $e->getMessage() . "</p>";
}
echo "</div>";

// Test 6: Photo Verification (without actual photo)
echo "<div class='test-section'>";
echo "<h2>6. Photo Verification Test</h2>";

try {
    require_once 'ai/photo_verification.php';
    $photo_verifier = new PhotoVerification($pdo);
    
    echo "<p class='success'>✅ Photo Verification class loaded</p>";
    echo "<p class='info'>📊 API Key Status: " . (strlen($photo_verifier->google_vision_api_key) > 10 ? 'Configured' : 'Not configured') . "</p>";
    echo "<p class='info'>📊 Verification Threshold: " . $photo_verifier->verification_threshold . "</p>";
    
    // Test verification stats
    $stats = $photo_verifier->getVerificationStats();
    echo "<p class='info'>📊 Total Photos: " . $stats['total_photos'] . "</p>";
    echo "<p class='info'>📊 Approved Photos: " . $stats['approved_photos'] . "</p>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Photo Verification failed: " . $e->getMessage() . "</p>";
}
echo "</div>";

// Test 7: API Key Validation
echo "<div class='test-section'>";
echo "<h2>7. API Key Validation Test</h2>";

$google_key = getAIConfig('google_vision_api_key');
if (validateGoogleVisionAPIKey($google_key)) {
    echo "<p class='success'>✅ Google Vision API Key format is valid</p>";
    
    // Test API connectivity (optional)
    if (getAIConfig('debug_mode')) {
        echo "<p class='info'>🔍 Testing API connectivity...</p>";
        // You can add actual API test here
        echo "<p class='info'>📡 API Key ready for use</p>";
    }
} else {
    echo "<p class='error'>❌ Google Vision API Key format is invalid</p>";
    echo "<p class='warning'>⚠️ Please check your API key in config/ai_config.php</p>";
}
echo "</div>";

// Summary
echo "<div class='test-section'>";
echo "<h2>🎉 Test Summary</h2>";
echo "<p class='info'>All AI features have been tested. Check the results above for any issues.</p>";
echo "<p class='info'>📝 Next steps:</p>";
echo "<ul>";
echo "<li>Run the database migration if any tables are missing</li>";
echo "<li>Test the admin AI features panel</li>";
echo "<li>Test the user AI assistant page</li>";
echo "<li>Upload a test photo to verify photo verification</li>";
echo "</ul>";
echo "</div>";

echo "<div class='test-section'>";
echo "<h2>🔗 Quick Links</h2>";
echo "<p><a href='admin/ai_features.php' target='_blank'>Admin AI Features Panel</a></p>";
echo "<p><a href='public/ai_assistant.php' target='_blank'>User AI Assistant</a></p>";
echo "<p><a href='public/dashboard.php' target='_blank'>User Dashboard (with AI features)</a></p>";
echo "</div>";
?>
